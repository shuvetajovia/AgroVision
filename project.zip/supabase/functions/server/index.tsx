import { Hono } from 'npm:hono';
import { cors } from 'npm:hono/cors';
import { logger } from 'npm:hono/logger';
import { createClient } from 'npm:@supabase/supabase-js@2';
import * as kv from './kv_store.tsx';

const app = new Hono();

// Enable CORS and logging
app.use('*', cors());
app.use('*', logger(console.log));

// Initialize Supabase client
const supabase = createClient(
  Deno.env.get('SUPABASE_URL')!,
  Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!
);

// Route prefix
const PREFIX = '/make-server-7a8723f1';

// Health check
app.get(`${PREFIX}/health`, (c) => {
  return c.json({ status: 'healthy', timestamp: new Date().toISOString() });
});

// Submit farmer query
app.post(`${PREFIX}/queries`, async (c) => {
  try {
    const body = await c.req.json();
    const { question, questionMl, context, type, farmerId } = body;

    if (!question || !farmerId) {
      return c.json({ error: 'Question and farmerId are required' }, 400);
    }

    // Generate AI response based on query
    const response = await generateAIResponse(question, context, type);
    
    // Store query and response
    const queryId = `query_${Date.now()}_${farmerId}`;
    const queryData = {
      id: queryId,
      farmerId,
      question,
      questionMl,
      answer: response.answer,
      answerMl: response.answerMl,
      context,
      type,
      status: response.needsEscalation ? 'escalated' : 'resolved',
      timestamp: new Date().toISOString(),
      confidence: response.confidence
    };

    await kv.set(queryId, queryData);
    
    // Store in farmer's query history
    const historyKey = `farmer_${farmerId}_queries`;
    const existingQueries = await kv.get(historyKey) || [];
    existingQueries.push(queryId);
    await kv.set(historyKey, existingQueries.slice(-50)); // Keep last 50 queries

    console.log(`Processed query ${queryId} for farmer ${farmerId} with status: ${queryData.status}`);
    
    return c.json({
      queryId,
      answer: response.answer,
      answerMl: response.answerMl,
      status: queryData.status,
      confidence: response.confidence,
      escalated: response.needsEscalation
    });

  } catch (error) {
    console.log(`Error processing query: ${error}`);
    return c.json({ error: 'Failed to process query' }, 500);
  }
});

// Get farmer's query history
app.get(`${PREFIX}/farmers/:farmerId/queries`, async (c) => {
  try {
    const farmerId = c.req.param('farmerId');
    const historyKey = `farmer_${farmerId}_queries`;
    
    const queryIds = await kv.get(historyKey) || [];
    const queries = await kv.mget(queryIds);
    
    // Sort by timestamp, newest first
    const sortedQueries = queries
      .filter(q => q !== null)
      .sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());

    return c.json({ queries: sortedQueries });

  } catch (error) {
    console.log(`Error fetching query history for farmer ${c.req.param('farmerId')}: ${error}`);
    return c.json({ error: 'Failed to fetch query history' }, 500);
  }
});

// Update query feedback
app.post(`${PREFIX}/queries/:queryId/feedback`, async (c) => {
  try {
    const queryId = c.req.param('queryId');
    const { satisfaction, feedback } = await c.req.json();

    const query = await kv.get(queryId);
    if (!query) {
      return c.json({ error: 'Query not found' }, 404);
    }

    query.satisfaction = satisfaction;
    query.feedback = feedback;
    query.updatedAt = new Date().toISOString();

    await kv.set(queryId, query);

    console.log(`Updated feedback for query ${queryId}: ${satisfaction}`);
    return c.json({ success: true });

  } catch (error) {
    console.log(`Error updating feedback for query ${c.req.param('queryId')}: ${error}`);
    return c.json({ error: 'Failed to update feedback' }, 500);
  }
});

// Store farmer profile
app.post(`${PREFIX}/farmers/:farmerId/profile`, async (c) => {
  try {
    const farmerId = c.req.param('farmerId');
    const profileData = await c.req.json();

    const profileKey = `farmer_${farmerId}_profile`;
    const profile = {
      ...profileData,
      farmerId,
      updatedAt: new Date().toISOString()
    };

    await kv.set(profileKey, profile);

    console.log(`Updated profile for farmer ${farmerId}`);
    return c.json({ success: true, profile });

  } catch (error) {
    console.log(`Error updating profile for farmer ${c.req.param('farmerId')}: ${error}`);
    return c.json({ error: 'Failed to update profile' }, 500);
  }
});

// Get farmer profile
app.get(`${PREFIX}/farmers/:farmerId/profile`, async (c) => {
  try {
    const farmerId = c.req.param('farmerId');
    const profileKey = `farmer_${farmerId}_profile`;
    
    const profile = await kv.get(profileKey);
    if (!profile) {
      return c.json({ error: 'Profile not found' }, 404);
    }

    return c.json({ profile });

  } catch (error) {
    console.log(`Error fetching profile for farmer ${c.req.param('farmerId')}: ${error}`);
    return c.json({ error: 'Failed to fetch profile' }, 500);
  }
});

// Get knowledge base articles
app.get(`${PREFIX}/knowledge`, async (c) => {
  try {
    const category = c.req.query('category');
    const search = c.req.query('search');
    
    let articlesKey = 'knowledge_articles';
    if (category) {
      articlesKey = `knowledge_${category}`;
    }

    const articles = await kv.get(articlesKey) || [];
    
    let filteredArticles = articles;
    if (search) {
      filteredArticles = articles.filter(article => 
        article.title.toLowerCase().includes(search.toLowerCase()) ||
        article.titleMl.includes(search) ||
        article.content.toLowerCase().includes(search.toLowerCase())
      );
    }

    return c.json({ articles: filteredArticles });

  } catch (error) {
    console.log(`Error fetching knowledge base: ${error}`);
    return c.json({ error: 'Failed to fetch knowledge base' }, 500);
  }
});

// Generate AI response (mock implementation)
async function generateAIResponse(question: string, context: any, type: string) {
  // This would integrate with actual AI/ML models in production
  const pestKeywords = ['disease', 'pest', 'insect', 'fungus', 'രോഗം', 'പുഴു', 'കീടം'];
  const weatherKeywords = ['weather', 'rain', 'drought', 'temperature', 'കാലാവസ്ഥ', 'മഴ', 'വരൾച്ച'];
  
  const isPestQuery = pestKeywords.some(keyword => 
    question.toLowerCase().includes(keyword) || question.includes(keyword)
  );
  
  const isWeatherQuery = weatherKeywords.some(keyword => 
    question.toLowerCase().includes(keyword) || question.includes(keyword)
  );

  let answer = '';
  let answerMl = '';
  let confidence = 0.8;
  let needsEscalation = false;

  if (isPestQuery) {
    answer = `Based on your description and location (${context?.location || 'Kerala'}), this appears to be a common pest/disease issue. Here are my recommendations: 1) Remove affected plant parts, 2) Apply organic neem oil spray, 3) Ensure proper drainage, 4) Monitor closely for spread. If symptoms persist, contact your local agricultural officer.`;
    answerMl = `നിങ്ങളുടെ വിവരണവും സ്ഥലവും (${context?.location || 'കേരളം'}) അടിസ്ഥാനമാക്കി, ഇത് ഒരു സാധാരണ കീട/രോഗ പ്രശ്നമാണെന്ന് തോന്നുന്നു. എന്റെ ശുപാർശകൾ: 1) രോഗബാധിതമായ ഭാഗങ്ങൾ നീക്കം ചെയ്യുക, 2) ഓർഗാനിക് വേപ്പെണ്ണ സ്പ്രേ പ്രയോഗിക്കുക, 3) നല്ല ജലനിർഗമനം ഉറപ്പാക്കുക, 4) വ്യാപനത്തിനായി സൂക്ഷ്മമായി നിരീക്ഷിക്കുക. ലക്ഷണങ്ങൾ തു���രുകയാണെങ്കിൽ, നിങ്ങളുടെ പ്രാദേശിക കൃഷി ഓഫീസറെ ബന്ധപ്പെടുക.`;
    
    // Check if escalation needed based on severity indicators
    const severeKeywords = ['dying', 'spreading', 'entire crop', 'മരിക്കുന്നു', 'പടരുന്നു'];
    needsEscalation = severeKeywords.some(keyword => 
      question.toLowerCase().includes(keyword) || question.includes(keyword)
    );
    
  } else if (isWeatherQuery) {
    answer = `Current weather conditions for ${context?.location || 'your area'}: Monsoon season is approaching. Recommendations: 1) Prepare drainage systems, 2) Apply pre-monsoon fertilizers, 3) Harvest mature crops, 4) Plan for water collection. Monitor weather forecasts regularly.`;
    answerMl = `${context?.location || 'നിങ്ങളുടെ പ്രദേശത്തിന്റെ'} നിലവിലെ കാലാവസ്ഥാ സാഹചര്യങ്ങൾ: മൺസൂൺ സീസൺ അടുക്കുന്നു. ശുപാർശകൾ: 1) ഡ്രെയിനേജ് സംവിധാനങ്ങൾ തയ്യാറാക്കുക, 2) മൺസൂൺ പൂർവ വളങ്ങൾ പ്രയോഗിക്കുക, 3) പാകമായ വിളകൾ കൊയ്യുക, 4) ജല ശേഖരണത്തിന് പദ്ധതിയിടുക. കാലാവസ്ഥാ പ്രവചനങ്ങൾ പതിവായി നിരീക്ഷിക്കുക.`;
    
  } else {
    answer = `Thank you for your farming question. Based on your query about ${context?.crop || 'your crops'}, I recommend consulting with local agricultural experts for specific guidance. You can also check our knowledge base for detailed articles on farming practices.`;
    answerMl = `നിങ്ങളുടെ കൃഷി ചോദ്യത്തിന് നന്ദി. ${context?.crop || 'നിങ്ങളുടെ വിളകളെ'} കുറിച്ചുള്ള നിങ്ങളുടെ ചോദ്യത്തിന്റെ അടിസ്ഥാനത്തിൽ, പ്രത്യേക മാർഗ്ഗനിർദ്ദേശത്തിനായി പ്രാദേശിക കൃഷി വിദഗ്ധരെ സമീപിക്കാൻ ഞാൻ ശുപാർശ ചെയ്യുന്നു. കൃഷി രീതികളെക്കുറിച്ചുള്ള വിശദമായ ലേഖനങ്ങൾക്കായി നിങ്ങൾക്ക് ഞങ്ങളുടെ വിജ്ഞാന ശേഖരം പരിശോധിക്കാനും കഴിയും.`;
    confidence = 0.6;
  }

  return {
    answer,
    answerMl,
    confidence,
    needsEscalation
  };
}

// Initialize knowledge base data
async function initializeKnowledgeBase() {
  try {
    const pestArticles = [
      {
        id: 'pest_1',
        title: 'Banana Leaf Spot Disease Management',
        titleMl: 'വാഴയിലെ ഇലപ്പുള്ളി രോഗ നിയന്ത്രണം',
        category: 'pest',
        content: 'Complete guide to identifying and treating leaf spot disease in banana plants...',
        contentMl: 'വാഴയിലെ ഇലപ്പുള്ളി രോഗം തിരിച്ചറിയാനും ചികിത്സിക്കാനുമുള്ള സമ്പൂർണ്ണ മാർഗ്ഗനിർദ്ദേശം...',
        severity: 'high',
        crops: ['banana'],
        region: 'kerala'
      },
      {
        id: 'pest_2',
        title: 'Rice Stem Borer Control',
        titleMl: 'നെല്ലിലെ തണ്ടിൽ പുഴു നിയന്ത്രണം',
        category: 'pest',
        content: 'Effective methods to prevent and control stem borer infestation in rice crops...',
        contentMl: 'നെല്ല് വിളയിൽ തണ്ടിൽ പുഴു ബാധ തടയാനും നിയന്ത്രിക്കാനുമുള്ള ഫലപ്രദമായ രീതികൾ...',
        severity: 'medium',
        crops: ['rice'],
        region: 'kerala'
      }
    ];

    await kv.set('knowledge_pest', pestArticles);
    console.log('Initialized knowledge base with pest articles');

  } catch (error) {
    console.log(`Error initializing knowledge base: ${error}`);
  }
}

// Initialize knowledge base on startup
initializeKnowledgeBase();

export default { fetch: app.fetch };
Deno.serve(app.fetch);