// Mock CSV-based user database for demonstration
// In a real application, this would be stored in actual CSV files or a database

export interface UserData {
  id: string;
  username: string;
  mobileNumber: string;
  password: string; // In real app, this would be hashed
  role: 'farmer' | 'admin';
  fullName: string;
  email?: string;
  district?: string;
  createdAt: string;
  lastLogin?: string;
  isActive: boolean;
}

// Mock user database - simulates CSV storage
export const userDatabase: UserData[] = [
  {
    id: '1',
    username: 'farmer1',
    mobileNumber: '9876543210',
    password: 'farmer123', // Would be hashed in real app
    role: 'farmer',
    fullName: 'Ravi Kumar',
    email: 'ravi@example.com',
    district: 'Thiruvananthapuram',
    createdAt: '2024-01-15',
    lastLogin: '2024-03-10',
    isActive: true
  },
  {
    id: '2',
    username: 'admin1',
    mobileNumber: '9876543211',
    password: 'admin123', // Would be hashed in real app
    role: 'admin',
    fullName: 'Dr. Priya Nair',
    email: 'priya.admin@kerala.gov.in',
    district: 'Kottayam',
    createdAt: '2024-01-10',
    lastLogin: '2024-03-12',
    isActive: true
  },
  {
    id: '3',
    username: 'farmer2',
    mobileNumber: '9876543212',
    password: 'pass123', // Would be hashed in real app
    role: 'farmer',
    fullName: 'Sita Menon',
    email: 'sita@example.com',
    district: 'Palakkad',
    createdAt: '2024-02-01',
    lastLogin: '2024-03-11',
    isActive: true
  }
];

// Simulate CSV operations
export class UserCSVDatabase {
  private static data: UserData[] = [...userDatabase];

  // Find user by username or mobile number
  static findUser(identifier: string, role?: 'farmer' | 'admin'): UserData | null {
    const user = this.data.find(user => 
      (user.username === identifier || user.mobileNumber === identifier) &&
      user.isActive &&
      (!role || user.role === role)
    );
    return user || null;
  }

  // Validate user credentials
  static validateCredentials(identifier: string, password: string, role?: 'farmer' | 'admin'): UserData | null {
    const user = this.findUser(identifier, role);
    if (user && user.password === password) { // In real app, compare hashed passwords
      // Update last login
      user.lastLogin = new Date().toISOString().split('T')[0];
      return user;
    }
    return null;
  }

  // Add new user (simulates appending to CSV)
  static addUser(userData: Omit<UserData, 'id' | 'createdAt' | 'isActive'>): UserData {
    const newUser: UserData = {
      ...userData,
      id: (this.data.length + 1).toString(),
      createdAt: new Date().toISOString().split('T')[0],
      isActive: true
    };

    this.data.push(newUser);
    return newUser;
  }

  // Check if username or mobile number already exists
  static userExists(username: string, mobileNumber: string): boolean {
    return this.data.some(user => 
      (user.username === username || user.mobileNumber === mobileNumber) && 
      user.isActive
    );
  }

  // Get all users by role (for admin purposes)
  static getUsersByRole(role: 'farmer' | 'admin'): UserData[] {
    return this.data.filter(user => user.role === role && user.isActive);
  }

  // Update user password (for forgot password functionality)
  static updatePassword(identifier: string, newPassword: string): boolean {
    const user = this.findUser(identifier);
    if (user) {
      user.password = newPassword; // In real app, hash the password
      return true;
    }
    return false;
  }

  // Export to CSV format (simulation)
  static exportToCSV(): string {
    const headers = ['id', 'username', 'mobileNumber', 'password', 'role', 'fullName', 'email', 'district', 'createdAt', 'lastLogin', 'isActive'];
    const csvContent = [
      headers.join(','),
      ...this.data.map(user => [
        user.id,
        user.username,
        user.mobileNumber,
        user.password,
        user.role,
        `"${user.fullName}"`,
        user.email || '',
        user.district || '',
        user.createdAt,
        user.lastLogin || '',
        user.isActive
      ].join(','))
    ].join('\n');
    
    return csvContent;
  }

  // Import from CSV format (simulation)
  static importFromCSV(csvContent: string): boolean {
    try {
      const lines = csvContent.split('\n');
      const headers = lines[0].split(',');
      
      this.data = lines.slice(1).map(line => {
        const values = line.split(',');
        return headers.reduce((obj, header, index) => {
          let value = values[index];
          
          // Handle quoted values
          if (value.startsWith('"') && value.endsWith('"')) {
            value = value.slice(1, -1);
          }
          
          // Convert boolean
          if (header === 'isActive') {
            value = value === 'true';
          }
          
          return { ...obj, [header]: value };
        }, {} as UserData);
      });
      
      return true;
    } catch (error) {
      console.error('Error importing CSV:', error);
      return false;
    }
  }
}

// Generate captcha
export function generateCaptcha(): { question: string; answer: number } {
  const operations = [
    { symbol: '+', func: (a: number, b: number) => a + b },
    { symbol: '-', func: (a: number, b: number) => a - b },
    { symbol: '×', func: (a: number, b: number) => a * b }
  ];

  const a = Math.floor(Math.random() * 10) + 1;
  const b = Math.floor(Math.random() * 10) + 1;
  const operation = operations[Math.floor(Math.random() * operations.length)];

  // Ensure subtraction doesn't result in negative numbers
  const num1 = operation.symbol === '-' ? Math.max(a, b) : a;
  const num2 = operation.symbol === '-' ? Math.min(a, b) : b;

  return {
    question: `${num1} ${operation.symbol} ${num2} = ?`,
    answer: operation.func(num1, num2)
  };
}