// Mock Agricultural Dataset - In production, this would be loaded from the Excel file
export interface CropData {
  crop: string;
  category: string;
  questions: QuestionAnswer[];
}

export interface QuestionAnswer {
  id: string;
  question: string;
  answer: string;
  keywords: string[];
  category: string;
  severity?: 'low' | 'medium' | 'high';
  season?: string;
  region?: string;
}

export const agriculturalDataset: CropData[] = [
  {
    crop: "rice",
    category: "cereal",
    questions: [
      {
        id: "rice_001",
        question: "What is the best time to plant rice?",
        answer: "Rice should be planted during the monsoon season, typically from June to July. For Kharif season, sow between June 15 - July 15. For Rabi season (in some regions), plant between November to December.",
        keywords: ["planting", "time", "season", "monsoon", "kharif", "rabi"],
        category: "planting",
        season: "monsoon"
      },
      {
        id: "rice_002",
        question: "How to control brown spot disease in rice?",
        answer: "Brown spot disease can be controlled by: 1) Apply fungicides like Carbendazim or Propiconazole, 2) Ensure proper field drainage, 3) Use disease-resistant varieties, 4) Apply balanced fertilizer with adequate potassium, 5) Remove infected plant debris.",
        keywords: ["brown spot", "disease", "fungicide", "carbendazim", "drainage"],
        category: "disease",
        severity: "medium"
      },
      {
        id: "rice_003",
        question: "What fertilizer is best for rice cultivation?",
        answer: "For rice cultivation, use NPK fertilizer in ratio 4:2:1. Apply 120 kg Nitrogen, 60 kg Phosphorus, and 40 kg Potassium per hectare. Apply in splits: 50% Nitrogen at transplanting, 25% at tillering, and 25% at panicle initiation.",
        keywords: ["fertilizer", "NPK", "nitrogen", "phosphorus", "potassium", "tillering"],
        category: "fertilizer"
      },
      {
        id: "rice_004",
        question: "How much water does rice need?",
        answer: "Rice requires about 1200-1500 mm of water throughout the growing season. Maintain 2-5 cm standing water in the field during vegetative growth. Drain the field 10-15 days before harvest.",
        keywords: ["water", "irrigation", "standing water", "drainage", "harvest"],
        category: "irrigation"
      }
    ]
  },
  {
    crop: "wheat",
    category: "cereal",
    questions: [
      {
        id: "wheat_001",
        question: "When to sow wheat seeds?",
        answer: "Wheat should be sown in the Rabi season between November 15 to December 15. Late sowing reduces yield significantly. Optimal soil temperature should be 18-20°C at sowing depth.",
        keywords: ["sowing", "rabi", "november", "december", "temperature"],
        category: "planting",
        season: "rabi"
      },
      {
        id: "wheat_002",
        question: "How to control rust disease in wheat?",
        answer: "Control rust disease by: 1) Use resistant varieties like HD2967, HD3086, 2) Spray fungicides like Propiconazole or Tebuconazole, 3) Ensure proper crop rotation, 4) Remove alternate hosts, 5) Apply at first appearance of disease.",
        keywords: ["rust", "disease", "fungicide", "propiconazole", "resistant varieties"],
        category: "disease",
        severity: "high"
      },
      {
        id: "wheat_003",
        question: "What is the recommended seed rate for wheat?",
        answer: "Recommended seed rate for wheat is 100-125 kg per hectare for normal conditions. For late sowing, increase to 125-150 kg per hectare. Use certified seeds with 85-90% germination rate.",
        keywords: ["seed rate", "hectare", "germination", "certified seeds"],
        category: "planting"
      }
    ]
  },
  {
    crop: "maize",
    category: "cereal",
    questions: [
      {
        id: "maize_001",
        question: "Best time to plant maize?",
        answer: "Maize can be grown in both Kharif and Rabi seasons. For Kharif: June-July, for Rabi: November-December. Summer maize can be planted in February-March with assured irrigation.",
        keywords: ["planting", "kharif", "rabi", "summer", "irrigation"],
        category: "planting"
      },
      {
        id: "maize_002",
        question: "How to control fall armyworm in maize?",
        answer: "Control fall armyworm by: 1) Use pheromone traps for monitoring, 2) Spray Chlorantraniliprole or Spinetoram, 3) Release Trichogramma wasps, 4) Maintain field hygiene, 5) Use light traps at night.",
        keywords: ["fall armyworm", "pheromone traps", "chlorantraniliprole", "trichogramma"],
        category: "pest",
        severity: "high"
      }
    ]
  },
  {
    crop: "cotton",
    category: "fiber",
    questions: [
      {
        id: "cotton_001",
        question: "How to control bollworm in cotton?",
        answer: "Control bollworm using IPM approach: 1) Plant Bt cotton varieties, 2) Use pheromone traps, 3) Spray Emamectin benzoate or Indoxacarb, 4) Maintain refuge crops, 5) Monitor regularly during flowering.",
        keywords: ["bollworm", "bt cotton", "pheromone", "emamectin", "refuge"],
        category: "pest",
        severity: "high"
      },
      {
        id: "cotton_002",
        question: "When to apply first irrigation to cotton?",
        answer: "First irrigation should be applied 45-60 days after sowing when plants are well established. Avoid early irrigation to promote deep root development. Subsequently irrigate at 15-20 day intervals.",
        keywords: ["irrigation", "first irrigation", "root development", "intervals"],
        category: "irrigation"
      }
    ]
  },
  {
    crop: "tomato",
    category: "vegetable",
    questions: [
      {
        id: "tomato_001",
        question: "How to control late blight in tomato?",
        answer: "Control late blight by: 1) Use resistant varieties, 2) Apply Metalaxyl + Mancozeb or Cymoxanil + Mancozeb, 3) Ensure proper spacing and ventilation, 4) Avoid overhead irrigation, 5) Remove infected plants immediately.",
        keywords: ["late blight", "metalaxyl", "mancozeb", "spacing", "ventilation"],
        category: "disease",
        severity: "high"
      },
      {
        id: "tomato_002",
        question: "What is the spacing for tomato plants?",
        answer: "For determinate varieties: 60 cm between rows and 30 cm between plants. For indeterminate varieties: 75 cm between rows and 45 cm between plants. Proper spacing ensures good air circulation and light penetration.",
        keywords: ["spacing", "determinate", "indeterminate", "air circulation"],
        category: "planting"
      }
    ]
  },
  {
    crop: "potato",
    category: "vegetable",
    questions: [
      {
        id: "potato_001",
        question: "How to control late blight in potato?",
        answer: "Control late blight using: 1) Spray Metalaxyl-M + Mancozeb preventively, 2) Use certified disease-free seeds, 3) Ensure proper hilling, 4) Avoid excess moisture, 5) Harvest tubers when mature and dry.",
        keywords: ["late blight", "metalaxyl", "certified seeds", "hilling", "moisture"],
        category: "disease",
        severity: "high"
      }
    ]
  }
];

// Common crop names and their variations
export const cropAliases: Record<string, string[]> = {
  "rice": ["paddy", "dhan", "chawal", "nellu", "arisi"],
  "wheat": ["gehun", "godhi", "gahuun"],
  "maize": ["corn", "makka", "makai", "cholam"],
  "cotton": ["kapas", "cotton plant", "patti"],
  "tomato": ["tamatar", "thakkali", "tomatoes"],
  "potato": ["aloo", "batata", "urulaikizhangu"],
  "onion": ["pyaz", "kanda", "vengayam"],
  "sugarcane": ["ganna", "sherdi", "karumbu"]
};

// Disease and pest keywords
export const issueKeywords = {
  diseases: ["disease", "blight", "rust", "rot", "wilt", "spot", "mildew", "virus"],
  pests: ["pest", "insect", "worm", "aphid", "thrips", "mite", "borer", "caterpillar"],
  nutrients: ["fertilizer", "nutrition", "deficiency", "nitrogen", "phosphorus", "potassium"],
  irrigation: ["water", "irrigation", "watering", "moisture", "drainage"],
  planting: ["sowing", "planting", "seed", "germination", "spacing"]
};