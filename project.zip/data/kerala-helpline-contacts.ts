export interface HelplineContact {
  id: string;
  district: string;
  centerName: string;
  helplineNumbers: string[];
  malayalamDistrict?: string;
  malayalamCenter?: string;
}

export const keralaHelplineContacts: HelplineContact[] = [
  {
    id: '1',
    district: 'Thiruvananthapuram',
    malayalamDistrict: 'തിരുവനന്തപുരം',
    centerName: 'Agricultural Extension Centre, Thiruvananthapuram',
    malayalamCenter: 'കാർഷിക വിപുലീകരണ കേന്ദ്രം, തിരുവനന്തപുരം',
    helplineNumbers: ['0471-2302100', '0471-2302101', '9446123456']
  },
  {
    id: '2',
    district: 'Kollam',
    malayalamDistrict: 'കൊല്ലം',
    centerName: 'Krishi Vigyan Kendra, Kollam',
    malayalamCenter: 'കൃഷി വിജ്ഞാൻ കേന്ദ്രം, കൊല്ലം',
    helplineNumbers: ['0474-2741234', '0474-2741235', '9447234567']
  },
  {
    id: '3',
    district: 'Pathanamthitta',
    malayalamDistrict: 'പത്തനംതിട്ട',
    centerName: 'District Agricultural Office, Pathanamthitta',
    malayalamCenter: 'ജില്ലാ കാർഷിക ഓഫീസ്, പത്തനംതിട്ട',
    helplineNumbers: ['0468-2222345', '0468-2222346', '9448345678']
  },
  {
    id: '4',
    district: 'Alappuzha',
    malayalamDistrict: 'ആലപ്പുഴ',
    centerName: 'Agricultural Technology Management Agency, Alappuzha',
    malayalamCenter: 'കാർഷിക സാങ്കേതിക വിദ്യാ മാനേജ്മെന്റ് ഏജൻസി, ആലപ്പുഴ',
    helplineNumbers: ['0477-2234567', '0477-2234568', '9449456789']
  },
  {
    id: '5',
    district: 'Kottayam',
    malayalamDistrict: 'കോട്ടയം',
    centerName: 'Rubber Research Institute, Kottayam',
    malayalamCenter: 'റബ്ബർ ഗവേഷണ ഇൻസ്റ്റിറ്റ്യൂട്ട്, കോട്ടയം',
    helplineNumbers: ['0481-2345678', '0481-2345679', '9450567890']
  },
  {
    id: '6',
    district: 'Idukki',
    malayalamDistrict: 'ഇടുക്കി',
    centerName: 'Spices Board Regional Office, Idukki',
    malayalamCenter: 'മസാല ബോർഡ് പ്രാദേശിക ഓഫീസ്, ഇടുക്കി',
    helplineNumbers: ['04862-234567', '04862-234568', '9451678901']
  },
  {
    id: '7',
    district: 'Ernakulam',
    malayalamDistrict: 'എറണാകുളം',
    centerName: 'Central Marine Fisheries Research Institute, Ernakulam',
    malayalamCenter: 'കേന്ദ്ര സമുദ്ര മത്സ്യബന്ധന ഗവേഷണ ഇൻസ്റ്റിറ്റ്യൂട്ട്, എറണാകുളം',
    helplineNumbers: ['0484-2345678', '0484-2345679', '9452789012']
  },
  {
    id: '8',
    district: 'Thrissur',
    malayalamDistrict: 'തൃശ്ശൂർ',
    centerName: 'Kerala Agricultural University, Thrissur',
    malayalamCenter: 'കേരള കാർഷിക സർവകലാശാല, തൃശ്ശൂർ',
    helplineNumbers: ['0487-2456789', '0487-2456790', '9453890123']
  },
  {
    id: '9',
    district: 'Palakkad',
    malayalamDistrict: 'പാലക്കാട്',
    centerName: 'Rice Research Station, Palakkad',
    malayalamCenter: 'നെല്ല് ഗവേഷണ കേന്ദ്രം, പാലക്കാട്',
    helplineNumbers: ['0491-2567890', '0491-2567891', '9454901234']
  },
  {
    id: '10',
    district: 'Malappuram',
    malayalamDistrict: 'മലപ്പുറം',
    centerName: 'Agricultural Extension Centre, Malappuram',
    malayalamCenter: 'കാർഷിക വിപുലീകരണ കേന്ദ്രം, മലപ്പുറം',
    helplineNumbers: ['0483-2678901', '0483-2678902', '9455012345']
  },
  {
    id: '11',
    district: 'Kozhikode',
    malayalamDistrict: 'കോഴിക്കോട്',
    centerName: 'Coconut Development Board, Kozhikode',
    malayalamCenter: 'തെങ്ങ് വികസന ബോർഡ്, കോഴിക്കോട്',
    helplineNumbers: ['0495-2789012', '0495-2789013', '9456123456']
  },
  {
    id: '12',
    district: 'Wayanad',
    malayalamDistrict: 'വയനാട്',
    centerName: 'Coffee Research Station, Wayanad',
    malayalamCenter: 'കാപ്പി ഗവേഷണ കേന്ദ്രം, വയനാട്',
    helplineNumbers: ['04936-234567', '04936-234568', '9457234567']
  },
  {
    id: '13',
    district: 'Kannur',
    malayalamDistrict: 'കണ്ണൂർ',
    centerName: 'Agricultural Research Station, Kannur',
    malayalamCenter: 'കാർഷിക ഗവേഷണ കേന്ദ്രം, കണ്ണൂർ',
    helplineNumbers: ['0497-2890123', '0497-2890124', '9458345678']
  },
  {
    id: '14',
    district: 'Kasaragod',
    malayalamDistrict: 'കാസർകോട്',
    centerName: 'Cashew Research Station, Kasaragod',
    malayalamCenter: 'കശുവണ്ടി ഗവേഷണ കേന്ദ്രം, കാസർകോട്',
    helplineNumbers: ['04994-234567', '04994-234568', '9459456789']
  }
];

// Helper function to search contacts
export function searchHelplineContacts(searchTerm: string): HelplineContact[] {
  if (!searchTerm.trim()) {
    return keralaHelplineContacts;
  }

  const lowercaseSearch = searchTerm.toLowerCase();
  
  return keralaHelplineContacts.filter(contact => 
    contact.district.toLowerCase().includes(lowercaseSearch) ||
    (contact.malayalamDistrict && contact.malayalamDistrict.includes(searchTerm)) ||
    contact.centerName.toLowerCase().includes(lowercaseSearch) ||
    (contact.malayalamCenter && contact.malayalamCenter.includes(searchTerm))
  );
}