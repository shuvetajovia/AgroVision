import React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { MarketPricesWidget } from './MarketPricesWidget';
import { useLanguage } from './LanguageContext';
import { Wheat, TrendingUp, Construction } from 'lucide-react';

export function CropsPage() {
  const { t } = useLanguage();
  
  return (
    <div className="p-6">
      <div className="text-center mb-8">
        <div className="bg-green-100 p-6 rounded-full w-24 h-24 mx-auto mb-4 flex items-center justify-center">
          <Wheat className="h-12 w-12 text-green-600" />
        </div>
        <h1 className="text-3xl text-green-800 mb-2">{t('crops')} Management</h1>
        <p className="text-green-600">Monitor and manage your crop health, planting schedules, and harvest plans</p>
      </div>

      <Card className="border-green-200 max-w-2xl mx-auto">
        <CardHeader className="bg-green-50 text-center">
          <CardTitle className="flex items-center justify-center text-green-800">
            <Construction className="h-6 w-6 mr-2" />
            Coming Soon
          </CardTitle>
          <CardDescription>This feature is under development</CardDescription>
        </CardHeader>
        <CardContent className="pt-6">
          <div className="space-y-4 text-center">
            <p className="text-green-700">
              The Crops Management section will include:
            </p>
            <div className="grid md:grid-cols-2 gap-4 mt-6">
              <div className="bg-green-50 p-4 rounded-lg">
                <h4 className="text-green-800 mb-2">🌱 Crop Calendar</h4>
                <p className="text-sm text-green-600">Track planting and harvesting schedules</p>
              </div>
              <div className="bg-green-50 p-4 rounded-lg">
                <h4 className="text-green-800 mb-2">🔍 Disease Detection</h4>
                <p className="text-sm text-green-600">AI-powered crop health analysis</p>
              </div>
              <div className="bg-green-50 p-4 rounded-lg">
                <h4 className="text-green-800 mb-2">💧 Irrigation Planning</h4>
                <p className="text-sm text-green-600">Optimize water usage for better yields</p>
              </div>
              <div className="bg-green-50 p-4 rounded-lg">
                <h4 className="text-green-800 mb-2">📊 Yield Tracking</h4>
                <p className="text-sm text-green-600">Monitor and predict crop productivity</p>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

export function MarketPricesPage() {
  const { t } = useLanguage();
  
  return (
    <div className="p-4 md:p-6">
      <div className="text-center mb-8">
        <div className="bg-green-100 p-6 rounded-full w-24 h-24 mx-auto mb-4 flex items-center justify-center">
          <TrendingUp className="h-12 w-12 text-green-600" />
        </div>
        <h1 className="text-2xl md:text-3xl text-green-800 mb-2">{t('marketPrices')}</h1>
        <p className="text-green-600">Real-time agricultural commodity prices and market trends</p>
      </div>

      {/* Main Market Prices Widget */}
      <div className="max-w-4xl mx-auto mb-8">
        <MarketPricesWidget />
      </div>

      {/* Additional Features Coming Soon */}
      <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-4 max-w-4xl mx-auto">
        <Card className="border-green-200">
          <CardContent className="p-4 text-center">
            <div className="bg-green-50 p-3 rounded-lg mb-3">
              <span className="text-2xl">📈</span>
            </div>
            <h4 className="text-green-800 mb-2">Price Trends</h4>
            <p className="text-xs text-green-600">Historical data and predictions</p>
            <div className="mt-2">
              <span className="text-xs bg-amber-100 text-amber-800 px-2 py-1 rounded">Coming Soon</span>
            </div>
          </CardContent>
        </Card>

        <Card className="border-green-200">
          <CardContent className="p-4 text-center">
            <div className="bg-green-50 p-3 rounded-lg mb-3">
              <span className="text-2xl">🏪</span>
            </div>
            <h4 className="text-green-800 mb-2">Local Markets</h4>
            <p className="text-xs text-green-600">Nearby mandis and markets</p>
            <div className="mt-2">
              <span className="text-xs bg-amber-100 text-amber-800 px-2 py-1 rounded">Coming Soon</span>
            </div>
          </CardContent>
        </Card>

        <Card className="border-green-200">
          <CardContent className="p-4 text-center">
            <div className="bg-green-50 p-3 rounded-lg mb-3">
              <span className="text-2xl">💰</span>
            </div>
            <h4 className="text-green-800 mb-2">Profit Calculator</h4>
            <p className="text-xs text-green-600">Calculate potential earnings</p>
            <div className="mt-2">
              <span className="text-xs bg-amber-100 text-amber-800 px-2 py-1 rounded">Coming Soon</span>
            </div>
          </CardContent>
        </Card>

        <Card className="border-green-200">
          <CardContent className="p-4 text-center">
            <div className="bg-green-50 p-3 rounded-lg mb-3">
              <span className="text-2xl">🚚</span>
            </div>
            <h4 className="text-green-800 mb-2">Transportation</h4>
            <p className="text-xs text-green-600">Find logistics partners</p>
            <div className="mt-2">
              <span className="text-xs bg-amber-100 text-amber-800 px-2 py-1 rounded">Coming Soon</span>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}