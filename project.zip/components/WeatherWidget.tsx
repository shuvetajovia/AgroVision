import React, { useState, useEffect } from 'react';
import { Card } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { useLanguage } from './LanguageContext';
import { MapPin, Cloud, Droplets, Wind, Eye, Loader2, AlertCircle, RefreshCw } from 'lucide-react';
import { toast } from 'sonner';

interface WeatherData {
  location: string;
  temperature: number;
  humidity: number;
  windSpeed: number;
  rainfall: number;
  description: string;
  icon: string;
}

export function WeatherWidget() {
  const { t } = useLanguage();
  const [weather, setWeather] = useState<WeatherData | null>(null);
  const [loading, setLoading] = useState(false);
  const [location, setLocation] = useState('');
  const [manualLocation, setManualLocation] = useState('');
  const [showLocationInput, setShowLocationInput] = useState(false);

  // Mock weather data - In production, integrate with actual weather API
  const getMockWeatherData = (locationName: string): WeatherData => {
    const mockData = [
      {
        location: locationName || 'Kerala, India',
        temperature: 28,
        humidity: 78,
        windSpeed: 12,
        rainfall: 65,
        description: 'Partly Cloudy',
        icon: '⛅'
      },
      {
        location: locationName || 'Tamil Nadu, India',
        temperature: 32,
        humidity: 82,
        windSpeed: 8,
        rainfall: 45,
        description: 'Humid',
        icon: '☀️'
      },
      {
        location: locationName || 'Karnataka, India',
        temperature: 26,
        humidity: 75,
        windSpeed: 15,
        rainfall: 80,
        description: 'Light Rain',
        icon: '🌦️'
      }
    ];
    
    return mockData[Math.floor(Math.random() * mockData.length)];
  };

  const detectLocation = async () => {
    setLoading(true);
    try {
      if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(
          async (position) => {
            const { latitude, longitude } = position.coords;
            
            // Mock location name based on coordinates
            const locationName = `${latitude.toFixed(2)}°N, ${longitude.toFixed(2)}°E`;
            setLocation(locationName);
            
            // Simulate API delay
            await new Promise(resolve => setTimeout(resolve, 1000));
            
            const weatherData = getMockWeatherData(locationName);
            setWeather(weatherData);
            setLoading(false);
            
            toast.success('Location detected successfully!');
          },
          (error) => {
            console.error('Geolocation error:', error);
            setLoading(false);
            toast.error('Unable to detect location. Please enter manually.');
            setShowLocationInput(true);
          }
        );
      } else {
        setLoading(false);
        toast.error('Geolocation is not supported by this browser.');
        setShowLocationInput(true);
      }
    } catch (error) {
      setLoading(false);
      toast.error('Failed to detect location.');
      setShowLocationInput(true);
    }
  };

  const fetchWeatherForLocation = async (locationName: string) => {
    setLoading(true);
    try {
      // Simulate API delay
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      const weatherData = getMockWeatherData(locationName);
      setWeather(weatherData);
      setLocation(locationName);
      setLoading(false);
      setShowLocationInput(false);
      
      toast.success('Weather updated successfully!');
    } catch (error) {
      setLoading(false);
      toast.error('Failed to fetch weather data.');
    }
  };

  const handleManualLocationSubmit = () => {
    if (manualLocation.trim()) {
      fetchWeatherForLocation(manualLocation.trim());
      setManualLocation('');
    }
  };

  useEffect(() => {
    // Auto-load weather for default location on component mount
    if (!weather) {
      fetchWeatherForLocation('Kerala, India');
    }
  }, []);

  const refreshWeather = () => {
    if (location) {
      fetchWeatherForLocation(location);
    } else {
      detectLocation();
    }
  };

  return (
    <Card className="p-4 bg-gradient-to-br from-blue-50 to-blue-100 border-blue-200">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center space-x-2">
          <Cloud className="h-5 w-5 text-blue-600" />
          <h3 className="text-lg font-semibold text-blue-900">{t('todayWeather')}</h3>
        </div>
        <Button
          size="sm"
          variant="ghost"
          onClick={refreshWeather}
          disabled={loading}
          className="text-blue-600 hover:bg-blue-200"
        >
          {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : <RefreshCw className="h-4 w-4" />}
        </Button>
      </div>

      {weather ? (
        <div className="space-y-4">
          {/* Location and Temperature */}
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <MapPin className="h-4 w-4 text-blue-600" />
              <span className="text-sm text-blue-800 truncate max-w-32">{weather.location}</span>
            </div>
            <div className="text-right">
              <div className="flex items-center space-x-2">
                <span className="text-2xl">{weather.icon}</span>
                <span className="text-2xl font-bold text-blue-900">{weather.temperature}°C</span>
              </div>
              <span className="text-xs text-blue-700">{weather.description}</span>
            </div>
          </div>

          {/* Weather Details */}
          <div className="grid grid-cols-3 gap-3">
            <div className="text-center p-2 bg-white/50 rounded-lg">
              <Droplets className="h-4 w-4 text-blue-600 mx-auto mb-1" />
              <div className="text-xs text-blue-700">{t('rainfall')}</div>
              <div className="text-sm font-semibold text-blue-900">{weather.rainfall}%</div>
            </div>
            
            <div className="text-center p-2 bg-white/50 rounded-lg">
              <Wind className="h-4 w-4 text-blue-600 mx-auto mb-1" />
              <div className="text-xs text-blue-700">{t('wind')}</div>
              <div className="text-sm font-semibold text-blue-900">{weather.windSpeed} km/h</div>
            </div>
            
            <div className="text-center p-2 bg-white/50 rounded-lg">
              <Eye className="h-4 w-4 text-blue-600 mx-auto mb-1" />
              <div className="text-xs text-blue-700">{t('humidity')}</div>
              <div className="text-sm font-semibold text-blue-900">{weather.humidity}%</div>
            </div>
          </div>
        </div>
      ) : loading ? (
        <div className="flex items-center justify-center py-8">
          <Loader2 className="h-6 w-6 animate-spin text-blue-600 mr-2" />
          <span className="text-blue-700">{t('loading')}</span>
        </div>
      ) : (
        <div className="text-center py-4">
          <AlertCircle className="h-8 w-8 text-blue-600 mx-auto mb-2" />
          <p className="text-blue-700 mb-3">No weather data available</p>
        </div>
      )}

      {/* Location Controls */}
      <div className="mt-4 space-y-2">
        {!showLocationInput ? (
          <div className="flex space-x-2">
            <Button
              size="sm"
              onClick={detectLocation}
              disabled={loading}
              className="flex-1 bg-blue-600 hover:bg-blue-700 text-white"
            >
              <MapPin className="h-3 w-3 mr-1" />
              {t('detectLocation')}
            </Button>
            <Button
              size="sm"
              variant="outline"
              onClick={() => setShowLocationInput(true)}
              className="border-blue-300 text-blue-700 hover:bg-blue-50"
            >
              {t('enterLocation')}
            </Button>
          </div>
        ) : (
          <div className="flex space-x-2">
            <Input
              placeholder="Enter city name..."
              value={manualLocation}
              onChange={(e) => setManualLocation(e.target.value)}
              onKeyPress={(e) => e.key === 'Enter' && handleManualLocationSubmit()}
              className="flex-1 border-blue-300 focus:border-blue-500"
            />
            <Button
              size="sm"
              onClick={handleManualLocationSubmit}
              disabled={!manualLocation.trim() || loading}
              className="bg-blue-600 hover:bg-blue-700 text-white"
            >
              Get Weather
            </Button>
          </div>
        )}
      </div>
    </Card>
  );
}