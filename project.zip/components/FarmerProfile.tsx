import React, { useState, useEffect, useRef } from 'react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Textarea } from './ui/textarea';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { User, MapPin, Square, Wheat, Heart, Save, Edit3, Phone, Calendar, Camera, Upload } from 'lucide-react';
import { useLanguage } from './LanguageContext';
import { toast } from 'sonner@2.0.3';

interface FarmerProfileData {
  name: string;
  age: string;
  phone: string;
  village: string;
  state: string;
  farmSize: string;
  farmUnit: string;
  cropsGrown: string;
  livestock: string;
  livestockDetails: string;
  address: string;
  profilePicture?: string;
}

export function FarmerProfile() {
  const { t } = useLanguage();
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [profile, setProfile] = useState<FarmerProfileData>({
    name: '',
    age: '',
    phone: '',
    village: '',
    state: '',
    farmSize: '',
    farmUnit: 'acres',
    cropsGrown: '',
    livestock: '',
    livestockDetails: '',
    address: '',
    profilePicture: ''
  });
  const [isEditing, setIsEditing] = useState(false);
  const [hasProfile, setHasProfile] = useState(false);

  // Load profile from localStorage on component mount
  useEffect(() => {
    const savedProfile = localStorage.getItem('farmerProfile');
    if (savedProfile) {
      try {
        const parsedProfile = JSON.parse(savedProfile);
        setProfile(parsedProfile);
        setHasProfile(true);
      } catch (error) {
        console.error('Error loading profile:', error);
      }
    }
  }, []);

  const handleInputChange = (field: string, value: string) => {
    setProfile(prev => ({
      ...prev,
      [field]: value
    }));
  };

  const handlePhotoUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      // Check file size (max 5MB)
      if (file.size > 5 * 1024 * 1024) {
        toast.error('File size should be less than 5MB');
        return;
      }

      // Check file type
      if (!file.type.startsWith('image/')) {
        toast.error('Please select a valid image file');
        return;
      }

      const reader = new FileReader();
      reader.onload = (e) => {
        const result = e.target?.result as string;
        setProfile(prev => ({
          ...prev,
          profilePicture: result
        }));
        toast.success(t('photoUploadSuccess'));
      };
      reader.onerror = () => {
        toast.error(t('photoUploadError'));
      };
      reader.readAsDataURL(file);
    }
  };

  const triggerFileInput = () => {
    fileInputRef.current?.click();
  };

  const ProfilePictureSection = ({ isEditMode = false }: { isEditMode?: boolean }) => (
    <div className="flex flex-col items-center mb-8">
      {/* Profile Picture */}
      <div className="relative mb-4">
        <div className="w-32 h-32 rounded-full overflow-hidden bg-green-100 dark:bg-green-900 border-4 border-green-300 dark:border-green-600 shadow-lg flex items-center justify-center">
          {profile.profilePicture ? (
            <img
              src={profile.profilePicture}
              alt="Profile"
              className="w-full h-full object-cover"
            />
          ) : (
            <User className="h-16 w-16 text-green-600 dark:text-green-400" />
          )}
        </div>
        
        {/* Camera icon overlay for edit mode */}
        {isEditMode && (
          <Button
            onClick={triggerFileInput}
            size="sm"
            className="absolute bottom-0 right-0 rounded-full w-10 h-10 bg-green-600 hover:bg-green-700 dark:bg-green-700 dark:hover:bg-green-600 text-white shadow-lg"
            aria-label={t('changePhoto')}
          >
            <Camera className="h-4 w-4" />
          </Button>
        )}
      </div>

      {/* Upload/Change Photo Button */}
      {isEditMode && (
        <div className="text-center">
          <Button
            onClick={triggerFileInput}
            variant="outline"
            className="border-green-600 dark:border-green-500 text-green-600 dark:text-green-400 hover:bg-green-50 dark:hover:bg-green-900/20 mb-2"
          >
            <Upload className="h-4 w-4 mr-2" />
            {profile.profilePicture ? t('changePhoto') : t('uploadPhoto')}
          </Button>
          <p className="text-xs text-green-600 dark:text-green-400">
            {t('selectProfilePhoto')}
          </p>
        </div>
      )}

      {/* Hidden file input */}
      <input
        ref={fileInputRef}
        type="file"
        accept="image/*"
        onChange={handlePhotoUpload}
        className="hidden"
        capture="environment"
      />
    </div>
  );

  const handleSaveProfile = () => {
    // Simple validation
    if (!profile.name || !profile.village || !profile.state) {
      toast.error('Please fill in at least your name and location details');
      return;
    }

    try {
      // Save to localStorage
      localStorage.setItem('farmerProfile', JSON.stringify(profile));
      setHasProfile(true);
      setIsEditing(false);
      toast.success('Profile saved successfully!');
      console.log('Saved profile:', profile);
    } catch (error) {
      toast.error('Failed to save profile. Please try again.');
      console.error('Error saving profile:', error);
    }
  };

  const handleEditProfile = () => {
    setIsEditing(true);
  };

  const handleCancelEdit = () => {
    // Reload profile from localStorage
    const savedProfile = localStorage.getItem('farmerProfile');
    if (savedProfile) {
      try {
        const parsedProfile = JSON.parse(savedProfile);
        setProfile(parsedProfile);
      } catch (error) {
        console.error('Error reloading profile:', error);
      }
    }
    setIsEditing(false);
  };

  const states = [
    'Kerala', 'Tamil Nadu', 'Karnataka', 'Andhra Pradesh', 'Telangana',
    'Maharashtra', 'Gujarat', 'Rajasthan', 'Punjab', 'Haryana',
    'Uttar Pradesh', 'Bihar', 'West Bengal', 'Odisha', 'Jharkhand',
    'Chhattisgarh', 'Madhya Pradesh', 'Assam', 'Himachal Pradesh', 'Uttarakhand'
  ];

  // If profile exists and not editing, show profile card
  if (hasProfile && !isEditing) {
    return (
      <div className="max-w-4xl mx-auto p-6 space-y-6">
        {/* Header with Profile Picture */}
        <div className="text-center mb-8">
          <ProfilePictureSection isEditMode={false} />
          <h1 className="text-3xl text-green-800 dark:text-green-300 mb-2">{t('farmerProfile')}</h1>
          <Button
            onClick={handleEditProfile}
            variant="outline"
            className="border-green-600 dark:border-green-500 text-green-600 dark:text-green-400 hover:bg-green-50 dark:hover:bg-green-900/20"
          >
            <Edit3 className="h-4 w-4 mr-2" />
            {t('edit')} {t('profile')}
          </Button>
        </div>

        {/* Profile Display Cards */}
        <div className="grid md:grid-cols-2 gap-6">
          {/* Personal Information Card */}
          <Card className="border-green-200 dark:border-green-600 bg-white dark:bg-gray-800">
            <CardHeader className="bg-green-50 dark:bg-gray-700">
              <CardTitle className="flex items-center text-green-800 dark:text-green-300">
                <User className="h-5 w-5 mr-2" />
                {t('personalInfo')}
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3 pt-4">
              <div className="flex items-center space-x-3">
                <User className="h-4 w-4 text-green-600 dark:text-green-400" />
                <div>
                  <p className="text-sm text-green-600 dark:text-green-400">{t('name')}</p>
                  <p className="text-base font-semibold text-green-800 dark:text-green-300">{profile.name}</p>
                </div>
              </div>
              {profile.age && (
                <div className="flex items-center space-x-3">
                  <Calendar className="h-4 w-4 text-green-600 dark:text-green-400" />
                  <div>
                    <p className="text-sm text-green-600 dark:text-green-400">{t('age')}</p>
                    <p className="text-base font-semibold text-green-800 dark:text-green-300">{profile.age} years</p>
                  </div>
                </div>
              )}
              {profile.phone && (
                <div className="flex items-center space-x-3">
                  <Phone className="h-4 w-4 text-green-600 dark:text-green-400" />
                  <div>
                    <p className="text-sm text-green-600 dark:text-green-400">{t('phoneNumber')}</p>
                    <p className="text-base font-semibold text-green-800 dark:text-green-300">{profile.phone}</p>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Location Information Card */}
          <Card className="border-green-200 dark:border-green-600 bg-white dark:bg-gray-800">
            <CardHeader className="bg-green-50 dark:bg-gray-700">
              <CardTitle className="flex items-center text-green-800 dark:text-green-300">
                <MapPin className="h-5 w-5 mr-2" />
                {t('location')} Details
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3 pt-4">
              <div className="flex items-center space-x-3">
                <MapPin className="h-4 w-4 text-green-600 dark:text-green-400" />
                <div>
                  <p className="text-sm text-green-600 dark:text-green-400">Location</p>
                  <p className="text-base font-semibold text-green-800 dark:text-green-300">{profile.village}, {profile.state}</p>
                </div>
              </div>
              {profile.address && (
                <div className="flex items-start space-x-3">
                  <MapPin className="h-4 w-4 text-green-600 dark:text-green-400 mt-1" />
                  <div>
                    <p className="text-sm text-green-600 dark:text-green-400">{t('address')}</p>
                    <p className="text-base font-semibold text-green-800 dark:text-green-300">{profile.address}</p>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Farm Information Card */}
          <Card className="border-green-200 dark:border-green-600 bg-white dark:bg-gray-800">
            <CardHeader className="bg-green-50 dark:bg-gray-700">
              <CardTitle className="flex items-center text-green-800 dark:text-green-300">
                <Square className="h-5 w-5 mr-2" />
                {t('farmInfo')}
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3 pt-4">
              {profile.farmSize && (
                <div className="flex items-center space-x-3">
                  <Square className="h-4 w-4 text-green-600 dark:text-green-400" />
                  <div>
                    <p className="text-sm text-green-600 dark:text-green-400">{t('farmSize')}</p>
                    <p className="text-base font-semibold text-green-800 dark:text-green-300">{profile.farmSize} {profile.farmUnit}</p>
                  </div>
                </div>
              )}
              {profile.cropsGrown && (
                <div className="flex items-start space-x-3">
                  <Wheat className="h-4 w-4 text-green-600 dark:text-green-400 mt-1" />
                  <div>
                    <p className="text-sm text-green-600 dark:text-green-400">{t('cropTypes')}</p>
                    <p className="text-base font-semibold text-green-800 dark:text-green-300">{profile.cropsGrown}</p>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Livestock Information Card */}
          {(profile.livestock || profile.livestockDetails) && (
            <Card className="border-green-200 dark:border-green-600 bg-white dark:bg-gray-800">
              <CardHeader className="bg-green-50 dark:bg-gray-700">
                <CardTitle className="flex items-center text-green-800 dark:text-green-300">
                  <Heart className="h-5 w-5 mr-2" />
                  {t('livestock')} Details
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3 pt-4">
                {profile.livestock && (
                  <div className="flex items-center space-x-3">
                    <Heart className="h-4 w-4 text-green-600 dark:text-green-400" />
                    <div>
                      <p className="text-sm text-green-600 dark:text-green-400">Number of Animals</p>
                      <p className="text-base font-semibold text-green-800 dark:text-green-300">{profile.livestock}</p>
                    </div>
                  </div>
                )}
                {profile.livestockDetails && (
                  <div className="flex items-start space-x-3">
                    <Heart className="h-4 w-4 text-green-600 dark:text-green-400 mt-1" />
                    <div>
                      <p className="text-sm text-green-600 dark:text-green-400">Types of {t('livestock')}</p>
                      <p className="text-base font-semibold text-green-800 dark:text-green-300">{profile.livestockDetails}</p>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto p-6 space-y-6">
      {/* Header with Profile Picture Upload */}
      <div className="text-center mb-8">
        <ProfilePictureSection isEditMode={true} />
        <h1 className="text-3xl text-green-800 dark:text-green-300 mb-2">{t('farmerProfile')}</h1>
        <p className="text-green-600 dark:text-green-400">{hasProfile ? 'Edit your profile information' : 'Please fill in your details to get personalized farming advice'}</p>
        {isEditing && hasProfile && (
          <Button
            onClick={handleCancelEdit}
            variant="outline"
            className="mt-3 border-gray-400 dark:border-gray-500 text-gray-600 dark:text-gray-400 hover:bg-gray-50 dark:hover:bg-gray-800"
          >
            {t('cancel')}
          </Button>
        )}
      </div>

      {/* Profile Form */}
      <div className="grid md:grid-cols-2 gap-6">
        {/* Personal Information */}
        <Card className="border-green-200 dark:border-green-600 bg-white dark:bg-gray-800">
          <CardHeader className="bg-green-50 dark:bg-gray-700">
            <CardTitle className="flex items-center text-green-800 dark:text-green-300">
              <User className="h-5 w-5 mr-2" />
              {t('personalInfo')}
            </CardTitle>
            <CardDescription className="dark:text-gray-400">Basic details about yourself</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4 pt-4">
            <div className="space-y-2">
              <Label htmlFor="name" className="text-green-700 dark:text-green-300">{t('name')} *</Label>
              <Input
                id="name"
                type="text"
                placeholder={`Enter your ${t('name').toLowerCase()}`}
                value={profile.name}
                onChange={(e) => handleInputChange('name', e.target.value)}
                className="border-green-200 dark:border-green-600 focus:border-green-400 dark:focus:border-green-400 bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="age" className="text-green-700 dark:text-green-300">{t('age')}</Label>
              <Input
                id="age"
                type="number"
                placeholder={`Enter your ${t('age').toLowerCase()}`}
                value={profile.age}
                onChange={(e) => handleInputChange('age', e.target.value)}
                className="border-green-200 dark:border-green-600 focus:border-green-400 dark:focus:border-green-400 bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100"
                min="18"
                max="100"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="phone" className="text-green-700 dark:text-green-300">{t('phoneNumber')}</Label>
              <Input
                id="phone"
                type="tel"
                placeholder="Enter your phone number"
                value={profile.phone}
                onChange={(e) => handleInputChange('phone', e.target.value)}
                className="border-green-200 dark:border-green-600 focus:border-green-400 dark:focus:border-green-400 bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100"
              />
            </div>
          </CardContent>
        </Card>

        {/* Location Information */}
        <Card className="border-green-200 dark:border-green-600 bg-white dark:bg-gray-800">
          <CardHeader className="bg-green-50 dark:bg-gray-700">
            <CardTitle className="flex items-center text-green-800 dark:text-green-300">
              <MapPin className="h-5 w-5 mr-2" />
              {t('location')} Details
            </CardTitle>
            <CardDescription className="dark:text-gray-400">Where is your farm located?</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4 pt-4">
            <div className="space-y-2">
              <Label htmlFor="village" className="text-green-700 dark:text-green-300">Village/Town *</Label>
              <Input
                id="village"
                type="text"
                placeholder="Enter your village or town name"
                value={profile.village}
                onChange={(e) => handleInputChange('village', e.target.value)}
                className="border-green-200 dark:border-green-600 focus:border-green-400 dark:focus:border-green-400 bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="state" className="text-green-700 dark:text-green-300">State *</Label>
              <Select onValueChange={(value) => handleInputChange('state', value)} value={profile.state}>
                <SelectTrigger className="border-green-200 dark:border-green-600 focus:border-green-400 dark:focus:border-green-400 bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100">
                  <SelectValue placeholder="Select your state" />
                </SelectTrigger>
                <SelectContent>
                  {states.map((state) => (
                    <SelectItem key={state} value={state}>
                      {state}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="address" className="text-green-700 dark:text-green-300">{t('address')}</Label>
              <Textarea
                id="address"
                placeholder="Full address (optional)"
                value={profile.address}
                onChange={(e) => handleInputChange('address', e.target.value)}
                className="border-green-200 dark:border-green-600 focus:border-green-400 dark:focus:border-green-400 bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100 resize-none"
                rows={3}
              />
            </div>
          </CardContent>
        </Card>

        {/* Farm Information */}
        <Card className="border-green-200 dark:border-green-600 bg-white dark:bg-gray-800">
          <CardHeader className="bg-green-50 dark:bg-gray-700">
            <CardTitle className="flex items-center text-green-800 dark:text-green-300">
              <Square className="h-5 w-5 mr-2" />
              {t('farmInfo')}
            </CardTitle>
            <CardDescription className="dark:text-gray-400">Information about your farmland</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4 pt-4">
            <div className="space-y-2">
              <Label htmlFor="farmSize" className="text-green-700 dark:text-green-300">{t('farmSize')}</Label>
              <div className="flex space-x-2">
                <Input
                  id="farmSize"
                  type="number"
                  placeholder="Enter area"
                  value={profile.farmSize}
                  onChange={(e) => handleInputChange('farmSize', e.target.value)}
                  className="border-green-200 dark:border-green-600 focus:border-green-400 dark:focus:border-green-400 bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100"
                  step="0.1"
                  min="0"
                />
                <Select onValueChange={(value) => handleInputChange('farmUnit', value)} value={profile.farmUnit}>
                  <SelectTrigger className="w-32 border-green-200 dark:border-green-600 bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="acres">Acres</SelectItem>
                    <SelectItem value="hectares">Hectares</SelectItem>
                    <SelectItem value="bigha">Bigha</SelectItem>
                    <SelectItem value="cent">Cent</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="cropsGrown" className="text-green-700 dark:text-green-300">{t('cropTypes')}</Label>
              <Textarea
                id="cropsGrown"
                placeholder="e.g., Rice, Wheat, Coconut, Pepper, Vegetables..."
                value={profile.cropsGrown}
                onChange={(e) => handleInputChange('cropsGrown', e.target.value)}
                className="border-green-200 dark:border-green-600 focus:border-green-400 dark:focus:border-green-400 bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100 resize-none"
                rows={3}
              />
            </div>
          </CardContent>
        </Card>

        {/* Livestock Information */}
        <Card className="border-green-200 dark:border-green-600 bg-white dark:bg-gray-800">
          <CardHeader className="bg-green-50 dark:bg-gray-700">
            <CardTitle className="flex items-center text-green-800 dark:text-green-300">
              <Heart className="h-5 w-5 mr-2" />
              {t('livestock')} Details
            </CardTitle>
            <CardDescription className="dark:text-gray-400">Information about your animals (if any)</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4 pt-4">
            <div className="space-y-2">
              <Label htmlFor="livestock" className="text-green-700 dark:text-green-300">Number of {t('livestock')}</Label>
              <Input
                id="livestock"
                type="number"
                placeholder="Total number of animals (0 if none)"
                value={profile.livestock}
                onChange={(e) => handleInputChange('livestock', e.target.value)}
                className="border-green-200 dark:border-green-600 focus:border-green-400 dark:focus:border-green-400 bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100"
                min="0"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="livestockDetails" className="text-green-700 dark:text-green-300">Types of {t('livestock')}</Label>
              <Textarea
                id="livestockDetails"
                placeholder="e.g., Cows, Goats, Poultry, Buffalo... (leave empty if no livestock)"
                value={profile.livestockDetails}
                onChange={(e) => handleInputChange('livestockDetails', e.target.value)}
                className="border-green-200 dark:border-green-600 focus:border-green-400 dark:focus:border-green-400 bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100 resize-none"
                rows={3}
              />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Save Button */}
      <div className="flex justify-center pt-6">
        <Button 
          onClick={handleSaveProfile}
          className="bg-green-600 hover:bg-green-700 dark:bg-green-700 dark:hover:bg-green-600 text-white px-8 py-3"
          size="lg"
        >
          <Save className="h-5 w-5 mr-2" />
          {t('save')} {t('profile')}
        </Button>
      </div>

      {/* Help Text */}
      <div className="text-center text-green-600 dark:text-green-400 bg-green-50 dark:bg-green-900/20 p-4 rounded-lg">
        <p className="mb-2">💡 <strong>Why do we need this information?</strong></p>
        <p>Your profile helps us provide personalized farming advice, weather alerts, and market information specific to your location and crops.</p>
      </div>
    </div>
  );
}