import React, { useState, useRef, useEffect } from 'react';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from './ui/dialog';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { useLanguage } from './LanguageContext';
import { MessageCircle, Send, Bot, User } from 'lucide-react';
import { toast } from 'sonner@2.0.3';

interface Message {
  id: number;
  text: string;
  sender: 'user' | 'ai';
  timestamp: Date;
}

interface TextMessagingModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export function TextMessagingModal({ isOpen, onClose }: TextMessagingModalProps) {
  const { t } = useLanguage();
  const [messages, setMessages] = useState<Message[]>([
    {
      id: 1,
      text: "Hello! I'm your Digital Krishi Officer. I can help you with farming questions, crop diseases, weather advice, and market information. How can I assist you today?",
      sender: 'ai',
      timestamp: new Date()
    }
  ]);
  const [inputMessage, setInputMessage] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  useEffect(() => {
    if (isOpen && inputRef.current) {
      setTimeout(() => {
        inputRef.current?.focus();
      }, 100);
    }
  }, [isOpen]);

  const sendMessage = async () => {
    if (!inputMessage.trim()) return;

    const userMessage: Message = {
      id: Date.now(),
      text: inputMessage.trim(),
      sender: 'user',
      timestamp: new Date()
    };

    setMessages(prev => [...prev, userMessage]);
    setInputMessage('');
    setIsTyping(true);

    // Simulate AI response
    setTimeout(() => {
      const aiResponse = generateAIResponse(userMessage.text);
      const aiMessage: Message = {
        id: Date.now() + 1,
        text: aiResponse,
        sender: 'ai',
        timestamp: new Date()
      };
      
      setMessages(prev => [...prev, aiMessage]);
      setIsTyping(false);
    }, 1500);
  };

  const generateAIResponse = (userInput: string): string => {
    const input = userInput.toLowerCase();
    
    if (input.includes('rice') || input.includes('നെൽ')) {
      return "🌾 Rice farming guidance: For healthy rice cultivation, ensure proper water management with 2-3 cm standing water. Watch for blast disease (brown spots on leaves) and use resistant varieties like Jaya or IR64. Best planting time is June-July for Kharif season.";
    }
    
    if (input.includes('disease') || input.includes('പുഴു') || input.includes('രോഗം')) {
      return "🔍 For crop disease identification, I'd recommend uploading a photo using our 'Send Crop Photos' feature for accurate diagnosis. Common signs include yellowing leaves, spots, wilting, or unusual growth. What specific symptoms are you observing?";
    }
    
    if (input.includes('weather') || input.includes('rain') || input.includes('മഴ')) {
      return "🌧️ Weather update: Monsoon season requires careful water management. Ensure proper drainage to prevent waterlogging. This is ideal time for transplanting rice and planting vegetables like okra, brinjal. Avoid applying fertilizers just before heavy rains.";
    }
    
    if (input.includes('fertilizer') || input.includes('വളം')) {
      return "🌱 Fertilizer guidance: Use NPK 20:10:10 for vegetative growth, 10:20:20 for flowering/fruiting. Apply organic compost for soil health. For rice, apply urea in 3 splits - 25% at transplanting, 50% at tillering, 25% at panicle initiation.";
    }
    
    if (input.includes('market') || input.includes('price') || input.includes('വില')) {
      return "💰 Market information: Current trends show increasing demand for organic produce. Rice prices are stable around ₹25-30/kg. Vegetables like tomato, onion showing good returns. Consider direct marketing to reduce middleman costs.";
    }
    
    if (input.includes('coconut') || input.includes('തെങ്ങ്')) {
      return "🥥 Coconut care: Apply organic manure twice yearly. Watch for red palm weevil - use pheromone traps. Ensure proper drainage during monsoon. For good yield, maintain 3-4 leaves removal per month and apply root feeding with fertilizer.";
    }
    
    // Default response
    return "Thank you for your question! I understand you're asking about farming. Could you please provide more specific details about your crop, location, or the particular issue you're facing? This will help me give you more targeted advice. You can also use voice input or send photos for better assistance.";
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      sendMessage();
    }
  };

  const formatTime = (date: Date) => {
    return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-lg h-[600px] p-0">
        <DialogHeader className="px-6 py-4 border-b border-green-200 bg-green-50">
          <DialogTitle className="flex items-center text-green-800">
            <MessageCircle className="h-5 w-5 mr-2" />
            Chat with AI Assistant
          </DialogTitle>
          <DialogDescription>
            {t('askQuestion')} in your preferred language
          </DialogDescription>
        </DialogHeader>

        {/* Messages Area */}
        <div className="flex-1 overflow-y-auto px-6 py-4 space-y-4" style={{ height: '400px' }}>
          {messages.map((message) => (
            <div
              key={message.id}
              className={`flex ${message.sender === 'user' ? 'justify-end' : 'justify-start'}`}
            >
              <div className={`flex max-w-[80%] ${message.sender === 'user' ? 'flex-row-reverse' : 'flex-row'} items-end space-x-2`}>
                <div className={`flex-shrink-0 w-8 h-8 rounded-full flex items-center justify-center ${
                  message.sender === 'user' 
                    ? 'bg-green-600 ml-2' 
                    : 'bg-green-100 mr-2'
                }`}>
                  {message.sender === 'user' ? (
                    <User className="h-4 w-4 text-white" />
                  ) : (
                    <Bot className="h-4 w-4 text-green-600" />
                  )}
                </div>
                
                <div className={`px-4 py-2 rounded-2xl ${
                  message.sender === 'user'
                    ? 'bg-green-600 text-white'
                    : 'bg-green-100 text-green-800'
                }`}>
                  <p className="text-sm whitespace-pre-wrap">{message.text}</p>
                  <p className={`text-xs mt-1 opacity-70 ${
                    message.sender === 'user' ? 'text-green-100' : 'text-green-600'
                  }`}>
                    {formatTime(message.timestamp)}
                  </p>
                </div>
              </div>
            </div>
          ))}

          {/* Typing Indicator */}
          {isTyping && (
            <div className="flex justify-start">
              <div className="flex items-end space-x-2 max-w-[80%]">
                <div className="flex-shrink-0 w-8 h-8 rounded-full bg-green-100 flex items-center justify-center mr-2">
                  <Bot className="h-4 w-4 text-green-600" />
                </div>
                <div className="bg-green-100 px-4 py-2 rounded-2xl">
                  <div className="flex space-x-1">
                    <div className="w-2 h-2 bg-green-600 rounded-full animate-bounce" style={{ animationDelay: '0ms' }} />
                    <div className="w-2 h-2 bg-green-600 rounded-full animate-bounce" style={{ animationDelay: '150ms' }} />
                    <div className="w-2 h-2 bg-green-600 rounded-full animate-bounce" style={{ animationDelay: '300ms' }} />
                  </div>
                </div>
              </div>
            </div>
          )}
          
          <div ref={messagesEndRef} />
        </div>

        {/* Input Area */}
        <div className="px-6 py-4 border-t border-green-200 bg-green-50">
          <div className="flex space-x-2">
            <Input
              ref={inputRef}
              value={inputMessage}
              onChange={(e) => setInputMessage(e.target.value)}
              onKeyPress={handleKeyPress}
              placeholder="Type your farming question..."
              className="flex-1 border-green-200 focus:border-green-400"
              disabled={isTyping}
            />
            <Button
              onClick={sendMessage}
              disabled={!inputMessage.trim() || isTyping}
              className="bg-green-600 hover:bg-green-700 px-3"
            >
              <Send className="h-4 w-4" />
            </Button>
          </div>
          
          <p className="text-xs text-green-600 mt-2 text-center">
            Press Enter to send • Type in Malayalam or English
          </p>
        </div>
      </DialogContent>
    </Dialog>
  );
}