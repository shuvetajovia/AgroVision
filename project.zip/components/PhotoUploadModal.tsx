import React, { useState, useRef } from 'react';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from './ui/dialog';
import { Button } from './ui/button';
import { Textarea } from './ui/textarea';
import { Card } from './ui/card';
import { Badge } from './ui/badge';
import { Camera, Upload, X, Send, Eye, CheckCircle, AlertTriangle, Info } from 'lucide-react';
import { useLanguage } from './LanguageContext';
import { toast } from 'sonner@2.0.3';

interface AnalysisResult {
  disease: string;
  confidence: number;
  severity: 'low' | 'medium' | 'high';
  recommendations: string[];
  preventiveMeasures: string[];
}

interface PhotoUploadModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export function PhotoUploadModal({ isOpen, onClose }: PhotoUploadModalProps) {
  const { t } = useLanguage();
  const [selectedImages, setSelectedImages] = useState<File[]>([]);
  const [imagePreviews, setImagePreviews] = useState<string[]>([]);
  const [description, setDescription] = useState('');
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [analysisResult, setAnalysisResult] = useState<AnalysisResult | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const checkCameraPermission = async () => {
    try {
      // Check if getUserMedia is supported
      if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
        toast.error('Camera access is not supported in this browser.');
        return false;
      }

      // Check current permission state if supported
      if (navigator.permissions) {
        try {
          const permissionStatus = await navigator.permissions.query({ name: 'camera' as PermissionName });
          
          if (permissionStatus.state === 'denied') {
            toast.error('Camera access denied. Please enable camera permissions in your browser settings and try again.');
            return false;
          }
        } catch (error) {
          // Permission API might not support camera query, continue with direct access
          console.log('Permission query not supported for camera');
        }
      }

      return true;
    } catch (error) {
      console.log('Permission API not supported, will try direct access');
      return true; // Fallback to trying getUserMedia directly
    }
  };

  const captureFromCamera = async () => {
    try {
      // First check permissions
      const hasPermission = await checkCameraPermission();
      if (!hasPermission) return;

      toast.info('Requesting camera access...');

      const stream = await navigator.mediaDevices.getUserMedia({ 
        video: { 
          facingMode: 'environment', // Use back camera on mobile
          width: { ideal: 1920 },
          height: { ideal: 1080 }
        } 
      });

      // Create video element to capture frame
      const video = document.createElement('video');
      video.srcObject = stream;
      video.autoplay = true;
      video.playsInline = true;

      video.onloadedmetadata = () => {
        video.play();
        
        // Wait a bit for camera to adjust
        setTimeout(() => {
          // Create canvas to capture frame
          const canvas = document.createElement('canvas');
          canvas.width = video.videoWidth;
          canvas.height = video.videoHeight;
          
          const ctx = canvas.getContext('2d');
          ctx?.drawImage(video, 0, 0);
          
          // Convert to blob
          canvas.toBlob((blob) => {
            if (blob) {
              const file = new File([blob], `crop-photo-${Date.now()}.jpg`, { type: 'image/jpeg' });
              processSelectedFiles([file]);
              toast.success('📸 Photo captured! Starting AI analysis...');
            }
            
            // Stop camera stream
            stream.getTracks().forEach(track => track.stop());
          }, 'image/jpeg', 0.8);
        }, 1000);
      };

    } catch (error: any) {
      console.error('Camera access error:', error);
      
      if (error.name === 'NotAllowedError') {
        toast.error('Camera access denied. Please click the camera icon in your browser\'s address bar and allow access.');
      } else if (error.name === 'NotFoundError') {
        toast.error('No camera found. Please use the gallery upload option instead.');
      } else if (error.name === 'NotReadableError') {
        toast.error('Camera is being used by another application. Please close other apps and try again.');
      } else {
        toast.error('Unable to access camera. Please try uploading from gallery instead.');
      }
    }
  };

  const handleFileSelect = (event: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(event.target.files || []);
    processSelectedFiles(files);
  };

  const processSelectedFiles = (files: File[]) => {
    if (files.length === 0) return;

    // Validate file types
    const validFiles = files.filter(file => file.type.startsWith('image/'));
    if (validFiles.length !== files.length) {
      toast.error('Please select only image files');
      return;
    }

    // Limit to 3 images max
    const limitedFiles = validFiles.slice(0, 3);
    if (limitedFiles.length < validFiles.length) {
      toast.warning('Maximum 3 images allowed. First 3 selected.');
    }

    setSelectedImages(prev => [...prev, ...limitedFiles].slice(0, 3));

    // Create previews
    limitedFiles.forEach(file => {
      const reader = new FileReader();
      reader.onload = (e) => {
        setImagePreviews(prev => [...prev, e.target?.result as string]);
      };
      reader.readAsDataURL(file);
    });

    toast.success(`${limitedFiles.length} image(s) selected`);
    
    // Auto-analyze after a short delay to allow images to load
    setTimeout(() => {
      if (limitedFiles.length > 0) {
        autoAnalyzeImages();
      }
    }, 1000);
  };

  const removeImage = (index: number) => {
    setSelectedImages(prev => prev.filter((_, i) => i !== index));
    setImagePreviews(prev => prev.filter((_, i) => i !== index));
  };

  // Mock analysis results - In production, this would call actual AI service
  const getMockAnalysisResult = (): AnalysisResult => {
    const diseases = [
      {
        disease: 'Brown Leaf Spot',
        confidence: 85,
        severity: 'medium' as const,
        recommendations: [
          'Apply fungicide spray immediately',
          'Remove affected leaves and burn them',
          'Improve field drainage to reduce humidity',
          'Apply balanced fertilizer to strengthen plants'
        ],
        preventiveMeasures: [
          'Maintain proper field hygiene',
          'Use disease-resistant varieties',
          'Apply preventive fungicide sprays',
          'Ensure adequate spacing between plants'
        ]
      },
      {
        disease: 'Nutrient Deficiency (Nitrogen)',
        confidence: 92,
        severity: 'low' as const,
        recommendations: [
          'Apply nitrogen-rich fertilizer (Urea 46%)',
          'Use organic compost or manure',
          'Consider foliar spray of liquid nitrogen',
          'Monitor soil pH levels'
        ],
        preventiveMeasures: [
          'Regular soil testing',
          'Balanced fertilizer application',
          'Use of green manure crops',
          'Proper crop rotation'
        ]
      },
      {
        disease: 'Bacterial Blight',
        confidence: 78,
        severity: 'high' as const,
        recommendations: [
          'Apply copper-based bactericide immediately',
          'Remove and destroy infected plants',
          'Avoid overhead irrigation',
          'Apply streptomycin sulfate spray'
        ],
        preventiveMeasures: [
          'Use certified disease-free seeds',
          'Maintain field sanitation',
          'Avoid working in wet fields',
          'Practice crop rotation'
        ]
      }
    ];
    
    return diseases[Math.floor(Math.random() * diseases.length)];
  };

  const analyzeImages = async () => {
    if (selectedImages.length === 0) {
      toast.error('Please select at least one image');
      return;
    }

    setIsAnalyzing(true);
    setAnalysisResult(null);

    // Simulate AI analysis delay
    setTimeout(() => {
      const result = getMockAnalysisResult();
      setAnalysisResult(result);
      setIsAnalyzing(false);
      toast.success('Analysis complete! Check the recommendations below.');
    }, 3000);
  };

  const autoAnalyzeImages = async () => {
    if (selectedImages.length === 0) {
      return;
    }

    setIsAnalyzing(true);
    setAnalysisResult(null);
    toast.info('🔍 Analyzing your crop images with AI...');

    // Simulate realistic AI analysis stages
    setTimeout(() => {
      toast.info('🧠 Detecting crop diseases and health issues...');
    }, 800);

    setTimeout(() => {
      toast.info('📊 Generating personalized recommendations...');
    }, 1600);

    setTimeout(() => {
      const result = getMockAnalysisResult();
      setAnalysisResult(result);
      setIsAnalyzing(false);
      toast.success('🎯 AI Analysis complete! Recommendations are ready.');
    }, 2500);
  };

  const handleClose = () => {
    setSelectedImages([]);
    setImagePreviews([]);
    setDescription('');
    setIsAnalyzing(false);
    setAnalysisResult(null);
    onClose();
  };

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case 'high': return 'bg-red-100 text-red-800 border-red-300';
      case 'medium': return 'bg-yellow-100 text-yellow-800 border-yellow-300';
      case 'low': return 'bg-green-100 text-green-800 border-green-300';
      default: return 'bg-gray-100 text-gray-800 border-gray-300';
    }
  };

  const getSeverityIcon = (severity: string) => {
    switch (severity) {
      case 'high': return <AlertTriangle className="h-4 w-4" />;
      case 'medium': return <Info className="h-4 w-4" />;
      case 'low': return <CheckCircle className="h-4 w-4" />;
      default: return <Info className="h-4 w-4" />;
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={handleClose}>
      <DialogContent className="sm:max-w-2xl max-h-[80vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center text-green-800">
            <Camera className="h-5 w-5 mr-2" />
            {t('uploadCropPhoto')}
          </DialogTitle>
          <DialogDescription>
            Upload photos of your crops for AI-powered disease detection and health analysis.
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-6">
          {/* Upload Buttons */}
          <div className="flex flex-col sm:flex-row gap-3">
            <Button
              onClick={captureFromCamera}
              className="flex-1 bg-green-600 hover:bg-green-700"
              disabled={isAnalyzing}
            >
              <Camera className="h-4 w-4 mr-2" />
              Take Photo
            </Button>
            
            <Button
              onClick={() => fileInputRef.current?.click()}
              variant="outline"
              className="flex-1 border-green-600 text-green-600 hover:bg-green-50"
              disabled={isAnalyzing}
            >
              <Upload className="h-4 w-4 mr-2" />
              Upload from Gallery
            </Button>
          </div>

          {/* Hidden File Input */}
          <input
            ref={fileInputRef}
            type="file"
            accept="image/*"
            multiple
            onChange={handleFileSelect}
            className="hidden"
          />

          {/* Image Previews */}
          {imagePreviews.length > 0 && (
            <div className="space-y-3">
              <h4 className="text-green-800">Selected Images ({imagePreviews.length}/3)</h4>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {imagePreviews.map((preview, index) => (
                  <div key={index} className="relative group">
                    <img
                      src={preview}
                      alt={`Crop photo ${index + 1}`}
                      className="w-full h-48 object-cover rounded-lg border border-green-200"
                    />
                    <Button
                      size="icon"
                      variant="destructive"
                      onClick={() => removeImage(index)}
                      className="absolute top-2 right-2 h-6 w-6 opacity-0 group-hover:opacity-100 transition-opacity"
                    >
                      <X className="h-3 w-3" />
                    </Button>
                    <div className="absolute bottom-2 left-2 bg-black bg-opacity-50 text-white px-2 py-1 rounded text-xs">
                      Image {index + 1}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Description */}
          <div className="space-y-2">
            <label className="text-green-700">
              Additional Description (Optional)
            </label>
            <Textarea
              placeholder="Describe what you're seeing on your crops - yellowing leaves, spots, wilting, etc. This helps our AI provide better analysis."
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              className="border-green-200 focus:border-green-400"
              rows={3}
            />
          </div>

          {/* AI Analysis Progress */}
          {isAnalyzing && (
            <Card className="p-6 border-blue-200 bg-blue-50">
              <div className="flex items-center justify-center space-x-3">
                <div className="w-8 h-8 border-3 border-blue-600 border-t-transparent rounded-full animate-spin"></div>
                <div>
                  <h4 className="font-medium text-blue-800">AI Analysis in Progress</h4>
                  <p className="text-sm text-blue-600">Analyzing crop health and detecting diseases...</p>
                </div>
              </div>
              <div className="mt-4 bg-white p-3 rounded-lg">
                <div className="flex justify-between text-xs text-blue-600 mb-2">
                  <span>Processing image...</span>
                  <span>{Math.min(100, Math.round((Date.now() % 3000) / 30))}%</span>
                </div>
                <div className="w-full bg-blue-200 rounded-full h-2">
                  <div 
                    className="bg-blue-600 h-2 rounded-full transition-all duration-300"
                    style={{ width: `${Math.min(100, Math.round((Date.now() % 3000) / 30))}%` }}
                  ></div>
                </div>
              </div>
            </Card>
          )}

          {/* Analysis Results */}
          {analysisResult && (
            <Card className="p-4 border-green-200 bg-green-50">
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <h3 className="text-lg font-semibold text-green-800">{t('analysisResult')}</h3>
                  <Badge className={`flex items-center space-x-1 ${getSeverityColor(analysisResult.severity)}`}>
                    {getSeverityIcon(analysisResult.severity)}
                    <span className="capitalize">{analysisResult.severity} Risk</span>
                  </Badge>
                </div>

                <div className="bg-white p-4 rounded-lg border border-green-200">
                  <div className="flex items-center justify-between mb-2">
                    <h4 className="text-base font-medium text-green-800">{analysisResult.disease}</h4>
                    <span className="text-sm text-green-600">{analysisResult.confidence}% confidence</span>
                  </div>
                </div>

                <div className="grid md:grid-cols-2 gap-4">
                  {/* Immediate Recommendations */}
                  <div className="bg-white p-4 rounded-lg border border-green-200">
                    <h5 className="text-sm font-semibold text-green-800 mb-3 flex items-center">
                      <CheckCircle className="h-4 w-4 mr-2 text-green-600" />
                      Immediate Actions
                    </h5>
                    <ul className="space-y-2">
                      {analysisResult.recommendations.map((rec, index) => (
                        <li key={index} className="text-sm text-green-700 flex items-start">
                          <span className="inline-block w-2 h-2 bg-green-500 rounded-full mt-2 mr-3 flex-shrink-0"></span>
                          {rec}
                        </li>
                      ))}
                    </ul>
                  </div>

                  {/* Preventive Measures */}
                  <div className="bg-white p-4 rounded-lg border border-green-200">
                    <h5 className="text-sm font-semibold text-green-800 mb-3 flex items-center">
                      <Info className="h-4 w-4 mr-2 text-blue-600" />
                      Prevention Tips
                    </h5>
                    <ul className="space-y-2">
                      {analysisResult.preventiveMeasures.map((measure, index) => (
                        <li key={index} className="text-sm text-green-700 flex items-start">
                          <span className="inline-block w-2 h-2 bg-blue-500 rounded-full mt-2 mr-3 flex-shrink-0"></span>
                          {measure}
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>

                {/* Action Buttons */}
                <div className="flex justify-between">
                  <Button
                    variant="outline"
                    onClick={() => setAnalysisResult(null)}
                    className="text-green-600 border-green-300"
                  >
                    Analyze Another Photo
                  </Button>
                  
                  <Button
                    onClick={handleClose}
                    className="bg-green-600 hover:bg-green-700"
                  >
                    Save Recommendations
                  </Button>
                </div>
              </div>
            </Card>
          )}

          {/* Manual Analyze Button - Only show if images selected but not analyzed/analyzing */}
          {!analysisResult && !isAnalyzing && selectedImages.length > 0 && (
            <div className="flex justify-end space-x-3">
              <Button
                variant="outline"
                onClick={handleClose}
              >
                {t('cancel')}
              </Button>
              
              <Button
                onClick={analyzeImages}
                className="bg-green-600 hover:bg-green-700"
              >
                <Eye className="h-4 w-4 mr-2" />
                Re-analyze Crops
              </Button>
            </div>
          )}

          {/* Cancel Button - Only show when no images */}
          {!analysisResult && !isAnalyzing && selectedImages.length === 0 && (
            <div className="flex justify-end">
              <Button
                variant="outline"
                onClick={handleClose}
              >
                {t('cancel')}
              </Button>
            </div>
          )}
        </div>

        {/* Help Text */}
        {!analysisResult && (
          <div className="bg-green-50 p-4 rounded-lg">
            <p className="text-sm text-green-700 mb-2">
              📸 <strong>{t('uploadTips')}:</strong>
            </p>
            <ul className="text-sm text-green-600 space-y-1 list-disc list-inside">
              <li>Take clear, well-lit photos of affected plant parts</li>
              <li>Include close-ups of leaves, stems, or fruits showing symptoms</li>
              <li>Take photos from multiple angles if possible</li>
              <li>Avoid blurry or dark images for accurate diagnosis</li>
            </ul>
            
            <div className="mt-3 p-3 bg-blue-50 border border-blue-200 rounded">
              <p className="text-xs text-blue-700">
                🔒 <strong>Privacy:</strong> Your photos are processed securely and are not stored permanently. 
                Camera access is only used when you click "Take Photo".
              </p>
            </div>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}