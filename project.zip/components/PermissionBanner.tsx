import React, { useState, useEffect } from 'react';
import { Alert, AlertDescription } from './ui/alert';
import { Button } from './ui/button';
import { Camera, Mic, AlertTriangle, CheckCircle } from 'lucide-react';

interface PermissionStatus {
  camera: 'granted' | 'denied' | 'prompt' | 'unknown';
  microphone: 'granted' | 'denied' | 'prompt' | 'unknown';
}

export function PermissionBanner() {
  const [permissions, setPermissions] = useState<PermissionStatus>({
    camera: 'unknown',
    microphone: 'unknown'
  });
  const [showBanner, setShowBanner] = useState(false);

  const checkPermissions = async () => {
    try {
      if (!navigator.permissions) {
        setPermissions({ camera: 'unknown', microphone: 'unknown' });
        return;
      }

      const cameraPermission = await navigator.permissions.query({ name: 'camera' as PermissionName });
      const microphonePermission = await navigator.permissions.query({ name: 'microphone' as PermissionName });

      const newPermissions = {
        camera: cameraPermission.state,
        microphone: microphonePermission.state
      };

      setPermissions(newPermissions);
      
      // Show banner if any permission is denied
      setShowBanner(
        newPermissions.camera === 'denied' || 
        newPermissions.microphone === 'denied'
      );

      // Listen for permission changes
      cameraPermission.onchange = () => checkPermissions();
      microphonePermission.onchange = () => checkPermissions();

    } catch (error) {
      console.log('Permission API not supported');
      setPermissions({ camera: 'unknown', microphone: 'unknown' });
    }
  };

  useEffect(() => {
    checkPermissions();
  }, []);

  const requestPermissions = async () => {
    try {
      let requestsMade = false;

      // Request camera permission if needed
      if (permissions.camera === 'denied' || permissions.camera === 'prompt') {
        try {
          const stream = await navigator.mediaDevices.getUserMedia({ video: true });
          stream.getTracks().forEach(track => track.stop());
          requestsMade = true;
        } catch (error: any) {
          console.log('Camera permission denied:', error.name);
        }
      }

      // Request microphone permission if needed
      if (permissions.microphone === 'denied' || permissions.microphone === 'prompt') {
        try {
          const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
          stream.getTracks().forEach(track => track.stop());
          requestsMade = true;
        } catch (error: any) {
          console.log('Microphone permission denied:', error.name);
        }
      }

      // Recheck permissions after request
      if (requestsMade) {
        setTimeout(checkPermissions, 500);
      }
    } catch (error) {
      console.error('Permission request failed:', error);
    }
  };

  const openBrowserSettings = () => {
    alert(`To enable camera and microphone access:

1. Look for the camera/microphone icon in your browser's address bar
2. Click it and select "Allow"
3. Or go to your browser settings:
   - Chrome: Settings > Privacy and security > Site Settings > Camera/Microphone
   - Firefox: Preferences > Privacy & Security > Permissions
   - Safari: Preferences > Websites > Camera/Microphone

4. Refresh the page after changing settings`);
  };

  if (!showBanner) return null;

  return (
    <div className="fixed top-0 left-0 right-0 z-50 p-4">
      <Alert className="max-w-4xl mx-auto bg-amber-50 border-amber-200">
        <AlertTriangle className="h-4 w-4 text-amber-600" />
        <AlertDescription className="flex items-center justify-between">
          <div className="flex-1">
            <p className="text-amber-800 mb-2">
              <strong>Camera and Microphone Access Needed</strong>
            </p>
            <p className="text-amber-700 text-sm">
              To use voice input and photo capture features, please enable camera and microphone permissions.
            </p>
            <div className="flex items-center space-x-4 mt-2 text-sm">
              <div className="flex items-center space-x-1">
                <Camera className="h-3 w-3" />
                <span className={permissions.camera === 'granted' ? 'text-green-600' : 'text-red-600'}>
                  Camera: {permissions.camera === 'granted' ? 'Allowed' : 'Blocked'}
                </span>
                {permissions.camera === 'granted' && <CheckCircle className="h-3 w-3 text-green-600" />}
              </div>
              <div className="flex items-center space-x-1">
                <Mic className="h-3 w-3" />
                <span className={permissions.microphone === 'granted' ? 'text-green-600' : 'text-red-600'}>
                  Microphone: {permissions.microphone === 'granted' ? 'Allowed' : 'Blocked'}
                </span>
                {permissions.microphone === 'granted' && <CheckCircle className="h-3 w-3 text-green-600" />}
              </div>
            </div>
          </div>
          
          <div className="flex space-x-2 ml-4">
            <Button
              size="sm"
              variant="outline"
              onClick={openBrowserSettings}
              className="text-amber-700 border-amber-300 hover:bg-amber-100"
            >
              How to Enable
            </Button>
            <Button
              size="sm"
              onClick={requestPermissions}
              className="bg-amber-600 hover:bg-amber-700 text-white"
            >
              Request Access
            </Button>
            <Button
              size="sm"
              variant="ghost"
              onClick={() => setShowBanner(false)}
              className="text-amber-600 hover:bg-amber-100"
            >
              Dismiss
            </Button>
          </div>
        </AlertDescription>
      </Alert>
    </div>
  );
}