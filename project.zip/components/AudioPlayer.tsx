import React, { useState, useRef, useEffect } from 'react';
import { Button } from './ui/button';
import { Card, CardContent } from './ui/card';
import { Separator } from './ui/separator';
import { Progress } from './ui/progress';
import { 
  Play, 
  Pause, 
  Square, 
  Volume2, 
  VolumeX, 
  X,
  SkipBack,
  SkipForward,
  ChevronDown,
  ChevronUp
} from 'lucide-react';

interface AudioPlayerProps {
  isVisible: boolean;
  text: string;
  language: string;
  onClose: () => void;
}

const SPEECH_LANG_MAP = {
  'en': 'en-US',
  'hi': 'hi-IN',
  'ml': 'ml-IN',
  'ta': 'ta-IN'
};

export function AudioPlayer({ isVisible, text, language, onClose }: AudioPlayerProps) {
  const [isPlaying, setIsPlaying] = useState(false);
  const [isPaused, setIsPaused] = useState(false);
  const [progress, setProgress] = useState(0);
  const [volume, setVolume] = useState(1);
  const [isMuted, setIsMuted] = useState(false);
  const [isMinimized, setIsMinimized] = useState(false);
  const [currentWordIndex, setCurrentWordIndex] = useState(0);
  const [duration, setDuration] = useState(0);
  const [currentTime, setCurrentTime] = useState(0);

  const utteranceRef = useRef<SpeechSynthesisUtterance | null>(null);
  const progressIntervalRef = useRef<NodeJS.Timeout | null>(null);
  const wordsRef = useRef<string[]>([]);

  // Initialize words array
  useEffect(() => {
    wordsRef.current = text.split(' ').filter(word => word.trim().length > 0);
    setCurrentWordIndex(0);
    setProgress(0);
    setCurrentTime(0);
    
    // Estimate duration (approximate 150 words per minute for speech)
    const estimatedDuration = (wordsRef.current.length / 150) * 60; // in seconds
    setDuration(estimatedDuration);
  }, [text]);

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      if (utteranceRef.current) {
        window.speechSynthesis.cancel();
      }
      if (progressIntervalRef.current) {
        clearInterval(progressIntervalRef.current);
      }
    };
  }, []);

  const play = () => {
    if (isPaused && utteranceRef.current) {
      // Resume existing utterance
      window.speechSynthesis.resume();
      setIsPlaying(true);
      setIsPaused(false);
      startProgressTracking();
    } else {
      // Create new utterance
      window.speechSynthesis.cancel(); // Cancel any existing speech
      
      const utterance = new SpeechSynthesisUtterance(text);
      utterance.lang = SPEECH_LANG_MAP[language as keyof typeof SPEECH_LANG_MAP] || 'en-US';
      utterance.rate = 0.8;
      utterance.pitch = 1;
      utterance.volume = isMuted ? 0 : volume;

      utterance.onstart = () => {
        setIsPlaying(true);
        setIsPaused(false);
        setCurrentWordIndex(0);
        startProgressTracking();
      };

      utterance.onend = () => {
        setIsPlaying(false);
        setIsPaused(false);
        setProgress(100);
        setCurrentWordIndex(wordsRef.current.length - 1);
        setCurrentTime(duration);
        stopProgressTracking();
      };

      utterance.onerror = () => {
        setIsPlaying(false);
        setIsPaused(false);
        stopProgressTracking();
      };

      utterance.onpause = () => {
        setIsPlaying(false);
        setIsPaused(true);
        stopProgressTracking();
      };

      utterance.onresume = () => {
        setIsPlaying(true);
        setIsPaused(false);
        startProgressTracking();
      };

      utteranceRef.current = utterance;
      window.speechSynthesis.speak(utterance);
    }
  };

  const pause = () => {
    if (window.speechSynthesis.speaking && !window.speechSynthesis.paused) {
      window.speechSynthesis.pause();
      setIsPlaying(false);
      setIsPaused(true);
      stopProgressTracking();
    }
  };

  const stop = () => {
    window.speechSynthesis.cancel();
    setIsPlaying(false);
    setIsPaused(false);
    setProgress(0);
    setCurrentWordIndex(0);
    setCurrentTime(0);
    stopProgressTracking();
    utteranceRef.current = null;
  };

  const startProgressTracking = () => {
    if (progressIntervalRef.current) {
      clearInterval(progressIntervalRef.current);
    }

    progressIntervalRef.current = setInterval(() => {
      const wordsPerSecond = wordsRef.current.length / duration;
      const increment = (100 / wordsRef.current.length) * wordsPerSecond;
      const timeIncrement = 1; // 1 second

      setProgress(prev => {
        const newProgress = Math.min(prev + increment, 100);
        return newProgress;
      });

      setCurrentTime(prev => {
        const newTime = Math.min(prev + timeIncrement, duration);
        return newTime;
      });

      setCurrentWordIndex(prev => {
        const newIndex = Math.min(
          Math.floor((progress / 100) * wordsRef.current.length),
          wordsRef.current.length - 1
        );
        return newIndex;
      });
    }, 1000);
  };

  const stopProgressTracking = () => {
    if (progressIntervalRef.current) {
      clearInterval(progressIntervalRef.current);
      progressIntervalRef.current = null;
    }
  };

  const toggleMute = () => {
    setIsMuted(!isMuted);
    if (utteranceRef.current) {
      // Note: SpeechSynthesis doesn't support volume change during playback
      // Would need to restart with new volume
    }
  };

  const handleProgressClick = (e: React.MouseEvent<HTMLDivElement>) => {
    // This is approximate since SpeechSynthesis doesn't support seeking
    const rect = e.currentTarget.getBoundingClientRect();
    const clickPosition = (e.clientX - rect.left) / rect.width;
    const newProgress = clickPosition * 100;
    
    // For speech synthesis, we'd need to restart from a calculated position
    // This is a simplified implementation
    if (window.speechSynthesis.speaking) {
      stop();
      // In a real implementation, you'd calculate the text portion to speak from
    }
  };

  const formatTime = (seconds: number): string => {
    const minutes = Math.floor(seconds / 60);
    const remainingSeconds = Math.floor(seconds % 60);
    return `${minutes}:${remainingSeconds.toString().padStart(2, '0')}`;
  };

  const getLanguageName = (code: string): string => {
    const names = {
      'en': 'English',
      'hi': 'हिन्दी',
      'ml': 'മലയാളം',
      'ta': 'தமிழ்'
    };
    return names[code as keyof typeof names] || code;
  };

  if (!isVisible) return null;

  return (
    <div className="fixed bottom-0 left-0 right-0 z-50 bg-white dark:bg-gray-800 border-t border-gray-200 dark:border-gray-700 shadow-lg">
      <Card className="rounded-none border-0 shadow-none">
        <CardContent className="p-0">
          {/* Minimize/Expand Button */}
          <div className="flex items-center justify-between p-2 bg-gray-50 dark:bg-gray-700">
            <div className="flex items-center gap-2">
              <Volume2 className="h-4 w-4 text-gray-600 dark:text-gray-400" />
              <span className="text-sm text-gray-600 dark:text-gray-400">
                Audio Player - {getLanguageName(language)}
              </span>
            </div>
            <div className="flex items-center gap-1">
              <Button
                onClick={() => setIsMinimized(!isMinimized)}
                variant="ghost"
                size="sm"
                className="h-6 w-6 p-0"
              >
                {isMinimized ? (
                  <ChevronUp className="h-3 w-3" />
                ) : (
                  <ChevronDown className="h-3 w-3" />
                )}
              </Button>
              <Button
                onClick={onClose}
                variant="ghost"
                size="sm"
                className="h-6 w-6 p-0 text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-200"
              >
                <X className="h-3 w-3" />
              </Button>
            </div>
          </div>

          {!isMinimized && (
            <>
              {/* Progress Bar */}
              <div className="px-4 py-2">
                <div 
                  className="cursor-pointer"
                  onClick={handleProgressClick}
                >
                  <Progress 
                    value={progress} 
                    className="h-2 mb-2"
                  />
                </div>
                <div className="flex justify-between text-xs text-gray-500 dark:text-gray-400">
                  <span>{formatTime(currentTime)}</span>
                  <span>{formatTime(duration)}</span>
                </div>
              </div>

              <Separator />

              {/* Controls */}
              <div className="flex items-center justify-center gap-3 p-4">
                {/* Skip Back (restart) */}
                <Button
                  onClick={() => {
                    stop();
                    setTimeout(play, 100);
                  }}
                  variant="outline"
                  size="sm"
                  className="h-8 w-8 p-0"
                  disabled={!text}
                >
                  <SkipBack className="h-4 w-4" />
                </Button>

                {/* Play/Pause */}
                <Button
                  onClick={isPlaying ? pause : play}
                  size="sm"
                  className="h-10 w-10 p-0 bg-green-600 hover:bg-green-700 dark:bg-green-700 dark:hover:bg-green-600"
                  disabled={!text}
                >
                  {isPlaying ? (
                    <Pause className="h-5 w-5" />
                  ) : (
                    <Play className="h-5 w-5" />
                  )}
                </Button>

                {/* Stop */}
                <Button
                  onClick={stop}
                  variant="outline"
                  size="sm"
                  className="h-8 w-8 p-0"
                  disabled={!isPlaying && !isPaused}
                >
                  <Square className="h-4 w-4" />
                </Button>

                {/* Volume */}
                <div className="flex items-center gap-2 ml-4">
                  <Button
                    onClick={toggleMute}
                    variant="ghost"
                    size="sm"
                    className="h-8 w-8 p-0"
                  >
                    {isMuted ? (
                      <VolumeX className="h-4 w-4" />
                    ) : (
                      <Volume2 className="h-4 w-4" />
                    )}
                  </Button>
                  <input
                    type="range"
                    min="0"
                    max="1"
                    step="0.1"
                    value={isMuted ? 0 : volume}
                    onChange={(e) => {
                      const newVolume = parseFloat(e.target.value);
                      setVolume(newVolume);
                      setIsMuted(newVolume === 0);
                    }}
                    className="w-16 h-1 bg-gray-300 rounded-lg appearance-none cursor-pointer dark:bg-gray-600"
                  />
                </div>
              </div>

              {/* Current Text Display */}
              {!isMinimized && text && (
                <>
                  <Separator />
                  <div className="p-4 max-h-32 overflow-y-auto">
                    <div className="text-sm leading-relaxed">
                      {wordsRef.current.map((word, index) => (
                        <span
                          key={index}
                          className={`${
                            index === currentWordIndex
                              ? 'bg-green-200 dark:bg-green-800 text-green-800 dark:text-green-200'
                              : index < currentWordIndex
                              ? 'text-gray-400 dark:text-gray-500'
                              : 'text-gray-700 dark:text-gray-300'
                          } transition-colors duration-300`}
                        >
                          {word}{' '}
                        </span>
                      ))}
                    </div>
                  </div>
                </>
              )}
            </>
          )}

          {/* Minimized State */}
          {isMinimized && (
            <div className="flex items-center justify-between p-3">
              <div className="flex items-center gap-3">
                <Button
                  onClick={isPlaying ? pause : play}
                  size="sm"
                  className="h-8 w-8 p-0 bg-green-600 hover:bg-green-700 dark:bg-green-700 dark:hover:bg-green-600"
                  disabled={!text}
                >
                  {isPlaying ? (
                    <Pause className="h-4 w-4" />
                  ) : (
                    <Play className="h-4 w-4" />
                  )}
                </Button>
                <div className="flex-1 max-w-xs">
                  <Progress value={progress} className="h-1" />
                </div>
              </div>
              <div className="text-xs text-gray-500 dark:text-gray-400">
                {formatTime(currentTime)} / {formatTime(duration)}
              </div>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}