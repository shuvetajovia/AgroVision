import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Badge } from './ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { ImageWithFallback } from './figma/ImageWithFallback';
import { getQueryHistory, submitQueryFeedback, type FarmerQuery } from '../utils/api';
import { 
  Search, 
  Filter, 
  Calendar,
  MessageCircle,
  Image,
  Mic,
  CheckCircle,
  Clock,
  AlertTriangle,
  ThumbsUp,
  ThumbsDown
} from 'lucide-react';

export function QueryHistory() {
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [typeFilter, setTypeFilter] = useState('all');
  const [queries, setQueries] = useState<FarmerQuery[]>([]);
  const [loading, setLoading] = useState(true);

  const farmerId = 'farmer_001'; // In real app, this would come from auth

  useEffect(() => {
    loadQueryHistory();
  }, []);

  const loadQueryHistory = async () => {
    try {
      setLoading(true);
      const history = await getQueryHistory(farmerId);
      setQueries(history);
    } catch (error) {
      console.error('Failed to load query history:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleFeedback = async (queryId: string, satisfaction: 'positive' | 'negative') => {
    try {
      await submitQueryFeedback(queryId, satisfaction);
      // Update local state
      setQueries(prev => prev.map(q => 
        q.id === queryId ? { ...q, satisfaction } : q
      ));
    } catch (error) {
      console.error('Failed to submit feedback:', error);
    }
  };

  // Mock queries for demo
  const mockQueries = [
    {
      id: '1',
      farmerId: 'farmer_001',
      question: 'What pesticide should I use for leaf spot disease in banana plants?',
      questionMl: 'വാഴയിലെ ഇലപ്പുള്ളി രോഗത്തിന് ഏത് കീടനാശിനി ഉപയോഗിക്കണം?',
      answer: 'Use Copper oxychloride fungicide (2g/L) and remove affected leaves immediately.',
      answerMl: 'കോപ്പർ ഓക്സിക്ലോറൈഡ് കുമിൾനാശിനി (2g/L) ഉപയോഗിക്കുകയും രോഗബാധിതമായ ഇലകൾ ഉടനെ നീക്കം ചെയ്യുകയും ചെയ്യുക.',
      timestamp: '2024-01-15T10:30:00',
      status: 'resolved',
      type: 'image',
      confidence: 0.9,
      satisfaction: 'positive',
      context: { location: 'Wayanad, Kerala', crop: 'Banana', category: 'Pest Control' }
    },
    {
      id: '2',
      farmerId: 'farmer_001',
      question: 'When is the best time to plant rice this season?',
      questionMl: 'ഈ സീസണിൽ നെല്ല് നടാൻ ഏറ്റവും നല്ല സമയം എപ്പോഴാണ്?',
      answer: 'For Kharif season, plant between June 15 - July 15 depending on monsoon arrival.',
      answerMl: 'ഖരീഫ് സീസണിൽ, മൺസൂൺ വരവിനെ ആശ്രയിച്ച് ജൂൺ 15 - ജൂലൈ 15 വരെ നടുക.',
      timestamp: '2024-01-14T14:15:00',
      status: 'resolved',
      type: 'voice',
      confidence: 0.8,
      satisfaction: 'positive',
      context: { location: 'Palakkad, Kerala', crop: 'Rice', category: 'Crop Management' }
    },
    {
      id: '3',
      farmerId: 'farmer_001',
      question: 'My coconut trees are showing yellowing leaves. What could be the problem?',
      questionMl: 'എന്റെ തെങ്ങുകളിൽ ഇലകൾ മഞ്ഞളായി വരുന്നു. എന്താകാം പ്രശ്നം?',
      answer: 'This could indicate nutrient deficiency or root wilt disease. Expert consultation recommended.',
      answerMl: 'ഇത് പോഷകക്കുറവോ റൂട്ട് വിൽറ്റ് രോഗമോ ആകാം. വിദഗ്ധ പരിശോധന ശുപാർശ ചെയ്യുന്നു.',
      timestamp: '2024-01-12T16:20:00',
      status: 'escalated',
      type: 'image',
      confidence: 0.6,
      satisfaction: null,
      context: { location: 'Kollam, Kerala', crop: 'Coconut', category: 'Pest Control' }
    }
  ];

  // Use real queries if available, otherwise use mock data for demo
  const displayQueries = queries.length > 0 ? queries : mockQueries;

  const filteredQueries = displayQueries.filter(query => {
    const matchesSearch = query.question.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         (query.questionMl && query.questionMl.includes(searchQuery));
    const matchesStatus = statusFilter === 'all' || query.status === statusFilter;
    const matchesType = typeFilter === 'all' || query.type === typeFilter;
    
    return matchesSearch && matchesStatus && matchesType;
  });

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'resolved':
        return <CheckCircle className="h-4 w-4 text-green-500" />;
      case 'pending':
        return <Clock className="h-4 w-4 text-orange-500" />;
      case 'escalated':
        return <AlertTriangle className="h-4 w-4 text-red-500" />;
      default:
        return null;
    }
  };

  const getTypeIcon = (type: string) => {
    switch (type) {
      case 'text':
        return <MessageCircle className="h-4 w-4" />;
      case 'voice':
        return <Mic className="h-4 w-4" />;
      case 'image':
        return <Image className="h-4 w-4" />;
      default:
        return null;
    }
  };

  const stats = {
    total: displayQueries.length,
    resolved: displayQueries.filter(q => q.status === 'resolved').length,
    pending: displayQueries.filter(q => q.status === 'pending').length,
    escalated: displayQueries.filter(q => q.status === 'escalated').length,
  };

  return (
    <div className="container mx-auto px-4 py-8">
      {/* Header */}
      <div className="mb-8">
        <h1 className="text-3xl font-bold mb-4">Query History</h1>
        <p className="text-muted-foreground mb-6">
          Track all your farming queries and responses from the AI assistant
        </p>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
        <Card>
          <CardContent className="p-4 text-center">
            <p className="text-2xl font-bold">{stats.total}</p>
            <p className="text-sm text-muted-foreground">Total Queries</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 text-center">
            <p className="text-2xl font-bold text-green-600">{stats.resolved}</p>
            <p className="text-sm text-muted-foreground">Resolved</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 text-center">
            <p className="text-2xl font-bold text-orange-600">{stats.pending}</p>
            <p className="text-sm text-muted-foreground">Pending</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 text-center">
            <p className="text-2xl font-bold text-red-600">{stats.escalated}</p>
            <p className="text-sm text-muted-foreground">Escalated</p>
          </CardContent>
        </Card>
      </div>

      {/* Filters */}
      <Card className="mb-6">
        <CardContent className="p-4">
          <div className="flex flex-wrap gap-4">
            <div className="flex-1 min-w-64">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="Search queries..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-10"
                />
              </div>
            </div>
            
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger className="w-40">
                <SelectValue placeholder="Status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Status</SelectItem>
                <SelectItem value="resolved">Resolved</SelectItem>
                <SelectItem value="pending">Pending</SelectItem>
                <SelectItem value="escalated">Escalated</SelectItem>
              </SelectContent>
            </Select>

            <Select value={typeFilter} onValueChange={setTypeFilter}>
              <SelectTrigger className="w-40">
                <SelectValue placeholder="Type" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Types</SelectItem>
                <SelectItem value="text">Text</SelectItem>
                <SelectItem value="voice">Voice</SelectItem>
                <SelectItem value="image">Image</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {/* Query List */}
      <div className="space-y-4">
        {filteredQueries.map((query) => (
          <Card key={query.id}>
            <CardContent className="p-6">
              <div className="flex items-start justify-between mb-4">
                <div className="flex items-center space-x-3">
                  {getTypeIcon(query.type)}
                  <div>
                    <Badge variant="outline">{query.context?.category || 'General'}</Badge>
                    <div className="flex items-center space-x-2 mt-1">
                      <span className="text-sm text-muted-foreground">{query.context?.location || 'Kerala'}</span>
                      <span className="text-sm text-muted-foreground">•</span>
                      <span className="text-sm text-muted-foreground">{query.context?.crop || 'Mixed'}</span>
                    </div>
                  </div>
                </div>
                
                <div className="flex items-center space-x-2">
                  {getStatusIcon(query.status)}
                  <Badge 
                    variant={
                      query.status === 'resolved' ? 'default' : 
                      query.status === 'pending' ? 'secondary' : 'destructive'
                    }
                  >
                    {query.status}
                  </Badge>
                  <span className="text-sm text-muted-foreground">
                    {new Date(query.timestamp).toLocaleDateString()}
                  </span>
                </div>
              </div>

              <div className="space-y-4">
                {/* Question */}
                <div className="bg-muted p-4 rounded-lg">
                  <p className="font-medium mb-1">Question:</p>
                  <p className="text-sm mb-2">{query.question}</p>
                  {query.questionMl && (
                    <p className="text-sm text-muted-foreground italic">{query.questionMl}</p>
                  )}
                </div>

                {/* Answer */}
                {query.status !== 'pending' && query.answer && (
                  <div className="bg-green-50 p-4 rounded-lg">
                    <p className="font-medium mb-1">Answer:</p>
                    <p className="text-sm mb-2">{query.answer}</p>
                    {query.answerMl && (
                      <p className="text-sm text-muted-foreground italic">{query.answerMl}</p>
                    )}
                  </div>
                )}

                {/* Satisfaction */}
                {query.status === 'resolved' && (
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-muted-foreground">Was this helpful?</span>
                    <div className="flex items-center space-x-2">
                      {query.satisfaction === 'positive' ? (
                        <ThumbsUp className="h-4 w-4 text-green-500 fill-current" />
                      ) : query.satisfaction === 'negative' ? (
                        <ThumbsDown className="h-4 w-4 text-red-500 fill-current" />
                      ) : (
                        <div className="flex space-x-1">
                          <Button 
                            variant="ghost" 
                            size="sm"
                            onClick={() => handleFeedback(query.id, 'positive')}
                          >
                            <ThumbsUp className="h-4 w-4" />
                          </Button>
                          <Button 
                            variant="ghost" 
                            size="sm"
                            onClick={() => handleFeedback(query.id, 'negative')}
                          >
                            <ThumbsDown className="h-4 w-4" />
                          </Button>
                        </div>
                      )}
                    </div>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {filteredQueries.length === 0 && (
        <Card>
          <CardContent className="p-12 text-center">
            <MessageCircle className="h-12 w-12 mx-auto mb-4 text-muted-foreground" />
            <p className="text-muted-foreground">
              {loading ? 'Loading query history...' : 'No queries found matching your filters.'}
            </p>
          </CardContent>
        </Card>
      )}
    </div>
  );
}