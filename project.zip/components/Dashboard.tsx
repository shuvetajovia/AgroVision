import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Button } from './ui/button';
import { ImageWithFallback } from './figma/ImageWithFallback';
import { 
  MessageCircle, 
  TrendingUp, 
  Users, 
  CheckCircle, 
  AlertTriangle,
  CloudRain,
  Bug,
  DollarSign,
  Calendar
} from 'lucide-react';

export function Dashboard() {
  const stats = [
    { title: 'Queries Resolved', value: '2,847', icon: CheckCircle, color: 'text-green-600' },
    { title: 'Active Farmers', value: '1,234', icon: Users, color: 'text-blue-600' },
    { title: 'Expert Escalations', value: '89', icon: AlertTriangle, color: 'text-orange-600' },
    { title: 'Success Rate', value: '94.2%', icon: TrendingUp, color: 'text-green-600' },
  ];

  const recentQueries = [
    {
      farmer: 'Ravi Kumar',
      location: 'Wayanad, Kerala',
      query: 'വാഴയിൽ ഇലപ്പുള്ളിരോഗം വന്നിട്ടുണ്ട്. എന്താണ് ചെയ്യേണ്ടത്?',
      queryEn: 'Banana plant has leaf spot disease. What should I do?',
      status: 'resolved',
      time: '2 minutes ago'
    },
    {
      farmer: 'Meera Nair',
      location: 'Palakkad, Kerala',
      query: 'മഴക്കാലത്ത് നെല്ല് കൃഷിക്ക് എന്ത് മുൻകരുതലുകൾ എടുക്കണം?',
      queryEn: 'What precautions should be taken for rice cultivation during monsoon?',
      status: 'in-progress',
      time: '15 minutes ago'
    },
    {
      farmer: 'Suresh Babu',
      location: 'Thrissur, Kerala',
      query: 'തെങ്ങിന് പുതിയ രോഗം കണ്ടു. ചിത്രം അയച്ചിട്ടുണ്ട്.',
      queryEn: 'New disease spotted in coconut trees. Image sent.',
      status: 'escalated',
      time: '1 hour ago'
    }
  ];

  const weatherAlerts = [
    { type: 'rain', message: 'Heavy rainfall expected in Wayanad - Take precautions for banana crops', severity: 'high' },
    { type: 'temperature', message: 'High temperature alert for Palakkad - Ensure adequate irrigation', severity: 'medium' },
  ];

  return (
    <div className="container mx-auto px-4 py-8">
      {/* Hero Section */}
      <div className="grid md:grid-cols-2 gap-8 mb-8">
        <div className="space-y-6">
          <div>
            <h1 className="text-3xl font-bold mb-4">AI-Powered Farming Assistant</h1>
            <p className="text-muted-foreground mb-6">
              Get instant, expert-level advice for all your farming needs. Ask questions in Malayalam, 
              upload crop images, and receive personalized guidance based on your location and crop type.
            </p>
            <div className="flex flex-wrap gap-3">
              <Button className="flex items-center space-x-2">
                <MessageCircle className="h-4 w-4" />
                <span>Start Chat</span>
              </Button>
              <Button variant="outline">Learn More</Button>
            </div>
          </div>
          
          <div className="grid grid-cols-2 gap-4">
            <Card>
              <CardContent className="p-4">
                <div className="flex items-center space-x-2">
                  <CloudRain className="h-5 w-5 text-blue-500" />
                  <div>
                    <p className="text-sm font-medium">Weather Alert</p>
                    <p className="text-xs text-muted-foreground">3 active alerts</p>
                  </div>
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardContent className="p-4">
                <div className="flex items-center space-x-2">
                  <Bug className="h-5 w-5 text-red-500" />
                  <div>
                    <p className="text-sm font-medium">Pest Alerts</p>
                    <p className="text-xs text-muted-foreground">2 new advisories</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
        
        <div className="relative">
          <ImageWithFallback
            src="https://images.unsplash.com/photo-1707721690544-781fe6ede937?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmYXJtZXIlMjBhZ3JpY3VsdHVyZSUyMGluZGlhbiUyMGNyb3BzfGVufDF8fHx8MTc1NzgzNDAxNHww&ixlib=rb-4.1.0&q=80&w=1080"
            alt="Farmer using technology"
            className="w-full h-64 object-cover rounded-lg"
          />
        </div>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
        {stats.map((stat, index) => {
          const Icon = stat.icon;
          return (
            <Card key={index}>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-muted-foreground">{stat.title}</p>
                    <p className="text-2xl font-bold">{stat.value}</p>
                  </div>
                  <Icon className={`h-8 w-8 ${stat.color}`} />
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* Recent Activity and Weather Alerts */}
      <div className="grid md:grid-cols-3 gap-6">
        <div className="md:col-span-2">
          <Card>
            <CardHeader>
              <CardTitle>Recent Farmer Queries</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {recentQueries.map((query, index) => (
                  <div key={index} className="border border-border rounded-lg p-4">
                    <div className="flex items-start justify-between mb-2">
                      <div>
                        <p className="font-medium">{query.farmer}</p>
                        <p className="text-sm text-muted-foreground">{query.location}</p>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Badge 
                          variant={
                            query.status === 'resolved' ? 'default' : 
                            query.status === 'in-progress' ? 'secondary' : 'destructive'
                          }
                        >
                          {query.status}
                        </Badge>
                        <span className="text-xs text-muted-foreground">{query.time}</span>
                      </div>
                    </div>
                    <div className="space-y-1">
                      <p className="text-sm bg-muted p-2 rounded">{query.query}</p>
                      <p className="text-xs text-muted-foreground italic">{query.queryEn}</p>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <CloudRain className="h-5 w-5" />
                <span>Weather Alerts</span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {weatherAlerts.map((alert, index) => (
                  <div key={index} className={`p-3 rounded-lg border ${
                    alert.severity === 'high' ? 'border-red-200 bg-red-50' : 'border-orange-200 bg-orange-50'
                  }`}>
                    <p className="text-sm">{alert.message}</p>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <DollarSign className="h-5 w-5" />
                <span>Market Prices</span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                <div className="flex justify-between items-center">
                  <span className="text-sm">Rice (per quintal)</span>
                  <span className="font-medium">₹2,450</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm">Banana (per dozen)</span>
                  <span className="font-medium">₹45</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm">Coconut (per 100)</span>
                  <span className="font-medium">₹2,800</span>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}