import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Input } from './ui/input';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Separator } from './ui/separator';
import { 
  Phone, 
  Search, 
  Volume2, 
  MapPin,
  Users,
  PhoneCall,
  Headphones
} from 'lucide-react';
import { useLanguage } from './LanguageContext';
import { toast } from 'sonner@2.0.3';
import { keralaHelplineContacts, searchHelplineContacts, type HelplineContact } from '../data/kerala-helpline-contacts';

export function HelplineContacts() {
  const { t, language } = useLanguage();
  const [searchTerm, setSearchTerm] = useState('');
  const [filteredContacts, setFilteredContacts] = useState<HelplineContact[]>(keralaHelplineContacts);
  const [isSearching, setIsSearching] = useState(false);

  // Update filtered contacts when search term changes
  useEffect(() => {
    const timer = setTimeout(() => {
      const results = searchHelplineContacts(searchTerm);
      setFilteredContacts(results);
      setIsSearching(false);
    }, 300);

    return () => clearTimeout(timer);
  }, [searchTerm]);

  // Handle search input change
  const handleSearchChange = (value: string) => {
    setSearchTerm(value);
    setIsSearching(true);
  };

  // Speak district and center name for accessibility
  const speakDistrictInfo = (contact: HelplineContact) => {
    if ('speechSynthesis' in window) {
      const text = language === 'ml' && contact.malayalamDistrict && contact.malayalamCenter
        ? `${contact.malayalamDistrict}, ${contact.malayalamCenter}`
        : `${contact.district}, ${contact.centerName}`;
      
      const utterance = new SpeechSynthesisUtterance(text);
      utterance.lang = language === 'ml' ? 'ml-IN' : 'en-IN';
      utterance.rate = 0.8;
      utterance.pitch = 1;
      
      window.speechSynthesis.cancel(); // Stop any current speech
      window.speechSynthesis.speak(utterance);
      
      toast.success(language === 'ml' ? 'ജില്ലയുടെ വിവരങ്ങൾ വായിക്കുന്നു' : 'Reading district information');
    } else {
      toast.error('Speech synthesis not supported in this browser');
    }
  };

  // Format phone number for display
  const formatPhoneNumber = (number: string): string => {
    // Remove any non-digit characters for tel: link
    return number.replace(/\D/g, '');
  };

  // Handle phone call
  const handlePhoneCall = (number: string, district: string) => {
    toast.success(`${t('callNow')}: ${number}`);
  };

  return (
    <div className="max-w-6xl mx-auto p-4 space-y-6">
      {/* Header */}
      <Card className="border-green-200 dark:border-green-600 bg-white dark:bg-gray-800">
        <CardHeader className="text-center bg-gradient-to-r from-green-50 to-blue-50 dark:from-gray-700 dark:to-gray-600">
          <CardTitle className="text-2xl text-green-800 dark:text-green-300 flex items-center justify-center">
            <Headphones className="h-7 w-7 mr-3" />
            {t('helplineContacts')}
          </CardTitle>
          <CardDescription className="text-lg dark:text-gray-300 max-w-2xl mx-auto">
            {t('findYourDistrict')}
          </CardDescription>
        </CardHeader>
      </Card>

      {/* Search Bar */}
      <Card className="border-green-200 dark:border-green-600 bg-white dark:bg-gray-800">
        <CardContent className="p-6">
          <div className="relative">
            <div className="relative flex-1">
              <Input
                placeholder={t('searchDistrict')}
                value={searchTerm}
                onChange={(e) => handleSearchChange(e.target.value)}
                className="text-lg h-14 pl-12 pr-4 border-green-200 dark:border-green-600 focus:border-green-400 dark:focus:border-green-400 bg-white dark:bg-gray-700"
              />
              <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 h-5 w-5 text-green-500 dark:text-green-400" />
            </div>
            
            {/* Search Results Summary */}
            <div className="mt-4 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <MapPin className="h-4 w-4 text-green-600 dark:text-green-400" />
                <span className="text-sm text-green-700 dark:text-green-300">
                  {isSearching ? 'Searching...' : `${filteredContacts.length} districts found`}
                </span>
              </div>
              
              {searchTerm && (
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => {
                    setSearchTerm('');
                    setFilteredContacts(keralaHelplineContacts);
                  }}
                  className="text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-200"
                >
                  Clear
                </Button>
              )}
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Contact Cards */}
      {filteredContacts.length > 0 ? (
        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-2">
          {filteredContacts.map((contact) => (
            <Card key={contact.id} className="border-green-200 dark:border-green-600 bg-white dark:bg-gray-800 hover:shadow-lg transition-shadow">
              <CardContent className="p-6">
                <div className="space-y-4">
                  {/* District Header */}
                  <div className="flex items-start justify-between gap-3">
                    <div className="flex-1">
                      <h3 className="text-xl font-semibold text-green-800 dark:text-green-300 mb-1">
                        {language === 'ml' && contact.malayalamDistrict ? contact.malayalamDistrict : contact.district}
                      </h3>
                      {language === 'ml' && contact.malayalamDistrict && (
                        <p className="text-sm text-gray-600 dark:text-gray-400">
                          {contact.district}
                        </p>
                      )}
                    </div>
                    
                    {/* Speaker Button for Accessibility */}
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => speakDistrictInfo(contact)}
                      className="text-green-600 hover:text-green-700 dark:text-green-400 dark:hover:text-green-300 shrink-0"
                      title={t('speakDistrictName')}
                    >
                      <Volume2 className="h-4 w-4" />
                    </Button>
                  </div>

                  <Separator />

                  {/* Center Information */}
                  <div className="space-y-2">
                    <div className="flex items-start gap-2">
                      <Users className="h-4 w-4 text-blue-600 dark:text-blue-400 mt-1 shrink-0" />
                      <div>
                        <p className="text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                          {t('centerName')}:
                        </p>
                        <p className="text-sm text-blue-800 dark:text-blue-300 leading-relaxed">
                          {language === 'ml' && contact.malayalamCenter ? contact.malayalamCenter : contact.centerName}
                        </p>
                        {language === 'ml' && contact.malayalamCenter && (
                          <p className="text-xs text-gray-500 dark:text-gray-400 mt-1">
                            {contact.centerName}
                          </p>
                        )}
                      </div>
                    </div>
                  </div>

                  <Separator />

                  {/* Contact Numbers */}
                  <div className="space-y-3">
                    <div className="flex items-center gap-2">
                      <Phone className="h-4 w-4 text-green-600 dark:text-green-400" />
                      <span className="text-sm font-medium text-gray-700 dark:text-gray-300">
                        {t('contactNumbers')}:
                      </span>
                    </div>
                    
                    <div className="grid gap-2">
                      {contact.helplineNumbers.map((number, index) => (
                        <div key={index} className="flex items-center justify-between bg-green-50 dark:bg-green-900/20 p-3 rounded-lg">
                          <div className="flex items-center gap-3">
                            <PhoneCall className="h-4 w-4 text-green-600 dark:text-green-400" />
                            <span className="font-mono text-lg text-green-800 dark:text-green-300">
                              {number}
                            </span>
                          </div>
                          
                          <a
                            href={`tel:${formatPhoneNumber(number)}`}
                            onClick={() => handlePhoneCall(number, contact.district)}
                          >
                            <Button
                              size="sm"
                              className="bg-green-600 hover:bg-green-700 text-white"
                            >
                              <Phone className="h-4 w-4 mr-2" />
                              {t('callNow')}
                            </Button>
                          </a>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* District Badge */}
                  <div className="flex justify-end">
                    <Badge className="bg-blue-100 text-blue-800 border-blue-300 dark:bg-blue-900 dark:text-blue-300">
                      Kerala
                    </Badge>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      ) : (
        /* No Results */
        <Card className="border-gray-200 dark:border-gray-600 bg-white dark:bg-gray-800">
          <CardContent className="p-12 text-center">
            <div className="space-y-4">
              <div className="mx-auto w-16 h-16 bg-gray-100 dark:bg-gray-700 rounded-full flex items-center justify-center">
                <Search className="h-8 w-8 text-gray-400" />
              </div>
              <h3 className="text-lg font-medium text-gray-900 dark:text-gray-100">
                {t('noResultsFound')}
              </h3>
              <p className="text-gray-500 dark:text-gray-400 max-w-md mx-auto">
                {t('tryDifferentSearch')}
              </p>
              <Button
                variant="outline"
                onClick={() => {
                  setSearchTerm('');
                  setFilteredContacts(keralaHelplineContacts);
                }}
                className="mt-4"
              >
                Show All Districts
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Help Information */}
      <Card className="border-blue-200 dark:border-blue-600 bg-blue-50 dark:bg-blue-900/20">
        <CardContent className="p-6">
          <div className="text-sm text-blue-700 dark:text-blue-300">
            <p className="mb-3 font-medium">
              📞 How to use the helpline:
            </p>
            <ul className="space-y-2 list-disc list-inside">
              <li>Search for your district using the search bar above</li>
              <li>Click the speaker icon to hear the district name spoken aloud</li>
              <li>Tap "Call Now" to directly dial the helpline numbers</li>
              <li>Agricultural experts are available during office hours (9 AM - 5 PM)</li>
              <li>For emergency assistance, contact multiple numbers if the first one is busy</li>
            </ul>
            
            <div className="mt-4 p-3 bg-blue-100 dark:bg-blue-900/40 rounded-lg">
              <p className="font-medium mb-1">🎯 Tip for better assistance:</p>
              <p className="text-xs">Have your farm location, crop details, and specific questions ready when calling.</p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}