import React from 'react';
import { Button } from './ui/button';
import { LanguageSwitcher } from './LanguageSwitcher';
import { useLanguage } from './LanguageContext';
import { ThemeSwitcher } from './ThemeSwitcher';
import { 
  Home, 
  User, 
  Calendar, 
  TrendingUp, 
  LogOut,
  Leaf,
  Menu,
  X,
  MessageSquare,
  Headphones
} from 'lucide-react';
import logo from 'figma:asset/5dc22ea35ca935a57743fd34fcb015d3e9e72d8f.png';

interface FarmerSidebarProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  onLogout: () => void;
  isOpen: boolean;
  setIsOpen: (open: boolean) => void;
}

export function FarmerSidebar({ 
  activeTab, 
  setActiveTab, 
  onLogout, 
  isOpen, 
  setIsOpen 
}: FarmerSidebarProps) {
  const { t } = useLanguage();
  
  const navItems = [
    { id: 'dashboard', label: t('dashboard'), icon: Home },
    { id: 'qa', label: 'Ask Expert', icon: MessageSquare },
    { id: 'helpline', label: t('helpline'), icon: Headphones },
    { id: 'profile', label: t('profile'), icon: User },
    { id: 'crops', label: 'Crop Calendar', icon: Calendar },
    { id: 'market', label: t('market'), icon: TrendingUp },
  ];

  const handleNavClick = (tabId: string) => {
    setActiveTab(tabId);
    if (window.innerWidth < 768) {
      setIsOpen(false);
    }
  };

  return (
    <>
      {/* Mobile Menu Button */}
      <div className="md:hidden fixed top-4 left-4 z-50">
        <Button
          variant="outline"
          size="icon"
          onClick={() => setIsOpen(!isOpen)}
          className="bg-white border-green-200 text-green-600 hover:bg-green-50"
        >
          {isOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
        </Button>
      </div>

      {/* Overlay for mobile */}
      {isOpen && (
        <div 
          className="md:hidden fixed inset-0 bg-black bg-opacity-50 z-40"
          onClick={() => setIsOpen(false)}
        />
      )}

      {/* Sidebar */}
      <div className={`
        fixed left-0 top-0 h-full w-64 bg-white dark:bg-gray-800 border-r border-green-200 dark:border-green-600 z-50 transform transition-all duration-300 ease-in-out
        ${isOpen ? 'translate-x-0' : '-translate-x-full'}
        md:translate-x-0 md:static md:z-auto
      `}>
        {/* Header */}
        <div className="p-6 border-b border-green-200 dark:border-green-600 bg-green-50 dark:bg-gray-700">
          <div className="flex items-center space-x-3 mb-4">
            <div className="w-12 h-12 rounded-full overflow-hidden bg-white dark:bg-gray-600 border-2 border-green-300 dark:border-green-500 flex items-center justify-center">
              <img 
                src={logo} 
                alt="Krishi Officer Logo" 
                className="w-10 h-10 object-cover rounded-full"
              />
            </div>
            <div>
              <h1 className="text-green-800 dark:text-green-300 font-semibold">Krishi Officer</h1>
              <p className="text-green-600 dark:text-green-400 text-sm">AI Farm Assistant</p>
            </div>
          </div>
          
          {/* Controls */}
          <div className="flex items-center justify-between gap-3">
            <LanguageSwitcher />
            <ThemeSwitcher />
          </div>
        </div>

        {/* Navigation */}
        <nav className="flex-1 p-4">
          <div className="space-y-2">
            {navItems.map((item) => {
              const Icon = item.icon;
              const isActive = activeTab === item.id;
              
              return (
                <Button
                  key={item.id}
                  variant={isActive ? "default" : "ghost"}
                  className={`w-full justify-start ${
                    isActive 
                      ? 'bg-green-600 dark:bg-green-700 text-white hover:bg-green-700 dark:hover:bg-green-600' 
                      : 'text-green-700 dark:text-green-300 hover:bg-green-50 dark:hover:bg-gray-700 hover:text-green-800 dark:hover:text-green-200'
                  }`}
                  onClick={() => handleNavClick(item.id)}
                >
                  <Icon className="h-5 w-5 mr-3" />
                  {item.label}
                </Button>
              );
            })}
          </div>
        </nav>

        {/* Logout Button */}
        <div className="p-4 border-t border-green-200 dark:border-green-600">
          <Button
            variant="outline"
            className="w-full justify-start border-red-200 dark:border-red-600 text-red-600 dark:text-red-400 hover:bg-red-50 dark:hover:bg-red-900/20 hover:text-red-700 dark:hover:text-red-300"
            onClick={onLogout}
          >
            <LogOut className="h-5 w-5 mr-3" />
            {t('logout')}
          </Button>
        </div>

        {/* Footer */}
        <div className="p-4 text-center text-sm text-green-600 dark:text-green-400 border-t border-green-100 dark:border-green-700">
          <p>🌱 Growing Together</p>
        </div>
      </div>
    </>
  );
}