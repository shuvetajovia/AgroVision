import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Textarea } from './ui/textarea';
import { Badge } from './ui/badge';
import { Separator } from './ui/separator';
import { 
  User, 
  MapPin, 
  Phone, 
  Mail, 
  Calendar,
  Sprout,
  Settings,
  Bell,
  Globe,
  Save
} from 'lucide-react';

export function Profile() {
  const [farmer, setFarmer] = useState({
    name: 'Ravi Kumar',
    phone: '+91 9876543210',
    email: 'ravi.kumar@email.com',
    location: 'Wayanad, Kerala',
    district: 'Wayanad',
    state: 'Kerala',
    pincode: '673121',
    farmSize: '2.5',
    primaryCrops: ['Banana', 'Coconut', 'Pepper'],
    farmingExperience: '15',
    language: 'malayalam',
    notifications: {
      weather: true,
      pest: true,
      market: true,
      subsidies: true
    }
  });

  const [isEditing, setIsEditing] = useState(false);

  const crops = [
    'Rice', 'Banana', 'Coconut', 'Pepper', 'Cardamom', 'Coffee', 
    'Tea', 'Rubber', 'Cashew', 'Ginger', 'Turmeric', 'Vegetables'
  ];

  const districts = [
    'Thiruvananthapuram', 'Kollam', 'Pathanamthitta', 'Alappuzha', 
    'Kottayam', 'Idukki', 'Ernakulam', 'Thrissur', 'Palakkad', 
    'Malappuram', 'Kozhikode', 'Wayanad', 'Kannur', 'Kasaragod'
  ];

  const handleSave = () => {
    // Save farmer profile
    setIsEditing(false);
  };

  const queryStats = {
    totalQueries: 47,
    resolvedQueries: 42,
    averageRating: 4.6,
    lastActive: 'Today'
  };

  return (
    <div className="container mx-auto px-4 py-8 max-w-4xl">
      <div className="grid md:grid-cols-3 gap-6">
        {/* Profile Info */}
        <div className="md:col-span-2 space-y-6">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between">
              <CardTitle className="flex items-center space-x-2">
                <User className="h-5 w-5" />
                <span>Farmer Profile</span>
              </CardTitle>
              <Button
                variant={isEditing ? "default" : "outline"}
                size="sm"
                onClick={() => isEditing ? handleSave() : setIsEditing(true)}
              >
                {isEditing ? (
                  <>
                    <Save className="h-4 w-4 mr-2" />
                    Save
                  </>
                ) : (
                  <>
                    <Settings className="h-4 w-4 mr-2" />
                    Edit
                  </>
                )}
              </Button>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="name">Name</Label>
                  <Input
                    id="name"
                    value={farmer.name}
                    onChange={(e) => setFarmer({...farmer, name: e.target.value})}
                    disabled={!isEditing}
                  />
                </div>
                <div>
                  <Label htmlFor="phone">Phone</Label>
                  <Input
                    id="phone"
                    value={farmer.phone}
                    onChange={(e) => setFarmer({...farmer, phone: e.target.value})}
                    disabled={!isEditing}
                  />
                </div>
              </div>

              <div>
                <Label htmlFor="email">Email</Label>
                <Input
                  id="email"
                  type="email"
                  value={farmer.email}
                  onChange={(e) => setFarmer({...farmer, email: e.target.value})}
                  disabled={!isEditing}
                />
              </div>

              <div className="grid md:grid-cols-3 gap-4">
                <div>
                  <Label htmlFor="district">District</Label>
                  <Select
                    value={farmer.district}
                    onValueChange={(value) => setFarmer({...farmer, district: value})}
                    disabled={!isEditing}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {districts.map(district => (
                        <SelectItem key={district} value={district}>
                          {district}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="state">State</Label>
                  <Input
                    id="state"
                    value={farmer.state}
                    disabled
                  />
                </div>
                <div>
                  <Label htmlFor="pincode">Pincode</Label>
                  <Input
                    id="pincode"
                    value={farmer.pincode}
                    onChange={(e) => setFarmer({...farmer, pincode: e.target.value})}
                    disabled={!isEditing}
                  />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <Sprout className="h-5 w-5" />
                <span>Farming Details</span>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="farmSize">Farm Size (Acres)</Label>
                  <Input
                    id="farmSize"
                    value={farmer.farmSize}
                    onChange={(e) => setFarmer({...farmer, farmSize: e.target.value})}
                    disabled={!isEditing}
                  />
                </div>
                <div>
                  <Label htmlFor="experience">Farming Experience (Years)</Label>
                  <Input
                    id="experience"
                    value={farmer.farmingExperience}
                    onChange={(e) => setFarmer({...farmer, farmingExperience: e.target.value})}
                    disabled={!isEditing}
                  />
                </div>
              </div>

              <div>
                <Label>Primary Crops</Label>
                <div className="flex flex-wrap gap-2 mt-2">
                  {farmer.primaryCrops.map(crop => (
                    <Badge key={crop} variant="secondary">
                      {crop}
                      {isEditing && (
                        <button
                          className="ml-2 text-red-500"
                          onClick={() => setFarmer({
                            ...farmer,
                            primaryCrops: farmer.primaryCrops.filter(c => c !== crop)
                          })}
                        >
                          ×
                        </button>
                      )}
                    </Badge>
                  ))}
                </div>
                {isEditing && (
                  <Select
                    onValueChange={(value) => {
                      if (!farmer.primaryCrops.includes(value)) {
                        setFarmer({
                          ...farmer,
                          primaryCrops: [...farmer.primaryCrops, value]
                        });
                      }
                    }}
                  >
                    <SelectTrigger className="mt-2">
                      <SelectValue placeholder="Add crop" />
                    </SelectTrigger>
                    <SelectContent>
                      {crops.filter(crop => !farmer.primaryCrops.includes(crop)).map(crop => (
                        <SelectItem key={crop} value={crop}>
                          {crop}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                )}
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <Settings className="h-5 w-5" />
                <span>Preferences</span>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label htmlFor="language">Preferred Language</Label>
                <Select
                  value={farmer.language}
                  onValueChange={(value) => setFarmer({...farmer, language: value})}
                  disabled={!isEditing}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="malayalam">മലയാളം (Malayalam)</SelectItem>
                    <SelectItem value="english">English</SelectItem>
                    <SelectItem value="hindi">हिंदी (Hindi)</SelectItem>
                    <SelectItem value="tamil">தமிழ் (Tamil)</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label className="flex items-center space-x-2 mb-3">
                  <Bell className="h-4 w-4" />
                  <span>Notification Preferences</span>
                </Label>
                <div className="space-y-2">
                  {Object.entries(farmer.notifications).map(([key, value]) => (
                    <div key={key} className="flex items-center justify-between">
                      <span className="text-sm capitalize">
                        {key === 'pest' ? 'Pest Alerts' : 
                         key === 'weather' ? 'Weather Updates' :
                         key === 'market' ? 'Market Prices' : 'Subsidy Schemes'}
                      </span>
                      <input
                        type="checkbox"
                        checked={value}
                        onChange={(e) => setFarmer({
                          ...farmer,
                          notifications: {...farmer.notifications, [key]: e.target.checked}
                        })}
                        disabled={!isEditing}
                        className="rounded"
                      />
                    </div>
                  ))}
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Stats Panel */}
        <div className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Query Statistics</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="text-center">
                <p className="text-3xl font-bold text-primary">{queryStats.totalQueries}</p>
                <p className="text-sm text-muted-foreground">Total Queries</p>
              </div>
              
              <Separator />
              
              <div className="space-y-3">
                <div className="flex justify-between">
                  <span className="text-sm">Resolved</span>
                  <span className="text-sm font-medium">{queryStats.resolvedQueries}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm">Success Rate</span>
                  <span className="text-sm font-medium">
                    {Math.round((queryStats.resolvedQueries / queryStats.totalQueries) * 100)}%
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm">Avg. Rating</span>
                  <span className="text-sm font-medium">⭐ {queryStats.averageRating}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm">Last Active</span>
                  <span className="text-sm font-medium">{queryStats.lastActive}</span>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Recent Activity</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                <div className="flex items-center space-x-2">
                  <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                  <span className="text-sm">Query about banana disease resolved</span>
                </div>
                <div className="flex items-center space-x-2">
                  <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
                  <span className="text-sm">Weather alert received</span>
                </div>
                <div className="flex items-center space-x-2">
                  <div className="w-2 h-2 bg-orange-500 rounded-full"></div>
                  <span className="text-sm">New subsidy scheme available</span>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Help & Support</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <Button variant="outline" size="sm" className="w-full justify-start">
                <Phone className="h-4 w-4 mr-2" />
                Contact Support
              </Button>
              <Button variant="outline" size="sm" className="w-full justify-start">
                <Mail className="h-4 w-4 mr-2" />
                Send Feedback
              </Button>
              <Button variant="outline" size="sm" className="w-full justify-start">
                <Globe className="h-4 w-4 mr-2" />
                Visit Krishibhavan
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}