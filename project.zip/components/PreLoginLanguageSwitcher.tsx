import React from 'react';
import { Button } from './ui/button';
import { Globe } from 'lucide-react';
import { useLanguage } from './LanguageContext';

export function PreLoginLanguageSwitcher() {
  const { language, setLanguage, t } = useLanguage();

  const languages = [
    { code: 'en', name: 'English', flag: '🇺🇸' },
    { code: 'ml', name: 'മലയാളം', flag: '🇮🇳' },
  ];

  const currentLang = languages.find(lang => lang.code === language) || languages[0];

  return (
    <div className="flex flex-col items-center space-y-4 mb-6">
      {/* Language selection header */}
      <div className="text-center">
        <div className="flex items-center justify-center mb-2">
          <Globe className="h-5 w-5 text-green-600 mr-2" />
          <span className="text-green-700 font-medium">{t('chooseLanguage')}</span>
        </div>
        <p className="text-sm text-green-600">{t('selectLanguage')}</p>
      </div>

      {/* Language toggle buttons */}
      <div className="flex bg-green-50 p-1 rounded-lg border border-green-200 shadow-sm">
        {languages.map((lang) => (
          <Button
            key={lang.code}
            variant={language === lang.code ? "default" : "ghost"}
            size="sm"
            onClick={() => setLanguage(lang.code)}
            className={`
              px-4 py-2 mx-1 rounded-md font-medium transition-all duration-200
              ${language === lang.code
                ? 'bg-green-600 text-white shadow-sm'
                : 'text-green-700 hover:bg-green-100 hover:text-green-800'
              }
            `}
          >
            <span className="mr-2">{lang.flag}</span>
            <span>{lang.name}</span>
          </Button>
        ))}
      </div>
    </div>
  );
}