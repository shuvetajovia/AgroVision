import React, { useState, useRef } from 'react';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from './ui/dialog';
import { Button } from './ui/button';
import { useLanguage } from './LanguageContext';
import { Mic, MicOff, Play, Square, Send } from 'lucide-react';
import { toast } from 'sonner@2.0.3';

interface VoiceInputModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export function VoiceInputModal({ isOpen, onClose }: VoiceInputModalProps) {
  const { t } = useLanguage();
  const [isRecording, setIsRecording] = useState(false);
  const [audioURL, setAudioURL] = useState<string>('');
  const [isProcessing, setIsProcessing] = useState(false);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const audioChunksRef = useRef<Blob[]>([]);

  const checkMicrophonePermission = async () => {
    try {
      // Check if getUserMedia is supported
      if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
        toast.error('Voice recording is not supported in this browser.');
        return false;
      }

      // Check current permission state if supported
      if (navigator.permissions) {
        try {
          const permissionStatus = await navigator.permissions.query({ name: 'microphone' as PermissionName });
          
          if (permissionStatus.state === 'denied') {
            toast.error('Microphone access denied. Please enable microphone permissions in your browser settings and try again.');
            return false;
          }
        } catch (error) {
          // Permission API might not support microphone query, continue with direct access
          console.log('Permission query not supported for microphone');
        }
      }

      return true;
    } catch (error) {
      console.log('Permission API not supported, will try direct access');
      return true; // Fallback to trying getUserMedia directly
    }
  };

  const startRecording = async () => {
    try {
      // First check permissions
      const hasPermission = await checkMicrophonePermission();
      if (!hasPermission) return;

      toast.info('Requesting microphone access...');
      
      const stream = await navigator.mediaDevices.getUserMedia({ 
        audio: {
          echoCancellation: true,
          noiseSuppression: true,
          sampleRate: 44100
        }
      });
      
      const mediaRecorder = new MediaRecorder(stream, {
        mimeType: MediaRecorder.isTypeSupported('audio/webm') ? 'audio/webm' : 'audio/mp4'
      });
      
      mediaRecorderRef.current = mediaRecorder;
      audioChunksRef.current = [];

      mediaRecorder.ondataavailable = (event) => {
        if (event.data.size > 0) {
          audioChunksRef.current.push(event.data);
        }
      };

      mediaRecorder.onstop = () => {
        const audioBlob = new Blob(audioChunksRef.current, { 
          type: mediaRecorder.mimeType || 'audio/wav' 
        });
        const url = URL.createObjectURL(audioBlob);
        setAudioURL(url);
        
        // Stop all tracks to release microphone
        stream.getTracks().forEach(track => track.stop());
      };

      mediaRecorder.onerror = (event) => {
        console.error('MediaRecorder error:', event);
        toast.error('Recording error occurred. Please try again.');
        setIsRecording(false);
      };

      mediaRecorder.start(1000); // Collect data every second
      setIsRecording(true);
      toast.success('🎤 Recording started! Speak your farming question clearly...');
      
    } catch (error: any) {
      console.error('Microphone access error:', error);
      
      if (error.name === 'NotAllowedError') {
        toast.error('Microphone access denied. Please click the microphone icon in your browser\'s address bar and allow access.');
      } else if (error.name === 'NotFoundError') {
        toast.error('No microphone found. Please connect a microphone and try again.');
      } else if (error.name === 'NotReadableError') {
        toast.error('Microphone is being used by another application. Please close other apps and try again.');
      } else {
        toast.error('Unable to access microphone. Please check your device settings and try again.');
      }
    }
  };

  const stopRecording = () => {
    if (mediaRecorderRef.current && isRecording) {
      mediaRecorderRef.current.stop();
      mediaRecorderRef.current.stream.getTracks().forEach(track => track.stop());
      setIsRecording(false);
      toast.success('Recording completed!');
    }
  };

  const playRecording = () => {
    if (audioURL) {
      const audio = new Audio(audioURL);
      audio.play();
    }
  };

  const submitVoiceQuery = async () => {
    setIsProcessing(true);
    // Simulate AI processing
    setTimeout(() => {
      toast.success('Voice query processed! Our AI assistant will respond soon.');
      setIsProcessing(false);
      handleClose();
    }, 2000);
  };

  const handleClose = () => {
    setIsRecording(false);
    setAudioURL('');
    setIsProcessing(false);
    if (mediaRecorderRef.current) {
      mediaRecorderRef.current.stream?.getTracks().forEach(track => track.stop());
    }
    onClose();
  };

  return (
    <Dialog open={isOpen} onOpenChange={handleClose}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center text-green-800">
            <Mic className="h-5 w-5 mr-2" />
            {t('voiceInput')}
          </DialogTitle>
          <DialogDescription>
            Record your farming question in your preferred language. Our AI will understand and respond.
          </DialogDescription>
        </DialogHeader>

        <div className="flex flex-col items-center space-y-6 py-6">
          {/* Recording Button */}
          <div className="relative">
            <Button
              onClick={isRecording ? stopRecording : startRecording}
              className={`w-24 h-24 rounded-full ${
                isRecording 
                  ? 'bg-red-500 hover:bg-red-600 animate-pulse' 
                  : 'bg-green-600 hover:bg-green-700'
              }`}
              disabled={isProcessing}
            >
              {isRecording ? (
                <MicOff className="h-8 w-8 text-white" />
              ) : (
                <Mic className="h-8 w-8 text-white" />
              )}
            </Button>
            
            {isRecording && (
              <div className="absolute -inset-2 border-2 border-red-500 rounded-full animate-ping" />
            )}
          </div>

          {/* Status Text */}
          <div className="text-center">
            {isRecording ? (
              <p className="text-red-600">🔴 Recording... Tap to stop</p>
            ) : audioURL ? (
              <p className="text-green-600">✅ Recording ready to submit</p>
            ) : (
              <p className="text-green-600">Tap the microphone to {t('startRecording').toLowerCase()}</p>
            )}
          </div>

          {/* Audio Controls */}
          {audioURL && (
            <div className="flex space-x-3">
              <Button
                variant="outline"
                onClick={playRecording}
                disabled={isProcessing}
                className="flex items-center"
              >
                <Play className="h-4 w-4 mr-2" />
                Play Recording
              </Button>
              
              <Button
                onClick={submitVoiceQuery}
                disabled={isProcessing}
                className="bg-green-600 hover:bg-green-700 flex items-center"
              >
                {isProcessing ? (
                  <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin mr-2" />
                ) : (
                  <Send className="h-4 w-4 mr-2" />
                )}
                {isProcessing ? t('processing') : 'Submit Query'}
              </Button>
            </div>
          )}
        </div>

        {/* Tips */}
        <div className="bg-green-50 p-3 rounded-lg">
          <p className="text-sm text-green-700 mb-2">
            💡 <strong>Tips:</strong> Speak clearly and describe your farming issue in detail. 
            You can ask about crops, diseases, weather, or market prices in Malayalam or English.
          </p>
          
          <div className="mt-3 p-3 bg-blue-50 border border-blue-200 rounded">
            <p className="text-xs text-blue-700">
              🔒 <strong>Privacy:</strong> Your voice recordings are processed securely and are not stored permanently. 
              Microphone access is only used when you click the record button.
            </p>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}