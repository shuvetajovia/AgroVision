import React, { useState, useRef } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Badge } from './ui/badge';
import { ImageWithFallback } from './figma/ImageWithFallback';
import { submitQuery, type QueryRequest } from '../utils/api';
import { 
  Send, 
  Mic, 
  MicOff, 
  Image, 
  MapPin, 
  Calendar,
  User,
  Bot,
  Upload,
  X
} from 'lucide-react';

interface Message {
  id: string;
  type: 'user' | 'bot';
  content: string;
  contentMl?: string;
  timestamp: Date;
  attachments?: {
    type: 'image' | 'voice';
    url: string;
    name: string;
  }[];
  context?: {
    location: string;
    crop: string;
    season: string;
  };
}

export function ChatInterface() {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: '1',
      type: 'bot',
      content: 'Hello! I\'m your Digital Krishi Officer. How can I help you today?',
      contentMl: 'നമസ്കാരം! ഞാൻ നിങ്ങളുടെ ഡിജിറ്റൽ കൃഷി ഓഫീസറാണ്. ഇന്ന് എങ്ങനെ സഹായിക്കാം?',
      timestamp: new Date(),
    }
  ]);
  const [input, setInput] = useState('');
  const [isRecording, setIsRecording] = useState(false);
  const [selectedImage, setSelectedImage] = useState<File | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const farmerContext = {
    name: 'Ravi Kumar',
    location: 'Wayanad, Kerala',
    primaryCrop: 'Banana',
    season: 'Monsoon'
  };

  const handleSendMessage = async () => {
    if (!input.trim() && !selectedImage) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      type: 'user',
      content: input,
      timestamp: new Date(),
      attachments: selectedImage ? [{ 
        type: 'image', 
        url: URL.createObjectURL(selectedImage), 
        name: selectedImage.name 
      }] : undefined,
      context: {
        location: farmerContext.location,
        crop: farmerContext.primaryCrop,
        season: farmerContext.season
      }
    };

    setMessages(prev => [...prev, userMessage]);
    const currentInput = input;
    setInput('');
    setSelectedImage(null);
    setIsLoading(true);

    try {
      // Submit query to backend
      const queryRequest: QueryRequest = {
        question: currentInput,
        context: {
          location: farmerContext.location,
          crop: farmerContext.primaryCrop,
          season: farmerContext.season,
          farmerId: 'farmer_001' // In real app, this would come from auth
        },
        type: selectedImage ? 'image' : 'text'
      };

      const response = await submitQuery(queryRequest);
      
      const botResponse: Message = {
        id: response.queryId,
        type: 'bot',
        content: response.answer,
        contentMl: response.answerMl,
        timestamp: new Date(),
      };

      setMessages(prev => [...prev, botResponse]);
      
      if (response.escalated) {
        // Show escalation notice
        const escalationMessage: Message = {
          id: `escalation_${Date.now()}`,
          type: 'bot',
          content: 'Your query has been forwarded to a local agricultural expert for detailed assistance. You will receive a response within 24 hours.',
          contentMl: 'നിങ്ങളുടെ ചോദ്യം വിശദമായ സഹായത്തിനായി ഒരു പ്രാദേശിക കൃഷി വിദഗ്ധന് കൈമാറി. 24 മണിക്കൂറിനുള്ളിൽ നിങ്ങൾക്ക് മറുപടി ലഭിക്കും.',
          timestamp: new Date(),
        };
        setMessages(prev => [...prev, escalationMessage]);
      }

    } catch (error) {
      console.error('Error submitting query:', error);
      const errorMessage: Message = {
        id: `error_${Date.now()}`,
        type: 'bot',
        content: 'Sorry, I encountered an error processing your query. Please try again.',
        contentMl: 'ക്ഷമിക്കണം, നിങ്ങളുടെ ചോദ്യം പ്രോസസ്സ് ചെയ്യുന്നതിൽ ഒരു പിശക് നേരിട്ടു. ദയവായി വീണ്ടും ശ്രമിക്കുക.',
        timestamp: new Date(),
      };
      setMessages(prev => [...prev, errorMessage]);
    } finally {
      setIsLoading(false);
    }
  };

  const generateBotResponse = (userMessage: Message): Message => {
    const responses = {
      pestControl: {
        content: 'Based on your image and description, this appears to be leaf spot disease in banana plants. Here\'s what I recommend:',
        contentMl: 'നിങ്ങളുടെ ചിത്രവും വിവരണവും അടിസ്ഥാനമാക്കി, ഇത് വാഴയിലെ ഇലപ്പുള്ളി രോഗമാണെന്ന് തോന്നുന്നു. ഞാൻ നിർദ്ദേശിക്കുന്നത്:',
        advice: [
          '1. Remove affected leaves immediately',
          '2. Apply Copper oxychloride fungicide (2g/L)',
          '3. Ensure proper drainage around plants',
          '4. Maintain 8-10 feet spacing between plants'
        ],
        adviceMl: [
          '1. രോഗബാധിതമായ ഇലകൾ ഉടനെ നീക്കം ചെയ്യുക',
          '2. കോപ്പർ ഓക്സിക്ലോറൈഡ് കുമിൾനാശിനി (2g/L) പ്രയോഗിക്കുക',
          '3. ചെടികൾക്ക് ചുറ്റും നല്ല നീർവാർച്ച ഉറപ്പാക്കുക',
          '4. ചെടികൾ തമ്മിൽ 8-10 അടി അകലം പാലിക്കുക'
        ]
      },
      general: {
        content: 'Thank you for your question about farming. Let me provide you with specific guidance based on your location and crop.',
        contentMl: 'കൃഷിയെക്കുറിച്ചുള്ള നിങ്ങളുടെ ചോദ്യത്തിന് നന്ദി. നിങ്ങളുടെ സ്ഥലവും വിളയും അടിസ്ഥാനമാക്കി പ്രത്യേക മാർഗ്ഗനിർദ്ദേശം നൽകാം.'
      }
    };

    const hasImage = userMessage.attachments?.some(att => att.type === 'image');
    const responseType = hasImage || userMessage.content.toLowerCase().includes('disease') || 
                        userMessage.content.includes('രോഗം') ? 'pestControl' : 'general';
    
    const response = responses[responseType];
    
    return {
      id: Date.now().toString(),
      type: 'bot',
      content: response.content,
      contentMl: response.contentMl,
      timestamp: new Date(),
    };
  };

  const handleImageUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      setSelectedImage(file);
    }
  };

  const toggleRecording = () => {
    setIsRecording(!isRecording);
    // Voice recording logic would go here
  };

  return (
    <div className="container mx-auto px-4 py-8 max-w-4xl">
      <div className="grid md:grid-cols-4 gap-6">
        {/* Context Panel */}
        <div className="md:col-span-1">
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Farmer Context</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center space-x-2">
                <User className="h-4 w-4 text-muted-foreground" />
                <span className="text-sm">{farmerContext.name}</span>
              </div>
              <div className="flex items-center space-x-2">
                <MapPin className="h-4 w-4 text-muted-foreground" />
                <span className="text-sm">{farmerContext.location}</span>
              </div>
              <div className="flex items-center space-x-2">
                <Calendar className="h-4 w-4 text-muted-foreground" />
                <span className="text-sm">{farmerContext.season}</span>
              </div>
              <Badge variant="secondary">{farmerContext.primaryCrop}</Badge>
            </CardContent>
          </Card>

          <Card className="mt-4">
            <CardHeader>
              <CardTitle className="text-lg">Quick Actions</CardTitle>
            </CardHeader>
            <CardContent className="space-y-2">
              <Button 
                variant="outline" 
                size="sm" 
                className="w-full justify-start"
                onClick={() => setInput('വാഴയിൽ പുഴു കണ്ടു. എന്ത് ചെയ്യണം?')}
              >
                Pest Control
              </Button>
              <Button 
                variant="outline" 
                size="sm" 
                className="w-full justify-start"
                onClick={() => setInput('ഇന്നത്തെ കാലാവസ്ഥ എങ്ങനെയാണ്?')}
              >
                Weather Info
              </Button>
              <Button 
                variant="outline" 
                size="sm" 
                className="w-full justify-start"
                onClick={() => setInput('സബ്സിഡി പദ്ധതികൾ എന്തെല്ലാം?')}
              >
                Subsidies
              </Button>
            </CardContent>
          </Card>
        </div>

        {/* Chat Panel */}
        <div className="md:col-span-3">
          <Card className="h-[70vh] flex flex-col">
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <Bot className="h-5 w-5" />
                <span>AI Farming Assistant</span>
              </CardTitle>
            </CardHeader>
            
            <CardContent className="flex-1 flex flex-col">
              {/* Messages */}
              <div className="flex-1 overflow-y-auto space-y-4 mb-4">
                {messages.map((message) => (
                  <div
                    key={message.id}
                    className={`flex ${message.type === 'user' ? 'justify-end' : 'justify-start'}`}
                  >
                    <div
                      className={`max-w-[80%] rounded-lg p-3 ${
                        message.type === 'user'
                          ? 'bg-primary text-primary-foreground'
                          : 'bg-muted'
                      }`}
                    >
                      <div className="flex items-start space-x-2">
                        {message.type === 'bot' && <Bot className="h-4 w-4 mt-1" />}
                        <div className="space-y-2">
                          <p className="text-sm">{message.content}</p>
                          {message.contentMl && (
                            <p className="text-sm italic text-muted-foreground">
                              {message.contentMl}
                            </p>
                          )}
                          {message.attachments?.map((attachment, idx) => (
                            <div key={idx} className="mt-2">
                              {attachment.type === 'image' && (
                                <ImageWithFallback
                                  src={attachment.url}
                                  alt={attachment.name}
                                  className="max-w-xs rounded-lg"
                                />
                              )}
                            </div>
                          ))}
                          <span className="text-xs text-muted-foreground">
                            {message.timestamp.toLocaleTimeString()}
                          </span>
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
                {isLoading && (
                  <div className="flex justify-start">
                    <div className="bg-muted rounded-lg p-3">
                      <div className="flex items-center space-x-2">
                        <Bot className="h-4 w-4" />
                        <div className="flex space-x-1">
                          <div className="w-2 h-2 bg-current rounded-full animate-bounce"></div>
                          <div className="w-2 h-2 bg-current rounded-full animate-bounce" style={{ animationDelay: '0.1s' }}></div>
                          <div className="w-2 h-2 bg-current rounded-full animate-bounce" style={{ animationDelay: '0.2s' }}></div>
                        </div>
                      </div>
                    </div>
                  </div>
                )}
              </div>

              {/* Input Area */}
              <div className="space-y-3">
                {selectedImage && (
                  <div className="flex items-center space-x-2 p-2 bg-muted rounded-lg">
                    <Image className="h-4 w-4" />
                    <span className="text-sm">{selectedImage.name}</span>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => setSelectedImage(null)}
                    >
                      <X className="h-4 w-4" />
                    </Button>
                  </div>
                )}
                
                <div className="flex space-x-2">
                  <Input
                    value={input}
                    onChange={(e) => setInput(e.target.value)}
                    placeholder="Type your question in Malayalam or English..."
                    onKeyPress={(e) => e.key === 'Enter' && handleSendMessage()}
                    className="flex-1"
                  />
                  
                  <input
                    ref={fileInputRef}
                    type="file"
                    accept="image/*"
                    onChange={handleImageUpload}
                    className="hidden"
                  />
                  
                  <Button
                    variant="outline"
                    size="icon"
                    onClick={() => fileInputRef.current?.click()}
                  >
                    <Upload className="h-4 w-4" />
                  </Button>
                  
                  <Button
                    variant="outline"
                    size="icon"
                    onClick={toggleRecording}
                    className={isRecording ? 'bg-red-100' : ''}
                  >
                    {isRecording ? <MicOff className="h-4 w-4" /> : <Mic className="h-4 w-4" />}
                  </Button>
                  
                  <Button onClick={handleSendMessage} disabled={!input.trim() && !selectedImage}>
                    <Send className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}