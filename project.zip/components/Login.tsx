import React, { useState, useEffect } from 'react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Alert, AlertDescription } from './ui/alert';
import { Badge } from './ui/badge';
import { Separator } from './ui/separator';
import { 
  Leaf, 
  Phone, 
  Mail, 
  User, 
  Lock, 
  Shield, 
  UserCheck, 
  Settings,
  RefreshCw,
  Eye,
  EyeOff,
  ArrowLeft,
  Database,
  CheckCircle,
  XCircle,
  AlertTriangle
} from 'lucide-react';
import { useLanguage } from './LanguageContext';
import { PreLoginLanguageSwitcher } from './PreLoginLanguageSwitcher';
import { ThemeSwitcher } from './ThemeSwitcher';
import { toast } from 'sonner@2.0.3';
import { UserCSVDatabase, generateCaptcha, type UserData } from '../data/user-database';
import logo from 'figma:asset/5dc22ea35ca935a57743fd34fcb015d3e9e72d8f.png';

interface LoginProps {
  onLogin: (userData: any) => void;
}

type ViewMode = 'login' | 'register' | 'forgot-password';
type UserRole = 'farmer' | 'admin';

export function Login({ onLogin }: LoginProps) {
  const { t } = useLanguage();
  
  // UI State
  const [viewMode, setViewMode] = useState<ViewMode>('login');
  const [selectedRole, setSelectedRole] = useState<UserRole>('farmer');
  const [showPassword, setShowPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  
  // Captcha State
  const [captcha, setCaptcha] = useState(generateCaptcha());
  const [captchaInput, setCaptchaInput] = useState('');
  
  // Form Data
  const [loginData, setLoginData] = useState({
    identifier: '', // username or mobile
    password: ''
  });
  
  const [registerData, setRegisterData] = useState({
    username: '',
    fullName: '',
    mobileNumber: '',
    email: '',
    password: '',
    confirmPassword: '',
    district: ''
  });
  
  const [forgotPasswordData, setForgotPasswordData] = useState({
    identifier: ''
  });
  
  // Error states
  const [errors, setErrors] = useState<string[]>([]);

  // Generate new captcha
  const refreshCaptcha = () => {
    setCaptcha(generateCaptcha());
    setCaptchaInput('');
  };

  // Validate mobile number format
  const validateMobileNumber = (mobile: string): boolean => {
    const mobileRegex = /^(\+91|91)?[6-9]\d{9}$/;
    return mobileRegex.test(mobile.replace(/\s+/g, ''));
  };

  // Validate form data
  const validateLogin = (): boolean => {
    const newErrors: string[] = [];
    
    if (!loginData.identifier.trim()) {
      newErrors.push('Username or mobile number is required');
    }
    
    if (!loginData.password.trim()) {
      newErrors.push('Password is required');
    }
    
    if (parseInt(captchaInput) !== captcha.answer) {
      newErrors.push(t('captchaIncorrect'));
    }
    
    setErrors(newErrors);
    return newErrors.length === 0;
  };

  const validateRegistration = (): boolean => {
    const newErrors: string[] = [];
    
    if (!registerData.username.trim()) {
      newErrors.push('Username is required');
    } else if (registerData.username.length < 3) {
      newErrors.push('Username must be at least 3 characters');
    }
    
    if (!registerData.fullName.trim()) {
      newErrors.push('Full name is required');
    }
    
    if (!registerData.mobileNumber.trim()) {
      newErrors.push('Mobile number is required');
    } else if (!validateMobileNumber(registerData.mobileNumber)) {
      newErrors.push('Please enter a valid Indian mobile number');
    }
    
    if (!registerData.password.trim()) {
      newErrors.push('Password is required');
    } else if (registerData.password.length < 6) {
      newErrors.push('Password must be at least 6 characters');
    }
    
    if (registerData.password !== registerData.confirmPassword) {
      newErrors.push('Passwords do not match');
    }
    
    if (parseInt(captchaInput) !== captcha.answer) {
      newErrors.push(t('captchaIncorrect'));
    }
    
    setErrors(newErrors);
    return newErrors.length === 0;
  };

  // Handle login
  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    
    try {
      if (!validateLogin()) {
        setIsLoading(false);
        return;
      }
      
      // Simulate API delay
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      const user = UserCSVDatabase.validateCredentials(
        loginData.identifier,
        loginData.password,
        selectedRole
      );
      
      if (user) {
        toast.success(`Welcome back, ${user.fullName}!`);
        onLogin({
          ...user,
          isAuthenticated: true
        });
      } else {
        setErrors([t('invalidCredentials')]);
        refreshCaptcha();
      }
    } catch (error) {
      setErrors(['Login failed. Please try again.']);
    } finally {
      setIsLoading(false);
    }
  };

  // Handle registration
  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    
    try {
      if (!validateRegistration()) {
        setIsLoading(false);
        return;
      }
      
      // Check if user already exists
      if (UserCSVDatabase.userExists(registerData.username, registerData.mobileNumber)) {
        setErrors([t('userAlreadyExists')]);
        setIsLoading(false);
        refreshCaptcha();
        return;
      }
      
      // Simulate API delay
      await new Promise(resolve => setTimeout(resolve, 1500));
      
      // Add user to database
      const newUser = UserCSVDatabase.addUser({
        username: registerData.username,
        fullName: registerData.fullName,
        mobileNumber: registerData.mobileNumber,
        email: registerData.email,
        password: registerData.password, // In real app, hash this
        role: selectedRole,
        district: registerData.district
      });
      
      toast.success(t('registrationSuccess'));
      
      // Automatically log in the new user
      onLogin({
        ...newUser,
        isAuthenticated: true
      });
      
    } catch (error) {
      setErrors(['Registration failed. Please try again.']);
    } finally {
      setIsLoading(false);
    }
  };

  // Handle forgot password
  const handleForgotPassword = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    
    try {
      // Simulate API delay
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      const user = UserCSVDatabase.findUser(forgotPasswordData.identifier);
      
      if (user) {
        toast.success(t('passwordResetSent'));
        setViewMode('login');
      } else {
        setErrors(['User not found with this username or mobile number']);
      }
    } catch (error) {
      setErrors(['Password reset failed. Please try again.']);
    } finally {
      setIsLoading(false);
    }
  };

  // Reset form when switching modes
  useEffect(() => {
    setErrors([]);
    setCaptchaInput('');
    refreshCaptcha();
  }, [viewMode, selectedRole]);

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 to-amber-50 dark:from-gray-900 dark:to-gray-800 flex items-center justify-center p-4 transition-colors duration-300">
      {/* Theme Switcher */}
      <div className="fixed top-4 right-4 z-50">
        <ThemeSwitcher />
      </div>
      
      <div className="w-full max-w-md">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="flex items-center justify-center mb-4">
            <div className="w-20 h-20 rounded-full overflow-hidden bg-white dark:bg-gray-800 border-4 border-green-300 dark:border-green-600 shadow-lg flex items-center justify-center">
              <img 
                src={logo} 
                alt="Krishi Officer Logo" 
                className="w-16 h-16 object-cover rounded-full"
              />
            </div>
          </div>
          <h1 className="text-3xl text-green-800 dark:text-green-400 mb-2">{t('digitalKrishiOfficer')}</h1>
          <p className="text-green-600 dark:text-green-300">{t('aiPoweredAssistant')}</p>
          
          {/* CSV Database Indicator */}
          <div className="mt-4 flex items-center justify-center">
            <Badge variant="outline" className="bg-blue-50 dark:bg-blue-900/20 text-blue-700 dark:text-blue-300 border-blue-200 dark:border-blue-600">
              <Database className="h-3 w-3 mr-1" />
              {t('csvDataStorage')}
            </Badge>
          </div>
        </div>

        {/* Language Selector */}
        <PreLoginLanguageSwitcher />

        {/* Main Card */}
        <Card className="shadow-lg border-green-200 dark:border-green-600 bg-white dark:bg-gray-800">
          {/* Role Selection */}
          <CardHeader className="text-center pb-4 bg-green-50 dark:bg-gray-700">
            <CardTitle className="text-green-800 dark:text-green-400 mb-4">{t('roleSelection')}</CardTitle>
            <div className="flex gap-2">
              <Button
                type="button"
                variant={selectedRole === 'farmer' ? 'default' : 'outline'}
                size="sm"
                onClick={() => setSelectedRole('farmer')}
                className={`flex-1 ${selectedRole === 'farmer' ? 'bg-green-600 hover:bg-green-700 text-white' : 'border-green-300 text-green-700 hover:bg-green-50 dark:border-green-500 dark:text-green-400 dark:hover:bg-green-900/20'}`}
              >
                <UserCheck className="h-4 w-4 mr-2" />
                {t('farmerLogin')}
              </Button>
              <Button
                type="button"
                variant={selectedRole === 'admin' ? 'default' : 'outline'}
                size="sm"
                onClick={() => setSelectedRole('admin')}
                className={`flex-1 ${selectedRole === 'admin' ? 'bg-blue-600 hover:bg-blue-700 text-white' : 'border-blue-300 text-blue-700 hover:bg-blue-50 dark:border-blue-500 dark:text-blue-400 dark:hover:bg-blue-900/20'}`}
              >
                <Settings className="h-4 w-4 mr-2" />
                {t('adminLogin')}
              </Button>
            </div>
          </CardHeader>

          {/* Error Display */}
          {errors.length > 0 && (
            <div className="px-6 pt-4">
              <Alert className="border-red-200 bg-red-50 dark:border-red-600 dark:bg-red-900/20">
                <XCircle className="h-4 w-4 text-red-600 dark:text-red-400" />
                <AlertDescription className="text-red-700 dark:text-red-300">
                  <ul className="list-disc list-inside space-y-1">
                    {errors.map((error, index) => (
                      <li key={index}>{error}</li>
                    ))}
                  </ul>
                </AlertDescription>
              </Alert>
            </div>
          )}

          {/* Login Form */}
          {viewMode === 'login' && (
            <CardContent className="p-6">
              <div className="text-center mb-6">
                <h3 className="text-lg font-medium text-gray-900 dark:text-gray-100">
                  {selectedRole === 'farmer' ? t('farmerLogin') : t('adminLogin')}
                </h3>
                <p className="text-sm text-gray-600 dark:text-gray-400">{t('welcomeBack')}</p>
              </div>

              <form onSubmit={handleLogin} className="space-y-4">
                {/* Username/Mobile */}
                <div className="space-y-2">
                  <Label htmlFor="identifier" className="text-green-700 dark:text-green-300">
                    {t('username')} / {t('mobileNumber')}
                  </Label>
                  <div className="relative">
                    <User className="absolute left-3 top-3 h-4 w-4 text-green-600 dark:text-green-400" />
                    <Input
                      id="identifier"
                      type="text"
                      placeholder={selectedRole === 'farmer' ? t('enterUsername') : 'admin1 or 9876543211'}
                      value={loginData.identifier}
                      onChange={(e) => setLoginData({...loginData, identifier: e.target.value})}
                      className="pl-10 h-12 border-green-200 dark:border-green-600 focus:border-green-400 dark:focus:border-green-400 bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100"
                      required
                    />
                  </div>
                </div>

                {/* Password */}
                <div className="space-y-2">
                  <Label htmlFor="password" className="text-green-700 dark:text-green-300">{t('password')}</Label>
                  <div className="relative">
                    <Lock className="absolute left-3 top-3 h-4 w-4 text-green-600 dark:text-green-400" />
                    <Input
                      id="password"
                      type={showPassword ? 'text' : 'password'}
                      placeholder={selectedRole === 'farmer' ? 'farmer123' : 'admin123'}
                      value={loginData.password}
                      onChange={(e) => setLoginData({...loginData, password: e.target.value})}
                      className="pl-10 pr-10 h-12 border-green-200 dark:border-green-600 focus:border-green-400 dark:focus:border-green-400 bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100"
                      required
                    />
                    <Button
                      type="button"
                      variant="ghost"
                      size="sm"
                      onClick={() => setShowPassword(!showPassword)}
                      className="absolute right-2 top-1/2 -translate-y-1/2 h-8 w-8 p-0 hover:bg-transparent"
                    >
                      {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                    </Button>
                  </div>
                </div>

                <Separator />

                {/* Captcha */}
                <div className="space-y-2">
                  <Label htmlFor="captcha" className="text-green-700 dark:text-green-300 flex items-center">
                    <Shield className="h-4 w-4 mr-2" />
                    {t('captcha')}
                  </Label>
                  <div className="flex gap-2">
                    <div className="flex-1 bg-gray-100 dark:bg-gray-700 border border-green-200 dark:border-green-600 rounded-lg p-3 flex items-center justify-center">
                      <span className="text-lg font-mono text-gray-800 dark:text-gray-200">
                        {captcha.question}
                      </span>
                    </div>
                    <Button
                      type="button"
                      variant="outline"
                      size="icon"
                      onClick={refreshCaptcha}
                      className="border-green-200 dark:border-green-600 hover:bg-green-50 dark:hover:bg-green-900/20"
                    >
                      <RefreshCw className="h-4 w-4" />
                    </Button>
                  </div>
                  <Input
                    id="captcha"
                    type="number"
                    placeholder={t('enterCaptcha')}
                    value={captchaInput}
                    onChange={(e) => setCaptchaInput(e.target.value)}
                    className="h-12 border-green-200 dark:border-green-600 focus:border-green-400 dark:focus:border-green-400 bg-white dark:bg-gray-700"
                    required
                  />
                  <p className="text-xs text-gray-500 dark:text-gray-400">
                    {t('solveMathProblem')}
                  </p>
                </div>

                {/* Submit Button */}
                <Button 
                  type="submit" 
                  disabled={isLoading}
                  className={`w-full h-12 text-white ${
                    selectedRole === 'farmer' 
                      ? 'bg-green-600 hover:bg-green-700 dark:bg-green-700 dark:hover:bg-green-600' 
                      : 'bg-blue-600 hover:bg-blue-700 dark:bg-blue-700 dark:hover:bg-blue-600'
                  }`}
                >
                  {isLoading ? (
                    <div className="flex items-center">
                      <RefreshCw className="h-4 w-4 mr-2 animate-spin" />
                      Logging in...
                    </div>
                  ) : (
                    t('signIn')
                  )}
                </Button>

                {/* Forgot Password Link */}
                <div className="text-center">
                  <Button
                    type="button"
                    variant="link"
                    onClick={() => setViewMode('forgot-password')}
                    className="text-green-600 dark:text-green-400 hover:text-green-700 dark:hover:text-green-300 p-0 h-auto"
                  >
                    {t('forgotPassword')}
                  </Button>
                </div>

                <Separator />

                {/* Register Link */}
                <div className="text-center space-y-2">
                  <p className="text-sm text-gray-600 dark:text-gray-400">{t('dontHaveAccount')}</p>
                  <Button
                    type="button"
                    variant="outline"
                    onClick={() => setViewMode('register')}
                    className="w-full border-green-200 dark:border-green-600 text-green-700 dark:text-green-300 hover:bg-green-50 dark:hover:bg-green-900/20"
                  >
                    {t('registerHere')}
                  </Button>
                </div>
              </form>
            </CardContent>
          )}

          {/* Registration Form */}
          {viewMode === 'register' && (
            <CardContent className="p-6">
              <div className="text-center mb-6">
                <h3 className="text-lg font-medium text-gray-900 dark:text-gray-100">
                  {t('registerNewUser')} ({selectedRole === 'farmer' ? t('farmerLogin') : t('adminLogin')})
                </h3>
                <p className="text-sm text-gray-600 dark:text-gray-400">{t('createAccountToStart')}</p>
              </div>

              <form onSubmit={handleRegister} className="space-y-4">
                {/* Username */}
                <div className="space-y-2">
                  <Label htmlFor="reg-username" className="text-green-700 dark:text-green-300">{t('username')}</Label>
                  <div className="relative">
                    <User className="absolute left-3 top-3 h-4 w-4 text-green-600 dark:text-green-400" />
                    <Input
                      id="reg-username"
                      type="text"
                      placeholder={t('enterUsername')}
                      value={registerData.username}
                      onChange={(e) => setRegisterData({...registerData, username: e.target.value})}
                      className="pl-10 h-12 border-green-200 dark:border-green-600 focus:border-green-400 dark:focus:border-green-400 bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100"
                      required
                    />
                  </div>
                </div>

                {/* Full Name */}
                <div className="space-y-2">
                  <Label htmlFor="reg-name" className="text-green-700 dark:text-green-300">{t('fullName')}</Label>
                  <Input
                    id="reg-name"
                    type="text"
                    placeholder={t('enterFullName')}
                    value={registerData.fullName}
                    onChange={(e) => setRegisterData({...registerData, fullName: e.target.value})}
                    className="h-12 border-green-200 dark:border-green-600 focus:border-green-400 dark:focus:border-green-400 bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100"
                    required
                  />
                </div>

                {/* Mobile Number */}
                <div className="space-y-2">
                  <Label htmlFor="reg-mobile" className="text-green-700 dark:text-green-300">{t('mobileNumber')}</Label>
                  <div className="relative">
                    <Phone className="absolute left-3 top-3 h-4 w-4 text-green-600 dark:text-green-400" />
                    <Input
                      id="reg-mobile"
                      type="tel"
                      placeholder={t('enterMobileNumber')}
                      value={registerData.mobileNumber}
                      onChange={(e) => setRegisterData({...registerData, mobileNumber: e.target.value})}
                      className="pl-10 h-12 border-green-200 dark:border-green-600 focus:border-green-400 dark:focus:border-green-400 bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100"
                      required
                    />
                  </div>
                </div>

                {/* Email (Optional) */}
                <div className="space-y-2">
                  <Label htmlFor="reg-email" className="text-green-700 dark:text-green-300">{t('email')} (Optional)</Label>
                  <div className="relative">
                    <Mail className="absolute left-3 top-3 h-4 w-4 text-green-600 dark:text-green-400" />
                    <Input
                      id="reg-email"
                      type="email"
                      placeholder={t('enterEmail')}
                      value={registerData.email}
                      onChange={(e) => setRegisterData({...registerData, email: e.target.value})}
                      className="pl-10 h-12 border-green-200 dark:border-green-600 focus:border-green-400 dark:focus:border-green-400 bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100"
                    />
                  </div>
                </div>

                {/* Password */}
                <div className="space-y-2">
                  <Label htmlFor="reg-password" className="text-green-700 dark:text-green-300">{t('password')}</Label>
                  <div className="relative">
                    <Lock className="absolute left-3 top-3 h-4 w-4 text-green-600 dark:text-green-400" />
                    <Input
                      id="reg-password"
                      type={showPassword ? 'text' : 'password'}
                      placeholder={t('createPassword')}
                      value={registerData.password}
                      onChange={(e) => setRegisterData({...registerData, password: e.target.value})}
                      className="pl-10 pr-10 h-12 border-green-200 dark:border-green-600 focus:border-green-400 dark:focus:border-green-400 bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100"
                      required
                    />
                    <Button
                      type="button"
                      variant="ghost"
                      size="sm"
                      onClick={() => setShowPassword(!showPassword)}
                      className="absolute right-2 top-1/2 -translate-y-1/2 h-8 w-8 p-0 hover:bg-transparent"
                    >
                      {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                    </Button>
                  </div>
                </div>

                {/* Confirm Password */}
                <div className="space-y-2">
                  <Label htmlFor="reg-confirm-password" className="text-green-700 dark:text-green-300">{t('confirmPassword')}</Label>
                  <Input
                    id="reg-confirm-password"
                    type="password"
                    placeholder={t('confirmYourPassword')}
                    value={registerData.confirmPassword}
                    onChange={(e) => setRegisterData({...registerData, confirmPassword: e.target.value})}
                    className="h-12 border-green-200 dark:border-green-600 focus:border-green-400 dark:focus:border-green-400 bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100"
                    required
                  />
                </div>

                <Separator />

                {/* Captcha */}
                <div className="space-y-2">
                  <Label htmlFor="reg-captcha" className="text-green-700 dark:text-green-300 flex items-center">
                    <Shield className="h-4 w-4 mr-2" />
                    {t('captcha')}
                  </Label>
                  <div className="flex gap-2">
                    <div className="flex-1 bg-gray-100 dark:bg-gray-700 border border-green-200 dark:border-green-600 rounded-lg p-3 flex items-center justify-center">
                      <span className="text-lg font-mono text-gray-800 dark:text-gray-200">
                        {captcha.question}
                      </span>
                    </div>
                    <Button
                      type="button"
                      variant="outline"
                      size="icon"
                      onClick={refreshCaptcha}
                      className="border-green-200 dark:border-green-600 hover:bg-green-50 dark:hover:bg-green-900/20"
                    >
                      <RefreshCw className="h-4 w-4" />
                    </Button>
                  </div>
                  <Input
                    id="reg-captcha"
                    type="number"
                    placeholder={t('enterCaptcha')}
                    value={captchaInput}
                    onChange={(e) => setCaptchaInput(e.target.value)}
                    className="h-12 border-green-200 dark:border-green-600 focus:border-green-400 dark:focus:border-green-400 bg-white dark:bg-gray-700"
                    required
                  />
                </div>

                {/* Submit Button */}
                <Button 
                  type="submit" 
                  disabled={isLoading}
                  className={`w-full h-12 text-white ${
                    selectedRole === 'farmer' 
                      ? 'bg-green-600 hover:bg-green-700 dark:bg-green-700 dark:hover:bg-green-600' 
                      : 'bg-blue-600 hover:bg-blue-700 dark:bg-blue-700 dark:hover:bg-blue-600'
                  }`}
                >
                  {isLoading ? (
                    <div className="flex items-center">
                      <RefreshCw className="h-4 w-4 mr-2 animate-spin" />
                      Creating Account...
                    </div>
                  ) : (
                    t('createAccount')
                  )}
                </Button>

                <Separator />

                {/* Back to Login */}
                <div className="text-center space-y-2">
                  <p className="text-sm text-gray-600 dark:text-gray-400">{t('alreadyHaveAccount')}</p>
                  <Button
                    type="button"
                    variant="outline"
                    onClick={() => setViewMode('login')}
                    className="w-full border-green-200 dark:border-green-600 text-green-700 dark:text-green-300 hover:bg-green-50 dark:hover:bg-green-900/20"
                  >
                    {t('loginHere')}
                  </Button>
                </div>
              </form>
            </CardContent>
          )}

          {/* Forgot Password Form */}
          {viewMode === 'forgot-password' && (
            <CardContent className="p-6">
              <div className="text-center mb-6">
                <h3 className="text-lg font-medium text-gray-900 dark:text-gray-100">{t('resetPassword')}</h3>
                <p className="text-sm text-gray-600 dark:text-gray-400">Enter your username or mobile number</p>
              </div>

              <form onSubmit={handleForgotPassword} className="space-y-4">
                {/* Username/Mobile */}
                <div className="space-y-2">
                  <Label htmlFor="forgot-identifier" className="text-green-700 dark:text-green-300">
                    {t('username')} / {t('mobileNumber')}
                  </Label>
                  <div className="relative">
                    <User className="absolute left-3 top-3 h-4 w-4 text-green-600 dark:text-green-400" />
                    <Input
                      id="forgot-identifier"
                      type="text"
                      placeholder={t('enterUsername')}
                      value={forgotPasswordData.identifier}
                      onChange={(e) => setForgotPasswordData({...forgotPasswordData, identifier: e.target.value})}
                      className="pl-10 h-12 border-green-200 dark:border-green-600 focus:border-green-400 dark:focus:border-green-400 bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100"
                      required
                    />
                  </div>
                </div>

                {/* Submit Button */}
                <Button 
                  type="submit" 
                  disabled={isLoading}
                  className="w-full h-12 bg-green-600 hover:bg-green-700 dark:bg-green-700 dark:hover:bg-green-600 text-white"
                >
                  {isLoading ? (
                    <div className="flex items-center">
                      <RefreshCw className="h-4 w-4 mr-2 animate-spin" />
                      Sending...
                    </div>
                  ) : (
                    t('sendResetCode')
                  )}
                </Button>

                <Separator />

                {/* Back to Login */}
                <div className="text-center">
                  <Button
                    type="button"
                    variant="outline"
                    onClick={() => setViewMode('login')}
                    className="w-full border-green-200 dark:border-green-600 text-green-700 dark:text-green-300 hover:bg-green-50 dark:hover:bg-green-900/20"
                  >
                    <ArrowLeft className="h-4 w-4 mr-2" />
                    {t('backToLogin')}
                  </Button>
                </div>
              </form>
            </CardContent>
          )}
        </Card>

        {/* Demo Credentials */}
        <Card className="mt-4 border-blue-200 dark:border-blue-600 bg-blue-50 dark:bg-blue-900/20">
          <CardContent className="p-4">
            <div className="text-center space-y-2">
              <h4 className="text-sm font-medium text-blue-800 dark:text-blue-300">Demo Credentials</h4>
              <div className="grid grid-cols-2 gap-4 text-xs">
                <div className="space-y-1">
                  <p className="font-medium text-green-700 dark:text-green-400">Farmer:</p>
                  <p className="text-gray-600 dark:text-gray-400">farmer1 / farmer123</p>
                </div>
                <div className="space-y-1">
                  <p className="font-medium text-blue-700 dark:text-blue-400">Admin:</p>
                  <p className="text-gray-600 dark:text-gray-400">admin1 / admin123</p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Footer */}
        <div className="text-center mt-6 text-green-600 dark:text-green-400">
          <p>{t('empoweringFarmers')}</p>
        </div>
      </div>
    </div>
  );
}