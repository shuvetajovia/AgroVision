import React, { useState, useRef, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Badge } from './ui/badge';
import { Separator } from './ui/separator';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Alert, AlertDescription } from './ui/alert';
import { AudioPlayer } from './AudioPlayer';
import { 
  Mic, 
  MicOff, 
  Search, 
  Brain, 
  CheckCircle, 
  AlertTriangle, 
  Info,
  Wheat,
  MessageSquare,
  Volume2,
  User,
  Phone,
  ExternalLink,
  AlertCircle,
  Zap,
  Droplets,
  Bug,
  Pill,
  Calendar,
  MapPin,
  X,
  Globe,
  Languages,
  Loader2,
  Sparkles,
  Send,
  Activity,
  Database,
  Target,
  TrendingUp,
  BookOpen,
  Lightbulb
} from 'lucide-react';
import { useLanguage } from './LanguageContext';
import { toast } from 'sonner@2.0.3';
import { EnhancedCropGPTService, type CropGPTQuery, type CropGPTResponse } from '../services/enhanced-crop-gpt';

const LANGUAGE_OPTIONS = [
  { code: 'en', name: 'English', nativeName: 'English', flag: '🇺🇸' },
  { code: 'hi', name: 'Hindi', nativeName: 'हिन्दी', flag: '🇮🇳' },
  { code: 'ml', name: 'Malayalam', nativeName: 'മലയാളം', flag: '🇮🇳' },
  { code: 'ta', name: 'Tamil', nativeName: 'தமிழ்', flag: '🇮🇳' }
];

const SPEECH_LANG_MAP = {
  'en': 'en-US',
  'hi': 'hi-IN',
  'ml': 'ml-IN',
  'ta': 'ta-IN'
};

export function IntelligentQA() {
  const { t } = useLanguage();
  const [query, setQuery] = useState('');
  const [selectedLanguage, setSelectedLanguage] = useState('en');
  const [isListening, setIsListening] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);
  const [gptResponses, setGptResponses] = useState<CropGPTResponse[]>([]);
  const [detectedLanguage, setDetectedLanguage] = useState<string | null>(null);
  
  // Audio player state
  const [audioPlayer, setAudioPlayer] = useState({
    isVisible: false,
    text: '',
    language: 'en'
  });

  const recognitionRef = useRef<SpeechRecognition | null>(null);

  // Initialize voice recognition
  useEffect(() => {
    if ('webkitSpeechRecognition' in window || 'SpeechRecognition' in window) {
      const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
      recognitionRef.current = new SpeechRecognition();
      recognitionRef.current.continuous = false;
      recognitionRef.current.interimResults = false;
      
      recognitionRef.current.onresult = (event) => {
        const transcript = event.results[0][0].transcript;
        const confidence = event.results[0][0].confidence;
        
        setQuery(transcript);
        
        // Auto-detect language from speech
        const detectedLang = EnhancedCropGPTService.detectLanguage(transcript);
        setDetectedLanguage(detectedLang);
        
        // Auto-process the query
        processGPTQuery(transcript, detectedLang);
        
        setIsListening(false);
        toast.success(`Voice captured with ${Math.round(confidence * 100)}% confidence`);
      };

      recognitionRef.current.onerror = (event) => {
        console.error('Speech recognition error:', event.error);
        setIsListening(false);
        toast.error('Voice recognition failed. Please try again.');
      };

      recognitionRef.current.onend = () => {
        setIsListening(false);
      };
    }
  }, []);

  // Update speech recognition language
  useEffect(() => {
    if (recognitionRef.current) {
      const speechLang = SPEECH_LANG_MAP[selectedLanguage as keyof typeof SPEECH_LANG_MAP] || 'en-US';
      recognitionRef.current.lang = speechLang;
    }
  }, [selectedLanguage]);

  // Process GPT query
  const processGPTQuery = async (queryText: string = query, autoDetectedLang?: string) => {
    if (!queryText.trim()) {
      toast.error('Please enter a question or use voice input');
      return;
    }

    setIsProcessing(true);

    try {
      const gptQuery: CropGPTQuery = {
        text: queryText,
        language: selectedLanguage,
        detectedLanguage: autoDetectedLang,
        audioInput: !!autoDetectedLang
      };

      const response = await EnhancedCropGPTService.processQuery(gptQuery);
      
      setGptResponses(prev => [response, ...prev.slice(0, 4)]); // Keep last 5 responses
      
      if (response.confidence < 0.6) {
        toast.warning('Low confidence response. Consider contacting an expert for detailed advice.');
      } else {
        toast.success(`Expert recommendations generated! ${response.datasetMatches.length} dataset matches found.`);
      }
      
    } catch (error) {
      console.error('GPT processing error:', error);
      toast.error('Failed to process your query. Please try again.');
    } finally {
      setIsProcessing(false);
    }
  };

  // Voice recognition controls
  const startListening = () => {
    if (!recognitionRef.current) {
      toast.error('Voice recognition not supported in this browser');
      return;
    }
    
    setIsListening(true);
    toast.info(`Listening in ${getLanguageName(selectedLanguage)}... Speak now!`);
    recognitionRef.current.start();
  };

  const stopListening = () => {
    if (recognitionRef.current) {
      recognitionRef.current.stop();
    }
    setIsListening(false);
  };

  // Audio player controls
  const playAudio = (text: string, language: string) => {
    setAudioPlayer({
      isVisible: true,
      text,
      language
    });
  };

  const closeAudioPlayer = () => {
    setAudioPlayer({
      isVisible: false,
      text: '',
      language: 'en'
    });
  };

  // Get language name
  const getLanguageName = (code: string): string => {
    const option = LANGUAGE_OPTIONS.find(lang => lang.code === code);
    return option ? option.nativeName : code;
  };

  // Get confidence badge
  const getConfidenceBadge = (confidence: number) => {
    if (confidence >= 0.8) {
      return <Badge className="bg-green-100 text-green-800 border-green-300 dark:bg-green-900 dark:text-green-300">High Confidence</Badge>;
    } else if (confidence >= 0.6) {
      return <Badge className="bg-yellow-100 text-yellow-800 border-yellow-300 dark:bg-yellow-900 dark:text-yellow-300">Medium Confidence</Badge>;
    } else {
      return <Badge className="bg-red-100 text-red-800 border-red-300 dark:bg-red-900 dark:text-red-300">Low Confidence</Badge>;
    }
  };

  // Get category icon
  const getCategoryIcon = (category: string | null) => {
    switch (category) {
      case 'fertilizer': return <Pill className="h-4 w-4 text-green-600" />;
      case 'irrigation': return <Droplets className="h-4 w-4 text-blue-600" />;
      case 'disease': case 'pest': return <Bug className="h-4 w-4 text-red-600" />;
      case 'planting': return <Calendar className="h-4 w-4 text-purple-600" />;
      case 'general': return <BookOpen className="h-4 w-4 text-gray-600" />;
      default: return <Info className="h-4 w-4 text-gray-600" />;
    }
  };

  // Clear responses
  const clearResponses = () => {
    setQuery('');
    setGptResponses([]);
    setDetectedLanguage(null);
    closeAudioPlayer();
  };

  return (
    <div className="max-w-4xl mx-auto p-4 space-y-6 pb-32">
      {/* Header */}
      <Card className="border-green-200 dark:border-green-600 bg-white dark:bg-gray-800">
        <CardHeader className="text-center bg-gradient-to-r from-green-50 to-blue-50 dark:from-gray-700 dark:to-gray-600">
          <CardTitle className="text-xl text-green-800 dark:text-green-300 flex items-center justify-center">
            <Brain className="h-6 w-6 mr-2" />
            Ask Expert - Crop Specialist AI
          </CardTitle>
          <CardDescription className="text-base dark:text-gray-300 flex items-center justify-center gap-2">
            <Database className="h-4 w-4" />
            Agricultural dataset-powered expert advice in your language
          </CardDescription>
        </CardHeader>
      </Card>

      {/* Language Selector */}
      <Card className="border-green-200 dark:border-green-600 bg-white dark:bg-gray-800">
        <CardContent className="p-4">
          <div className="flex flex-col sm:flex-row items-start sm:items-center gap-3">
            <div className="flex items-center gap-2">
              <Languages className="h-5 w-5 text-green-600 dark:text-green-400" />
              <span className="text-sm font-medium text-green-700 dark:text-green-300">
                Response Language:
              </span>
            </div>
            <Select value={selectedLanguage} onValueChange={setSelectedLanguage}>
              <SelectTrigger className="w-[220px] border-green-200 dark:border-green-600">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {LANGUAGE_OPTIONS.map((lang) => (
                  <SelectItem key={lang.code} value={lang.code}>
                    <div className="flex items-center gap-2">
                      <span className="text-lg">{lang.flag}</span>
                      <span>{lang.nativeName}</span>
                    </div>
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            {detectedLanguage && (
              <Badge className="bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-300">
                <Activity className="h-3 w-3 mr-1" />
                Detected: {getLanguageName(detectedLanguage)}
              </Badge>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Input Interface */}
      <Card className="border-green-200 dark:border-green-600 bg-white dark:bg-gray-800">
        <CardContent className="p-6">
          <div className="space-y-4">
            {/* Text Input */}
            <div className="flex flex-col sm:flex-row gap-3">
              <div className="flex-1 relative">
                <Input
                  placeholder="Ask about crops: diseases, fertilizers, irrigation, planting... (English / हिन्दी / മലയാളം / தமிழ்)"
                  value={query}
                  onChange={(e) => setQuery(e.target.value)}
                  onKeyPress={(e) => e.key === 'Enter' && !isProcessing && processGPTQuery()}
                  className="text-lg h-12 pr-12 border-green-200 dark:border-green-600 focus:border-green-400 dark:focus:border-green-400 bg-white dark:bg-gray-700"
                  disabled={isListening || isProcessing}
                />
                <Search className="absolute right-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-green-500 dark:text-green-400" />
              </div>
              
              {/* Voice Button */}
              <Button
                onClick={isListening ? stopListening : startListening}
                variant={isListening ? "destructive" : "outline"}
                size="lg"
                className={`h-12 px-6 ${isListening ? '' : 'border-blue-200 dark:border-blue-600 text-blue-600 dark:text-blue-400 hover:bg-blue-50 dark:hover:bg-blue-900/20'}`}
                disabled={isProcessing}
              >
                {isListening ? (
                  <>
                    <MicOff className="h-5 w-5 mr-2" />
                    Stop
                  </>
                ) : (
                  <>
                    <Mic className="h-5 w-5 mr-2" />
                    Voice
                  </>
                )}
              </Button>
              
              {/* Submit Button */}
              <Button
                onClick={() => processGPTQuery()}
                disabled={!query.trim() || isProcessing}
                size="lg"
                className="h-12 px-8 bg-green-600 hover:bg-green-700 dark:bg-green-700 dark:hover:bg-green-600"
              >
                {isProcessing ? (
                  <>
                    <Loader2 className="h-5 w-5 mr-2 animate-spin" />
                    Processing...
                  </>
                ) : (
                  <>
                    <Send className="h-5 w-5 mr-2" />
                    Ask Expert
                  </>
                )}
              </Button>

              {/* Clear Button */}
              {gptResponses.length > 0 && (
                <Button
                  onClick={clearResponses}
                  variant="outline"
                  size="lg"
                  className="h-12 px-4 border-gray-300 dark:border-gray-600"
                >
                  <X className="h-5 w-5" />
                </Button>
              )}
            </div>

            {/* Voice Listening Status */}
            {isListening && (
              <Alert className="border-blue-200 bg-blue-50 dark:border-blue-600 dark:bg-blue-900/20">
                <Mic className="h-4 w-4 text-blue-600 dark:text-blue-400 animate-pulse" />
                <AlertDescription className="text-blue-800 dark:text-blue-300">
                  <div className="flex items-center gap-2">
                    <div className="w-2 h-2 bg-red-500 rounded-full animate-pulse"></div>
                    <span>🎤 Listening in {getLanguageName(selectedLanguage)}... Speak clearly about your crop question.</span>
                  </div>
                </AlertDescription>
              </Alert>
            )}

            {/* Processing Status */}
            {isProcessing && (
              <Alert className="border-green-200 bg-green-50 dark:border-green-600 dark:bg-green-900/20">
                <Brain className="h-4 w-4 text-green-600 dark:text-green-400" />
                <AlertDescription className="text-green-800 dark:text-green-300">
                  <div className="flex items-center gap-2">
                    <Loader2 className="h-4 w-4 animate-spin" />
                    <span>🧠 Analyzing your query and searching agricultural database...</span>
                  </div>
                </AlertDescription>
              </Alert>
            )}
          </div>
        </CardContent>
      </Card>

      {/* GPT Responses */}
      {gptResponses.map((response) => (
        <Card key={response.id} className="border-blue-200 dark:border-blue-600 bg-white dark:bg-gray-800">
          <CardContent className="p-6">
            <div className="space-y-4">
              {/* Response Header */}
              <div className="flex flex-wrap items-start justify-between gap-2">
                <h4 className="text-base font-medium text-blue-800 dark:text-blue-300 flex-1">
                  <MessageSquare className="h-4 w-4 inline mr-2" />
                  {response.query}
                </h4>
                <div className="flex flex-wrap items-center gap-2">
                  {response.cropDetected && (
                    <Badge className="bg-green-100 text-green-800 border-green-300 dark:bg-green-900 dark:text-green-300 capitalize">
                      <Wheat className="h-3 w-3 mr-1" />
                      {response.cropDetected}
                    </Badge>
                  )}
                  {response.category && (
                    <Badge className="bg-gray-100 text-gray-800 border-gray-300 dark:bg-gray-700 dark:text-gray-300 capitalize">
                      {getCategoryIcon(response.category)}
                      <span className="ml-1">{response.category}</span>
                    </Badge>
                  )}
                  {getConfidenceBadge(response.confidence)}
                  <Badge className="bg-purple-100 text-purple-800 border-purple-300 dark:bg-purple-900 dark:text-purple-300">
                    <Database className="h-3 w-3 mr-1" />
                    {response.datasetMatches.length} matches
                  </Badge>
                </div>
              </div>
              
              <Separator />
              
              {/* Main Response */}
              <div className="bg-blue-50 dark:bg-blue-900/20 p-4 rounded-lg">
                <div className="flex items-start justify-between gap-3">
                  <div className="flex-1">
                    <div className="text-blue-800 dark:text-blue-300 leading-relaxed whitespace-pre-wrap">
                      {response.response}
                    </div>
                  </div>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => playAudio(response.response, response.language)}
                    className="text-blue-600 hover:text-blue-700 dark:text-blue-400 dark:hover:text-blue-300 shrink-0"
                    title="Play Audio"
                  >
                    <Volume2 className="h-4 w-4" />
                  </Button>
                </div>
              </div>

              {/* English Translation */}
              {response.englishTranslation && response.language !== 'en' && (
                <div className="bg-gray-50 dark:bg-gray-700 p-3 rounded-lg">
                  <div className="flex items-start justify-between gap-3">
                    <div className="flex-1">
                      <p className="text-xs text-gray-600 dark:text-gray-400 mb-1 font-medium">
                        🇺🇸 English Translation:
                      </p>
                      <p className="text-sm text-gray-800 dark:text-gray-200 leading-relaxed">
                        {response.englishTranslation}
                      </p>
                    </div>
                  </div>
                </div>
              )}

              {/* Dataset Matches */}
              {response.datasetMatches.length > 0 && (
                <div className="bg-green-50 dark:bg-green-900/20 p-3 rounded-lg">
                  <h5 className="text-sm font-medium text-green-800 dark:text-green-300 mb-2 flex items-center">
                    <Target className="h-4 w-4 mr-1" />
                    Related Dataset Information:
                  </h5>
                  <div className="space-y-2">
                    {response.datasetMatches.slice(0, 2).map((match, index) => (
                      <div key={match.id} className="text-xs text-green-700 dark:text-green-300">
                        <span className="font-medium">Q:</span> {match.question}
                        <br />
                        <span className="font-medium">A:</span> {match.answer.substring(0, 150)}...
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Low Confidence Warning */}
              {response.confidence < 0.6 && (
                <Alert className="border-orange-200 bg-orange-50 dark:border-orange-600 dark:bg-orange-900/20">
                  <AlertCircle className="h-4 w-4 text-orange-600 dark:text-orange-400" />
                  <AlertDescription className="text-orange-800 dark:text-orange-300">
                    <div className="space-y-2">
                      <p className="font-medium">⚠️ Expert Review Recommended</p>
                      <p className="text-sm">This response has low confidence. For critical farming decisions, please consult with a local agricultural expert.</p>
                      <Button
                        onClick={() => window.location.href = '/helpline'}
                        size="sm"
                        className="bg-orange-600 hover:bg-orange-700 text-white"
                      >
                        <Phone className="h-4 w-4 mr-2" />
                        Contact Krishi Officer
                      </Button>
                    </div>
                  </AlertDescription>
                </Alert>
              )}
              
              {/* Metadata */}
              <div className="flex flex-wrap items-center justify-between text-xs text-gray-500 dark:text-gray-400">
                <div className="flex items-center gap-4">
                  <span>Language: {getLanguageName(response.language)}</span>
                  <span>Confidence: {Math.round(response.confidence * 100)}%</span>
                  <span>Generated: {response.timestamp.toLocaleTimeString()}</span>
                </div>
                <div className="flex items-center gap-1">
                  <Sparkles className="h-3 w-3" />
                  <span>AI Agricultural Expert</span>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      ))}

      {/* Welcome Message */}
      {gptResponses.length === 0 && !isProcessing && (
        <Card className="border-gray-200 dark:border-gray-600 bg-gray-50 dark:bg-gray-800/50">
          <CardContent className="p-8 text-center">
            <Brain className="h-16 w-16 text-gray-400 dark:text-gray-500 mx-auto mb-4" />
            <h3 className="text-lg font-medium text-gray-600 dark:text-gray-400 mb-2">
              🌾 Crop Specialist AI Ready to Help
            </h3>
            <p className="text-gray-500 dark:text-gray-400 mb-6 max-w-md mx-auto">
              Ask me anything about farming in your preferred language. I'll provide expert recommendations 
              based on our comprehensive agricultural dataset with real crop-specific information.
            </p>
            
            {/* Language Examples */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
              <div className="space-y-2">
                <h4 className="text-sm font-medium text-gray-700 dark:text-gray-300">📝 Example Questions:</h4>
                <div className="space-y-1 text-xs text-gray-600 dark:text-gray-400">
                  <p>🇺🇸 "How to control brown spot in rice?"</p>
                  <p>🇮🇳 "धान में भूरे धब्बे कैसे नियंत्रित करें?"</p>
                  <p>🇮🇳 "നെല്ലിൽ തവിട്ട് പാട് എങ്ങനെ നിയന്ത്രിക്കാം?"</p>
                  <p>🇮🇳 "நெல்லில் பழுப்பு புள்ளி எப்படி கட்டுப்படுத்துவது?"</p>
                </div>
              </div>
              <div className="space-y-2">
                <h4 className="text-sm font-medium text-gray-700 dark:text-gray-300">🔍 Available Crops:</h4>
                <div className="flex flex-wrap justify-center gap-2 text-xs">
                  <Badge variant="outline">🌾 Rice / धान / നെല്ല് / நெல்</Badge>
                  <Badge variant="outline">🌾 Wheat / गेहूं / ഗോതമ്പ് / கோதுமை</Badge>
                  <Badge variant="outline">🌽 Maize / मक्का / ചോളം / மக்காச்சோளம்</Badge>
                  <Badge variant="outline">🍅 Tomato / टमाटर / തക്കാളി / தக்காளி</Badge>
                  <Badge variant="outline">🌿 Cotton / कपास / പരുത്തി / பருத்தி</Badge>
                  <Badge variant="outline">🥔 Potato / आलू / ഉരുളക്കിഴങ്ങ് / உருளைக்கிழங்கு</Badge>
                </div>
              </div>
            </div>
            
            <div className="space-y-2">
              <h4 className="text-sm font-medium text-gray-700 dark:text-gray-300">🎯 Expert Topics:</h4>
              <div className="flex flex-wrap justify-center gap-2 text-xs">
                <Badge variant="outline">🦠 Disease Management</Badge>
                <Badge variant="outline">🌱 Fertilizer Recommendations</Badge>
                <Badge variant="outline">💧 Irrigation Guidelines</Badge>
                <Badge variant="outline">🐛 Pest Control</Badge>
                <Badge variant="outline">📅 Planting Schedules</Badge>
                <Badge variant="outline">🌡️ Seasonal Advice</Badge>
              </div>
            </div>
            
            <p className="text-xs text-gray-400 dark:text-gray-500 mt-4">
              🎤 Use voice input or type your question • 🧠 Automatic language detection • 📊 Dataset-powered responses
            </p>
          </CardContent>
        </Card>
      )}

      {/* Audio Player */}
      <AudioPlayer
        isVisible={audioPlayer.isVisible}
        text={audioPlayer.text}
        language={audioPlayer.language}
        onClose={closeAudioPlayer}
      />
    </div>
  );
}