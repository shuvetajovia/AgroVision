import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Separator } from './ui/separator';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Alert, AlertDescription } from './ui/alert';
import { Progress } from './ui/progress';
import { AudioPlayer } from './AudioPlayer';
import { 
  Calendar, 
  Droplets, 
  MapPin, 
  CloudRain, 
  Thermometer,
  Leaf,
  Clock,
  Target,
  TrendingUp,
  Volume2,
  RefreshCw,
  Loader2,
  CheckCircle,
  AlertTriangle,
  Info,
  Sunrise,
  Sunset,
  Activity,
  BarChart3,
  Zap,
  Brain,
  Globe,
  Languages,
  Download,
  Share2,
  BookOpen,
  Lightbulb,

} from 'lucide-react';
import { useLanguage } from './LanguageContext';
import { toast } from 'sonner@2.0.3';
import { CropCalendarGPTService, type CropCalendarQuery, type CropCalendarResponse, type IrrigationPlan } from '../services/crop-calendar-gpt';

const LANGUAGE_OPTIONS = [
  { code: 'en', name: 'English', nativeName: 'English' },
  { code: 'hi', name: 'Hindi', nativeName: 'हिन्दी' },
  { code: 'ml', name: 'Malayalam', nativeName: 'മലയാളം' },
  { code: 'ta', name: 'Tamil', nativeName: 'தமிழ்' }
];

const CROP_OPTIONS = [
  { value: 'rice', label: 'Rice / धान / നെല്ല് / நெல்' },
  { value: 'wheat', label: 'Wheat / गेहूं / ഗോതമ്പ് / கோதுமை' },
  { value: 'tomato', label: 'Tomato / टमाटर / തക്കാളി / தக்காளி' },
  { value: 'cotton', label: 'Cotton / कपास / പരുത്തി / பருத்தி' },
  { value: 'maize', label: 'Maize / मक्का / ചോളം / மக்காச்சோளம்' }
];

const SEASON_OPTIONS = [
  { value: 'kharif', label: 'Kharif (Monsoon) / खरीफ / ഖരീഫ് / கரீப்' },
  { value: 'rabi', label: 'Rabi (Winter) / रबी / റാബി / ரபி' },
  { value: 'summer', label: 'Summer / गर्मी / വേനൽ / கோடை' },
  { value: 'winter', label: 'Winter / सर्दी / ശൈത്യ / குளிர்காலம्' }
];

const LOCATION_OPTIONS = [
  { value: 'kerala', label: 'Kerala / केरल / കേരളം / கேரளா' },
  { value: 'punjab', label: 'Punjab / पंजाब / പഞ്ചാബ് / பஞ்சாப்' },
  { value: 'maharashtra', label: 'Maharashtra / महाराष्ट्र / മഹാരാഷ്ട്ര / மஹாராஷ்டிரா' },
  { value: 'tamilnadu', label: 'Tamil Nadu / तमिल नाडु / തമിഴ്നാട് / தமிழ்நாடு' },
  { value: 'karnataka', label: 'Karnataka / कर्नाटक / കർണാടക / கர்நாடகா' }
];

export function CropCalendar() {
  const { t } = useLanguage();
  const [selectedLanguage, setSelectedLanguage] = useState('en');
  const [selectedCrop, setSelectedCrop] = useState('rice');
  const [selectedSeason, setSelectedSeason] = useState('kharif');
  const [selectedLocation, setSelectedLocation] = useState('kerala');
  const [isLoading, setIsLoading] = useState(false);
  const [calendarData, setCalendarData] = useState<CropCalendarResponse | null>(null);
  const [activeStage, setActiveStage] = useState<number | null>(null);
  
  // Audio player state
  const [audioPlayer, setAudioPlayer] = useState({
    isVisible: false,
    text: '',
    language: 'en'
  });

  // Auto-generate calendar on component load
  useEffect(() => {
    generateCalendar();
  }, []);

  const generateCalendar = async () => {
    setIsLoading(true);
    
    try {
      const query: CropCalendarQuery = {
        crop: selectedCrop,
        location: selectedLocation,
        season: selectedSeason,
        language: selectedLanguage
      };

      const response = await CropCalendarGPTService.generateCropCalendar(query);
      setCalendarData(response);
      toast.success('Crop calendar generated successfully!');
      
    } catch (error) {
      console.error('Error generating calendar:', error);
      toast.error('Failed to generate crop calendar. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  const playAudio = (text: string, language: string) => {
    setAudioPlayer({
      isVisible: true,
      text,
      language
    });
  };

  const closeAudioPlayer = () => {
    setAudioPlayer({
      isVisible: false,
      text: '',
      language: 'en'
    });
  };

  const getLanguageName = (code: string): string => {
    const option = LANGUAGE_OPTIONS.find(lang => lang.code === code);
    return option ? option.nativeName : code;
  };

  const getStageIcon = (stage: string) => {
    const stageIcons: Record<string, React.ReactNode> = {
      'Land Preparation': <Leaf className="h-4 w-4" />,
      'भूमि तैयारी': <Leaf className="h-4 w-4" />,
      'ഭൂമി തയ്യാറാക്കൽ': <Leaf className="h-4 w-4" />,
      'நில தயாரிப்பு': <Leaf className="h-4 w-4" />,
      'Transplanting': <Activity className="h-4 w-4" />,
      'रोपाई': <Activity className="h-4 w-4" />,
      'നടീൽ': <Activity className="h-4 w-4" />,
      'நடவு': <Activity className="h-4 w-4" />,
      'Sowing': <Activity className="h-4 w-4" />,
      'Nursery': <Sunrise className="h-4 w-4" />,
      'Flowering': <Target className="h-4 w-4" />,
      'Maturity': <Sunset className="h-4 w-4" />
    };
    
    return stageIcons[stage] || <Droplets className="h-4 w-4" />;
  };

  const getStageColor = (daysAfterSowing: number) => {
    if (daysAfterSowing < 0) return 'bg-gray-100 border-gray-300 text-gray-700';
    if (daysAfterSowing < 30) return 'bg-green-100 border-green-300 text-green-700';
    if (daysAfterSowing < 60) return 'bg-blue-100 border-blue-300 text-blue-700';
    if (daysAfterSowing < 90) return 'bg-yellow-100 border-yellow-300 text-yellow-700';
    return 'bg-purple-100 border-purple-300 text-purple-700';
  };

  const calculateProgress = (stage: IrrigationPlan, totalDuration: number) => {
    const progress = ((stage.daysAfterSowing + 15) / (totalDuration + 15)) * 100;
    return Math.max(0, Math.min(100, progress));
  };

  return (
    <div className="max-w-6xl mx-auto p-4 space-y-6 pb-32">
      {/* Header */}
      <Card className="border-green-200 dark:border-green-600 bg-white dark:bg-gray-800">
        <CardHeader className="text-center bg-gradient-to-r from-green-50 to-blue-50 dark:from-gray-700 dark:to-gray-600">
          <CardTitle className="text-2xl text-green-800 dark:text-green-300 flex items-center justify-center">
            <Calendar className="h-7 w-7 mr-3" />
            Crop Calendar & Irrigation Planning
          </CardTitle>
          <CardDescription className="text-lg dark:text-gray-300 flex items-center justify-center gap-2">
            <Brain className="h-5 w-5" />
            AI-powered seasonal planning for optimal crop management
          </CardDescription>
        </CardHeader>
      </Card>

      {/* Control Panel */}
      <Card className="border-green-200 dark:border-green-600 bg-white dark:bg-gray-800">
        <CardHeader>
          <CardTitle className="text-lg text-green-800 dark:text-green-300 flex items-center">
            <BarChart3 className="h-5 w-5 mr-2" />
            Planning Parameters
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {/* Language Selector */}
          <div className="flex flex-col sm:flex-row items-start sm:items-center gap-3">
            <div className="flex items-center gap-2 min-w-[120px]">
              <Languages className="h-4 w-4 text-green-600 dark:text-green-400" />
              <span className="text-sm font-medium text-green-700 dark:text-green-300">Language:</span>
            </div>
            <Select value={selectedLanguage} onValueChange={setSelectedLanguage}>
              <SelectTrigger className="w-[200px] border-green-200 dark:border-green-600">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {LANGUAGE_OPTIONS.map((lang) => (
                  <SelectItem key={lang.code} value={lang.code}>
                    <div className="flex items-center gap-2">
                      <Globe className="h-4 w-4" />
                      <span>{lang.nativeName}</span>
                    </div>
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* Selection Grid */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {/* Crop Selection */}
            <div className="space-y-2">
              <label className="text-sm font-medium text-gray-700 dark:text-gray-300 flex items-center">
                <Leaf className="h-4 w-4 mr-2 text-green-600" />
                Select Crop
              </label>
              <Select value={selectedCrop} onValueChange={setSelectedCrop}>
                <SelectTrigger className="border-green-200 dark:border-green-600">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {CROP_OPTIONS.map((crop) => (
                    <SelectItem key={crop.value} value={crop.value}>
                      {crop.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {/* Season Selection */}
            <div className="space-y-2">
              <label className="text-sm font-medium text-gray-700 dark:text-gray-300 flex items-center">
                <CloudRain className="h-4 w-4 mr-2 text-blue-600" />
                Select Season
              </label>
              <Select value={selectedSeason} onValueChange={setSelectedSeason}>
                <SelectTrigger className="border-blue-200 dark:border-blue-600">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {SEASON_OPTIONS.map((season) => (
                    <SelectItem key={season.value} value={season.value}>
                      {season.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {/* Location Selection */}
            <div className="space-y-2">
              <label className="text-sm font-medium text-gray-700 dark:text-gray-300 flex items-center">
                <MapPin className="h-4 w-4 mr-2 text-purple-600" />
                Select Location
              </label>
              <Select value={selectedLocation} onValueChange={setSelectedLocation}>
                <SelectTrigger className="border-purple-200 dark:border-purple-600">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {LOCATION_OPTIONS.map((location) => (
                    <SelectItem key={location.value} value={location.value}>
                      {location.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          {/* Generate Button */}
          <div className="flex justify-center pt-4">
            <Button
              onClick={generateCalendar}
              disabled={isLoading}
              size="lg"
              className="bg-green-600 hover:bg-green-700 dark:bg-green-700 dark:hover:bg-green-600 px-8"
            >
              {isLoading ? (
                <>
                  <Loader2 className="h-5 w-5 mr-2 animate-spin" />
                  Generating Calendar...
                </>
              ) : (
                <>
                  <Zap className="h-5 w-5 mr-2" />
                  Generate Smart Calendar
                </>
              )}
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Calendar Results */}
      {calendarData && (
        <div className="space-y-6">
          {/* Overview Cards */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            {/* Planting Window */}
            <Card className="border-green-200 dark:border-green-600 bg-gradient-to-br from-green-50 to-green-100 dark:from-green-900/20 dark:to-green-800/20">
              <CardContent className="p-4">
                <div className="flex items-center space-x-3">
                  <div className="p-2 bg-green-200 dark:bg-green-800 rounded-lg">
                    <Sunrise className="h-6 w-6 text-green-800 dark:text-green-200" />
                  </div>
                  <div>
                    <p className="text-sm text-green-600 dark:text-green-400">Planting Window</p>
                    <p className="font-medium text-green-800 dark:text-green-200 text-sm">
                      {calendarData.plantingWindow.optimal}
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Harvest Window */}
            <Card className="border-orange-200 dark:border-orange-600 bg-gradient-to-br from-orange-50 to-orange-100 dark:from-orange-900/20 dark:to-orange-800/20">
              <CardContent className="p-4">
                <div className="flex items-center space-x-3">
                  <div className="p-2 bg-orange-200 dark:bg-orange-800 rounded-lg">
                    <Sunset className="h-6 w-6 text-orange-800 dark:text-orange-200" />
                  </div>
                  <div>
                    <p className="text-sm text-orange-600 dark:text-orange-400">Harvest Window</p>
                    <p className="font-medium text-orange-800 dark:text-orange-200 text-sm">
                      {calendarData.harvestWindow.optimal}
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Growth Duration */}
            <Card className="border-blue-200 dark:border-blue-600 bg-gradient-to-br from-blue-50 to-blue-100 dark:from-blue-900/20 dark:to-blue-800/20">
              <CardContent className="p-4">
                <div className="flex items-center space-x-3">
                  <div className="p-2 bg-blue-200 dark:bg-blue-800 rounded-lg">
                    <Clock className="h-6 w-6 text-blue-800 dark:text-blue-200" />
                  </div>
                  <div>
                    <p className="text-sm text-blue-600 dark:text-blue-400">Growth Duration</p>
                    <p className="font-medium text-blue-800 dark:text-blue-200 text-sm">
                      {calendarData.growthDuration}
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Expected Yield */}
            <Card className="border-purple-200 dark:border-purple-600 bg-gradient-to-br from-purple-50 to-purple-100 dark:from-purple-900/20 dark:to-purple-800/20">
              <CardContent className="p-4">
                <div className="flex items-center space-x-3">
                  <div className="p-2 bg-purple-200 dark:bg-purple-800 rounded-lg">
                    <TrendingUp className="h-6 w-6 text-purple-800 dark:text-purple-200" />
                  </div>
                  <div>
                    <p className="text-sm text-purple-600 dark:text-purple-400">Expected Yield</p>
                    <p className="font-medium text-purple-800 dark:text-purple-200 text-sm">
                      {calendarData.expectedYield}
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Irrigation Schedule */}
          <Card className="border-blue-200 dark:border-blue-600 bg-white dark:bg-gray-800">
            <CardHeader>
              <CardTitle className="text-xl text-blue-800 dark:text-blue-300 flex items-center justify-between">
                <div className="flex items-center">
                  <Droplets className="h-6 w-6 mr-3" />
                  Smart Irrigation Schedule
                </div>
                <div className="flex items-center gap-2">
                  <Badge className="bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-300">
                    <Droplets className="h-3 w-3 mr-1" />
                    {calendarData.totalWaterRequirement}
                  </Badge>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => playAudio(
                      calendarData.irrigationPlan.map(stage => 
                        `${stage.stage}: ${stage.waterRequirement} water every ${stage.frequency}. ${stage.notes}`
                      ).join('. '),
                      calendarData.language
                    )}
                    className="text-blue-600 hover:text-blue-700 dark:text-blue-400"
                  >
                    <Volume2 className="h-4 w-4" />
                  </Button>
                </div>
              </CardTitle>
              <CardDescription className="dark:text-gray-300">
                Detailed irrigation plan for optimal water management
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {calendarData.irrigationPlan.map((stage, index) => {
                const totalDuration = parseInt(calendarData.growthDuration.split('-')[1] || '130');
                const progress = calculateProgress(stage, totalDuration);
                
                return (
                  <div
                    key={index}
                    className={`p-4 border rounded-lg transition-all cursor-pointer ${
                      activeStage === index 
                        ? 'border-blue-400 bg-blue-50 dark:bg-blue-900/20' 
                        : 'border-gray-200 dark:border-gray-600 hover:border-blue-300 dark:hover:border-blue-500'
                    }`}
                    onClick={() => setActiveStage(activeStage === index ? null : index)}
                  >
                    <div className="flex items-center justify-between mb-3">
                      <div className="flex items-center space-x-3">
                        <div className={`p-2 rounded-lg ${getStageColor(stage.daysAfterSowing)}`}>
                          {getStageIcon(stage.stage)}
                        </div>
                        <div>
                          <h4 className="font-medium text-gray-800 dark:text-gray-200">
                            {stage.stage}
                          </h4>
                          <p className="text-sm text-gray-600 dark:text-gray-400">
                            {stage.daysAfterSowing >= 0 
                              ? `Day ${stage.daysAfterSowing}` 
                              : `${Math.abs(stage.daysAfterSowing)} days before sowing`
                            }
                          </p>
                        </div>
                      </div>
                      <div className="text-right">
                        <Badge className="bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-300">
                          {stage.waterRequirement}
                        </Badge>
                        <p className="text-sm text-gray-600 dark:text-gray-400 mt-1">
                          {stage.frequency}
                        </p>
                      </div>
                    </div>
                    
                    {/* Progress Bar */}
                    <div className="mb-3">
                      <Progress value={progress} className="h-2" />
                      <div className="flex justify-between text-xs text-gray-500 mt-1">
                        <span>Start</span>
                        <span>{Math.round(progress)}% of growing season</span>
                        <span>Harvest</span>
                      </div>
                    </div>

                    {/* Detailed Notes */}
                    {activeStage === index && (
                      <div className="mt-4 p-3 bg-gray-50 dark:bg-gray-700 rounded-lg">
                        <p className="text-sm text-gray-700 dark:text-gray-300 mb-2">
                          <strong>Notes:</strong> {stage.notes}
                        </p>
                        <div className="flex flex-wrap gap-2">
                          <Badge variant="outline" className="text-xs">
                            <Clock className="h-3 w-3 mr-1" />
                            {stage.frequency}
                          </Badge>
                          <Badge variant="outline" className="text-xs">
                            <Droplets className="h-3 w-3 mr-1" />
                            {stage.waterRequirement}
                          </Badge>
                        </div>
                      </div>
                    )}
                  </div>
                );
              })}
            </CardContent>
          </Card>

          {/* Seasonal Tips & Climate Considerations */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Seasonal Tips */}
            <Card className="border-green-200 dark:border-green-600 bg-white dark:bg-gray-800">
              <CardHeader>
                <CardTitle className="text-lg text-green-800 dark:text-green-300 flex items-center justify-between">
                  <div className="flex items-center">
                    <Lightbulb className="h-5 w-5 mr-2" />
                    Seasonal Tips
                  </div>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => playAudio(
                      calendarData.seasonalTips.join('. '),
                      calendarData.language
                    )}
                    className="text-green-600 hover:text-green-700 dark:text-green-400"
                  >
                    <Volume2 className="h-4 w-4" />
                  </Button>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <ul className="space-y-3">
                  {calendarData.seasonalTips.map((tip, index) => (
                    <li key={index} className="flex items-start space-x-3">
                      <CheckCircle className="h-4 w-4 text-green-600 dark:text-green-400 mt-0.5 shrink-0" />
                      <span className="text-sm text-gray-700 dark:text-gray-300">{tip}</span>
                    </li>
                  ))}
                </ul>
                
                {/* English Translation */}
                {calendarData.englishTranslation && calendarData.language !== 'en' && (
                  <div className="mt-6 pt-4 border-t border-gray-200 dark:border-gray-600">
                    <p className="text-xs text-gray-500 dark:text-gray-400 mb-3 font-medium">
                      English Translation:
                    </p>
                    <ul className="space-y-2">
                      {calendarData.englishTranslation.seasonalTips.map((tip, index) => (
                        <li key={index} className="flex items-start space-x-2">
                          <span className="text-xs text-gray-400 mt-1">•</span>
                          <span className="text-xs text-gray-600 dark:text-gray-400">{tip}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Climate Considerations */}
            <Card className="border-orange-200 dark:border-orange-600 bg-white dark:bg-gray-800">
              <CardHeader>
                <CardTitle className="text-lg text-orange-800 dark:text-orange-300 flex items-center justify-between">
                  <div className="flex items-center">
                    <Thermometer className="h-5 w-5 mr-2" />
                    Climate Considerations
                  </div>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => playAudio(
                      calendarData.climateConsiderations.join('. '),
                      calendarData.language
                    )}
                    className="text-orange-600 hover:text-orange-700 dark:text-orange-400"
                  >
                    <Volume2 className="h-4 w-4" />
                  </Button>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <ul className="space-y-3">
                  {calendarData.climateConsiderations.map((consideration, index) => (
                    <li key={index} className="flex items-start space-x-3">
                      <AlertTriangle className="h-4 w-4 text-orange-600 dark:text-orange-400 mt-0.5 shrink-0" />
                      <span className="text-sm text-gray-700 dark:text-gray-300">{consideration}</span>
                    </li>
                  ))}
                </ul>
                
                {/* English Translation */}
                {calendarData.englishTranslation && calendarData.language !== 'en' && (
                  <div className="mt-6 pt-4 border-t border-gray-200 dark:border-gray-600">
                    <p className="text-xs text-gray-500 dark:text-gray-400 mb-3 font-medium">
                      English Translation:
                    </p>
                    <ul className="space-y-2">
                      {calendarData.englishTranslation.climateConsiderations.map((consideration, index) => (
                        <li key={index} className="flex items-start space-x-2">
                          <span className="text-xs text-gray-400 mt-1">•</span>
                          <span className="text-xs text-gray-600 dark:text-gray-400">{consideration}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>

          {/* Action Buttons */}
          <div className="flex flex-wrap gap-3 justify-center">
            <Button
              onClick={() => toast.info('Download feature coming soon!')}
              variant="outline"
              className="border-green-600 text-green-600 hover:bg-green-50 dark:border-green-500 dark:text-green-400"
            >
              <Download className="h-4 w-4 mr-2" />
              Download Calendar
            </Button>
            <Button
              onClick={() => toast.info('Share feature coming soon!')}
              variant="outline"
              className="border-blue-600 text-blue-600 hover:bg-blue-50 dark:border-blue-500 dark:text-blue-400"
            >
              <Share2 className="h-4 w-4 mr-2" />
              Share Plan
            </Button>
            <Button
              onClick={() => playAudio(
                `Crop calendar for ${calendarData.crop} in ${calendarData.season} season. Planting from ${calendarData.plantingWindow.optimal}. Harvest from ${calendarData.harvestWindow.optimal}. Total water requirement ${calendarData.totalWaterRequirement}.`,
                calendarData.language
              )}
              variant="outline"
              className="border-purple-600 text-purple-600 hover:bg-purple-50 dark:border-purple-500 dark:text-purple-400"
            >
              <Volume2 className="h-4 w-4 mr-2" />
              Play Summary
            </Button>
          </div>

          {/* Metadata */}
          <Card className="border-gray-200 dark:border-gray-600 bg-gray-50 dark:bg-gray-800/50">
            <CardContent className="p-4">
              <div className="flex flex-wrap items-center justify-between text-sm text-gray-600 dark:text-gray-400">
                <div className="flex items-center gap-4">
                  <span>Language: {getLanguageName(calendarData.language)}</span>
                  <span>Location: {calendarData.location}</span>
                  <span>Season: {calendarData.season}</span>
                </div>
                <div className="flex items-center gap-2">
                  <Brain className="h-4 w-4" />
                  <span>Generated: {calendarData.timestamp.toLocaleTimeString()}</span>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      )}

      {/* Welcome Message */}
      {!calendarData && !isLoading && (
        <Card className="border-gray-200 dark:border-gray-600 bg-gray-50 dark:bg-gray-800/50">
          <CardContent className="p-8 text-center">
            <Calendar className="h-16 w-16 text-gray-400 dark:text-gray-500 mx-auto mb-4" />
            <h3 className="text-lg font-medium text-gray-600 dark:text-gray-400 mb-2">
              AI-Powered Crop Calendar & Irrigation Planning
            </h3>
            <p className="text-gray-500 dark:text-gray-400 mb-6 max-w-2xl mx-auto">
              Get intelligent crop calendars and irrigation schedules based on your location, 
              climate data, and seasonal patterns. Our GPT-powered system provides precise 
              recommendations in your preferred language.
            </p>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
              <div className="flex flex-col items-center space-y-2">
                <div className="p-3 bg-green-100 dark:bg-green-900/20 rounded-full">
                  <Leaf className="h-6 w-6 text-green-600 dark:text-green-400" />
                </div>
                <h4 className="font-medium text-gray-700 dark:text-gray-300">Smart Planning</h4>
                <p className="text-sm text-gray-600 dark:text-gray-400 text-center">
                  AI-generated crop calendars based on climate and location
                </p>
              </div>
              <div className="flex flex-col items-center space-y-2">
                <div className="p-3 bg-blue-100 dark:bg-blue-900/20 rounded-full">
                  <Droplets className="h-6 w-6 text-blue-600 dark:text-blue-400" />
                </div>
                <h4 className="font-medium text-gray-700 dark:text-gray-300">Irrigation Schedule</h4>
                <p className="text-sm text-gray-600 dark:text-gray-400 text-center">
                  Detailed water management plans for each growth stage
                </p>
              </div>
              <div className="flex flex-col items-center space-y-2">
                <div className="p-3 bg-purple-100 dark:bg-purple-900/20 rounded-full">
                  <Languages className="h-6 w-6 text-purple-600 dark:text-purple-400" />
                </div>
                <h4 className="font-medium text-gray-700 dark:text-gray-300">Multilingual</h4>
                <p className="text-sm text-gray-600 dark:text-gray-400 text-center">
                  Available in English, Hindi, Malayalam, and Tamil
                </p>
              </div>
            </div>
            
            <p className="text-xs text-gray-400 dark:text-gray-500">
              🤖 Powered by agricultural AI • 📅 Season-specific recommendations • 🌧️ Climate-adaptive planning
            </p>
          </CardContent>
        </Card>
      )}

      {/* Audio Player */}
      <AudioPlayer
        isVisible={audioPlayer.isVisible}
        text={audioPlayer.text}
        language={audioPlayer.language}
        onClose={closeAudioPlayer}
      />
    </div>
  );
}