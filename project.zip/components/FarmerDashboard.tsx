import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { VoiceInputModal } from './VoiceInputModal';
import { PhotoUploadModal } from './PhotoUploadModal';
import { TextMessagingModal } from './TextMessagingModal';
import { WeatherWidget } from './WeatherWidget';
import { MarketPricesWidget } from './MarketPricesWidget';
import { useLanguage } from './LanguageContext';
import { ThemeSwitcher } from './ThemeSwitcher';
import { 
  Wheat, 
  Cloud, 
  TrendingUp, 
  Users, 
  Leaf,
  Sun,
  Droplets,
  Thermometer,
  Menu,
  MessageSquare,
  ArrowRight
} from 'lucide-react';

interface FarmerDashboardProps {
  setActiveTab: (tab: string) => void;
}

export function FarmerDashboard({ setActiveTab }: FarmerDashboardProps) {
  const { t } = useLanguage();
  const [voiceModalOpen, setVoiceModalOpen] = useState(false);
  const [photoModalOpen, setPhotoModalOpen] = useState(false);
  const [textModalOpen, setTextModalOpen] = useState(false);
  
  return (
    <div className="p-4 md:p-6 space-y-6 relative">
      {/* Theme Switcher for larger screens */}
      <div className="hidden md:block fixed top-4 right-4 z-40">
        <ThemeSwitcher />
      </div>
      
      {/* Welcome Header */}
      <div className="text-center mb-8">
        <h1 className="text-2xl md:text-3xl text-green-800 dark:text-green-300 mb-2">{t('welcome')}</h1>
        <p className="text-green-600 dark:text-green-400">Your one-stop solution for smart farming decisions</p>
      </div>

      {/* Quick Stats */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <Card className="border-green-200 dark:border-green-600 bg-white dark:bg-gray-800 hover:shadow-md transition-shadow">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm text-green-700 dark:text-green-300">Today's Weather</CardTitle>
            <Sun className="h-4 w-4 text-orange-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl text-green-800 dark:text-green-300 mb-1">28°C</div>
            <p className="text-xs text-green-600 dark:text-green-400">Sunny, Good for harvesting</p>
          </CardContent>
        </Card>

        <Card className="border-green-200 dark:border-green-600 bg-white dark:bg-gray-800 hover:shadow-md transition-shadow">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm text-green-700 dark:text-green-300">Rainfall This Week</CardTitle>
            <Droplets className="h-4 w-4 text-blue-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl text-green-800 dark:text-green-300 mb-1">25mm</div>
            <p className="text-xs text-green-600 dark:text-green-400">Adequate for crops</p>
          </CardContent>
        </Card>

        <Card className="border-green-200 dark:border-green-600 bg-white dark:bg-gray-800 hover:shadow-md transition-shadow">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm text-green-700 dark:text-green-300">Crop Health</CardTitle>
            <Leaf className="h-4 w-4 text-green-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl text-green-800 dark:text-green-300 mb-1">Good</div>
            <p className="text-xs text-green-600 dark:text-green-400">No disease detected</p>
          </CardContent>
        </Card>

        <Card className="border-green-200 dark:border-green-600 bg-white dark:bg-gray-800 hover:shadow-md transition-shadow">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm text-green-700 dark:text-green-300">Market Trend</CardTitle>
            <TrendingUp className="h-4 w-4 text-green-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl text-green-800 dark:text-green-300 mb-1">↗ 12%</div>
            <p className="text-xs text-green-600 dark:text-green-400">Rice prices rising</p>
          </CardContent>
        </Card>
      </div>

      {/* Main Content Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Weather Widget */}
        <div className="lg:col-span-1">
          <WeatherWidget />
        </div>
        
        {/* Market Prices Widget */}
        <div className="lg:col-span-2">
          <MarketPricesWidget />
        </div>
      </div>

      {/* Featured: Smart Q&A Section */}
      <Card className="border-blue-200 dark:border-blue-600 bg-gradient-to-r from-blue-50 to-green-50 dark:from-blue-900/20 dark:to-green-900/20">
        <CardContent className="p-6">
          <div className="flex flex-col md:flex-row items-center justify-between space-y-4 md:space-y-0">
            <div className="flex items-center space-x-4">
              <div className="bg-blue-600 dark:bg-blue-700 p-3 rounded-full">
                <MessageSquare className="h-8 w-8 text-white" />
              </div>
              <div>
                <h3 className="text-xl font-semibold text-blue-800 dark:text-blue-300 mb-1">
                  🤖 Smart Farming Assistant
                </h3>
                <p className="text-blue-700 dark:text-blue-400 mb-2">
                  Get instant answers to all your farming questions from our agricultural knowledge base
                </p>
                <div className="flex flex-wrap gap-2 text-sm">
                  <span className="bg-blue-100 dark:bg-blue-800 text-blue-700 dark:text-blue-200 px-2 py-1 rounded">Disease Control</span>
                  <span className="bg-green-100 dark:bg-green-800 text-green-700 dark:text-green-200 px-2 py-1 rounded">Fertilizer Advice</span>
                  <span className="bg-orange-100 dark:bg-orange-800 text-orange-700 dark:text-orange-200 px-2 py-1 rounded">Planting Times</span>
                  <span className="bg-purple-100 dark:bg-purple-800 text-purple-700 dark:text-purple-200 px-2 py-1 rounded">Pest Management</span>
                </div>
              </div>
            </div>
            <div className="flex flex-col sm:flex-row gap-3">
              <div className="text-center">
                <div className="text-2xl font-bold text-blue-800 dark:text-blue-300">1000+</div>
                <div className="text-xs text-blue-600 dark:text-blue-400">Expert Answers</div>
              </div>
              <button
                onClick={() => setActiveTab('qa')}
                className="bg-blue-600 hover:bg-blue-700 dark:bg-blue-700 dark:hover:bg-blue-600 text-white px-6 py-3 rounded-lg font-medium transition-colors flex items-center space-x-2 group"
              >
                <span>Ask Expert Now</span>
                <ArrowRight className="h-4 w-4 group-hover:translate-x-1 transition-transform" />
              </button>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Quick Actions & Recent Activity */}
      <div className="grid md:grid-cols-2 gap-6">
        {/* Quick Actions */}
        <Card className="border-green-200 dark:border-green-600 bg-white dark:bg-gray-800">
          <CardHeader className="bg-green-50 dark:bg-gray-700">
            <CardTitle className="text-green-800 dark:text-green-300">{t('quickActions')}</CardTitle>
            <CardDescription className="dark:text-gray-400">Common farming tasks and assistance</CardDescription>
          </CardHeader>
          <CardContent className="pt-4">
            <div className="grid grid-cols-2 gap-3">
              <button
                onClick={() => setPhotoModalOpen(true)}
                className="p-3 md:p-4 bg-green-50 dark:bg-gray-700 rounded-lg text-center hover:bg-green-100 dark:hover:bg-gray-600 cursor-pointer transition-colors"
              >
                <Wheat className="h-6 w-6 md:h-8 md:w-8 text-green-600 dark:text-green-400 mx-auto mb-2" />
                <p className="text-xs md:text-sm text-green-700 dark:text-green-300">Crop Disease Detection</p>
              </button>
              <button
                onClick={() => setTextModalOpen(true)}
                className="p-3 md:p-4 bg-green-50 dark:bg-gray-700 rounded-lg text-center hover:bg-green-100 dark:hover:bg-gray-600 cursor-pointer transition-colors"
              >
                <Cloud className="h-6 w-6 md:h-8 md:w-8 text-blue-600 dark:text-blue-400 mx-auto mb-2" />
                <p className="text-xs md:text-sm text-green-700 dark:text-green-300">Weather Forecast</p>
              </button>
              <button
                onClick={() => setTextModalOpen(true)}
                className="p-3 md:p-4 bg-green-50 dark:bg-gray-700 rounded-lg text-center hover:bg-green-100 dark:hover:bg-gray-600 cursor-pointer transition-colors"
              >
                <TrendingUp className="h-6 w-6 md:h-8 md:w-8 text-orange-600 dark:text-orange-400 mx-auto mb-2" />
                <p className="text-xs md:text-sm text-green-700 dark:text-green-300">Market Prices</p>
              </button>
              <button
                onClick={() => setVoiceModalOpen(true)}
                className="p-3 md:p-4 bg-green-50 dark:bg-gray-700 rounded-lg text-center hover:bg-green-100 dark:hover:bg-gray-600 cursor-pointer transition-colors"
              >
                <Users className="h-6 w-6 md:h-8 md:w-8 text-purple-600 dark:text-purple-400 mx-auto mb-2" />
                <p className="text-xs md:text-sm text-green-700 dark:text-green-300">Expert Consultation</p>
              </button>
            </div>
          </CardContent>
        </Card>

        {/* Recent Activity */}
        <Card className="border-green-200 dark:border-green-600 bg-white dark:bg-gray-800">
          <CardHeader className="bg-green-50 dark:bg-gray-700">
            <CardTitle className="text-green-800 dark:text-green-300">{t('recentUpdates')}</CardTitle>
            <CardDescription className="dark:text-gray-400">Your latest farming activities</CardDescription>
          </CardHeader>
          <CardContent className="pt-4">
            <div className="space-y-4">
              <div className="flex items-start space-x-3 p-3 bg-green-50 dark:bg-green-900/20 rounded-lg">
                <div className="bg-green-600 dark:bg-green-700 p-1 rounded-full">
                  <Leaf className="h-3 w-3 text-white" />
                </div>
                <div>
                  <p className="text-sm text-green-800 dark:text-green-300">Profile setup completed</p>
                  <p className="text-xs text-green-600 dark:text-green-400">Today, 10:30 AM</p>
                </div>
              </div>
              
              <div className="flex items-start space-x-3 p-3 bg-amber-50 dark:bg-amber-900/20 rounded-lg">
                <div className="bg-amber-600 dark:bg-amber-700 p-1 rounded-full">
                  <Sun className="h-3 w-3 text-white" />
                </div>
                <div>
                  <p className="text-sm text-amber-800 dark:text-amber-300">Weather alert: Sunny weather ahead</p>
                  <p className="text-xs text-amber-600 dark:text-amber-400">Yesterday, 6:00 AM</p>
                </div>
              </div>

              <div className="flex items-start space-x-3 p-3 bg-blue-50 dark:bg-blue-900/20 rounded-lg">
                <div className="bg-blue-600 dark:bg-blue-700 p-1 rounded-full">
                  <TrendingUp className="h-3 w-3 text-white" />
                </div>
                <div>
                  <p className="text-sm text-blue-800 dark:text-blue-300">Market prices updated</p>
                  <p className="text-xs text-blue-600 dark:text-blue-400">2 days ago</p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Tips Section */}
      <Card className="border-green-200">
        <CardHeader className="bg-gradient-to-r from-green-50 to-amber-50">
          <CardTitle className="text-green-800">💡 Today's Farming Tip</CardTitle>
        </CardHeader>
        <CardContent className="pt-4">
          <div className="bg-green-50 p-4 rounded-lg">
            <p className="text-green-800">
              <strong>Tip:</strong> With the current sunny weather, it's an excellent time for drying harvested crops. 
              Make sure to spread them evenly and turn them regularly for uniform drying. 
              Also, check soil moisture levels as crops may need additional watering.
            </p>
          </div>
        </CardContent>
      </Card>

      {/* Help Section */}
      <div className="text-center bg-green-50 p-6 rounded-lg">
        <h3 className="text-lg md:text-xl text-green-800 mb-2">{t('needHelp')}</h3>
        <p className="text-green-600 mb-4">
          Our AI assistant is here to answer your farming questions 24/7
        </p>
        <div className="flex flex-col sm:flex-row justify-center gap-3 md:gap-4">
          <button
            onClick={() => setVoiceModalOpen(true)}
            className="bg-white p-3 md:p-4 rounded-lg shadow-sm border border-green-200 hover:bg-green-50 hover:border-green-300 transition-all duration-200 flex items-center justify-center space-x-2 cursor-pointer group"
          >
            <span className="text-xl md:text-2xl">📱</span>
            <span className="text-xs md:text-sm text-green-700 group-hover:text-green-800">{t('voiceQuery')}</span>
          </button>
          <button
            onClick={() => setPhotoModalOpen(true)}
            className="bg-white p-3 md:p-4 rounded-lg shadow-sm border border-green-200 hover:bg-green-50 hover:border-green-300 transition-all duration-200 flex items-center justify-center space-x-2 cursor-pointer group"
          >
            <span className="text-xl md:text-2xl">📷</span>
            <span className="text-xs md:text-sm text-green-700 group-hover:text-green-800">{t('uploadPhoto')}</span>
          </button>
          <button
            onClick={() => setTextModalOpen(true)}
            className="bg-white p-3 md:p-4 rounded-lg shadow-sm border border-green-200 hover:bg-green-50 hover:border-green-300 transition-all duration-200 flex items-center justify-center space-x-2 cursor-pointer group"
          >
            <span className="text-xl md:text-2xl">💬</span>
            <span className="text-xs md:text-sm text-green-700 group-hover:text-green-800">{t('askQuestion')}</span>
          </button>
        </div>
      </div>

      {/* Modals */}
      <VoiceInputModal 
        isOpen={voiceModalOpen} 
        onClose={() => setVoiceModalOpen(false)} 
      />
      <PhotoUploadModal 
        isOpen={photoModalOpen} 
        onClose={() => setPhotoModalOpen(false)} 
      />
      <TextMessagingModal 
        isOpen={textModalOpen} 
        onClose={() => setTextModalOpen(false)} 
      />
    </div>
  );
}