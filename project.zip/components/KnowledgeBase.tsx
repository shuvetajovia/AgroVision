import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Badge } from './ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { ImageWithFallback } from './figma/ImageWithFallback';
import { 
  Search, 
  Bug, 
  CloudRain, 
  Sprout, 
  DollarSign,
  BookOpen,
  AlertTriangle,
  TrendingUp
} from 'lucide-react';

export function KnowledgeBase() {
  const [searchQuery, setSearchQuery] = useState('');

  const categories = [
    { id: 'pests', name: 'Pest Control', icon: Bug, count: 45 },
    { id: 'weather', name: 'Weather & Climate', icon: CloudRain, count: 32 },
    { id: 'crops', name: 'Crop Management', icon: Sprout, count: 67 },
    { id: 'market', name: 'Market & Pricing', icon: DollarSign, count: 28 },
  ];

  const pestArticles = [
    {
      title: 'Banana Leaf Spot Disease Management',
      titleMl: 'വാഴയിലെ ഇലപ്പുള്ളി രോഗ നിയന്ത്രണം',
      summary: 'Complete guide to identifying and treating leaf spot disease in banana plants',
      summaryMl: 'വാഴയിലെ ഇലപ്പുള്ളി രോഗം തിരിച്ചറിയാനും ചികിത്സിക്കാനുമുള്ള സമ്പൂർണ്ണ മാർഗ്ഗനിർദ്ദേശം',
      severity: 'high',
      readTime: '5 min',
      image: 'https://images.unsplash.com/photo-1637922808382-0e5930886159?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxiYW5hbmElMjBwbGFudCUyMGRpc2Vhc2UlMjBhZ3JpY3VsdHVyZXxlbnwxfHx8fDE3NTc4MzQwMTZ8MA&ixlib=rb-4.1.0&q=80&w=400'
    },
    {
      title: 'Rice Stem Borer Control',
      titleMl: 'നെല്ലിലെ തണ്ടിൽ പുഴു നിയന്ത്രണം',
      summary: 'Effective methods to prevent and control stem borer infestation in rice crops',
      summaryMl: 'നെല്ല് വിളയിൽ തണ്ടിൽ പുഴു ബാധ തടയാനും നിയന്ത്രിക്കാനുമുള്ള ഫലപ്രദമായ രീതികൾ',
      severity: 'medium',
      readTime: '7 min',
      image: 'https://images.unsplash.com/photo-1707721690544-781fe6ede937?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmYXJtZXIlMjBhZ3JpY3VsdHVyZSUyMGluZGlhbiUyMGNyb3BzfGVufDF8fHx8MTc1NzgzNDAxNHww&ixlib=rb-4.1.0&q=80&w=400'
    },
    {
      title: 'Coconut Palm Weevil Prevention',
      titleMl: 'തെങ്ങിലെ വെള്ളപ്പുഴു തടയൽ',
      summary: 'Comprehensive approach to prevent red palm weevil damage in coconut trees',
      summaryMl: 'തെങ്ങുകളിൽ ചുവന്ന പാം വീവിൽ കേടുപാടുകൾ തടയുന്നതിനുള്ള സമഗ്ര സമീപനം',
      severity: 'high',
      readTime: '8 min',
      image: 'https://images.unsplash.com/photo-1707721690544-781fe6ede937?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmYXJtZXIlMjBhZ3JpY3VsdHVyZSUyMGluZGlhbiUyMGNyb3BzfGVufDF8fHx8MTc1NzgzNDAxNHww&ixlib=rb-4.1.0&q=80&w=400'
    }
  ];

  const weatherArticles = [
    {
      title: 'Monsoon Farming Best Practices',
      titleMl: 'മഴക്കാല കൃഷി മികച്ച രീതികൾ',
      summary: 'Essential guidelines for successful farming during monsoon season',
      summaryMl: 'മഴക്കാലത്തെ വിജയകരമായ കൃഷിക്കുള്ള അത്യാവശ്യ മാർഗ്ഗനിർദ്ദേശങ്ങൾ',
      readTime: '6 min'
    },
    {
      title: 'Drought Management Strategies',
      titleMl: 'വരൾച്ച കൈകാര്യം ചെയ്യൽ തന്ത്രങ്ങൾ',
      summary: 'Water conservation and crop selection during dry periods',
      summaryMl: 'വരണ്ട കാലയളവിൽ ജല സംരക്ഷണവും വിള തിരഞ്ഞെടുപ്പും',
      readTime: '9 min'
    }
  ];

  const subsidySchemes = [
    {
      title: 'PM-KISAN Scheme',
      titleMl: 'പ്രധാനമന്ത്രി കിസാൻ പദ്ധതി',
      amount: '₹6,000/year',
      description: 'Direct income support to farmer families',
      descriptionMl: 'കർഷക കുടുംബങ്ങൾക്ക് നേരിട്ടുള്ള വരുമാന പിന്തുണ',
      eligibility: 'All landholding farmers'
    },
    {
      title: 'Soil Health Card Scheme',
      titleMl: 'മണ്ണിന്റെ ആരോഗ്യ കാർഡ് പദ്ധതി',
      amount: 'Free',
      description: 'Soil testing and nutrient management guidance',
      descriptionMl: 'മണ്ണ് പരിശോധനയും പോഷക മാനേജ്മെന്റ് മാർഗ്ഗനിർദ്ദേശവും',
      eligibility: 'All farmers'
    }
  ];

  return (
    <div className="container mx-auto px-4 py-8">
      {/* Header */}
      <div className="mb-8">
        <h1 className="text-3xl font-bold mb-4">Knowledge Base</h1>
        <p className="text-muted-foreground mb-6">
          Comprehensive farming knowledge and expert guidance in Malayalam and English
        </p>
        
        <div className="flex space-x-2">
          <div className="relative flex-1 max-w-md">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search knowledge base..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10"
            />
          </div>
        </div>
      </div>

      {/* Category Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
        {categories.map((category) => {
          const Icon = category.icon;
          return (
            <Card key={category.id} className="hover:shadow-md transition-shadow cursor-pointer">
              <CardContent className="p-6 text-center">
                <Icon className="h-8 w-8 mx-auto mb-2 text-primary" />
                <h3 className="font-medium mb-1">{category.name}</h3>
                <p className="text-sm text-muted-foreground">{category.count} articles</p>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* Content Tabs */}
      <Tabs defaultValue="pests" className="w-full">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="pests">Pest Control</TabsTrigger>
          <TabsTrigger value="weather">Weather</TabsTrigger>
          <TabsTrigger value="subsidies">Subsidies</TabsTrigger>
          <TabsTrigger value="market">Market</TabsTrigger>
        </TabsList>

        <TabsContent value="pests" className="mt-6">
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {pestArticles.map((article, index) => (
              <Card key={index} className="hover:shadow-md transition-shadow">
                <div className="relative">
                  <ImageWithFallback
                    src={article.image}
                    alt={article.title}
                    className="w-full h-48 object-cover rounded-t-lg"
                  />
                  <Badge 
                    className={`absolute top-2 right-2 ${
                      article.severity === 'high' ? 'bg-red-500' : 'bg-orange-500'
                    }`}
                  >
                    {article.severity === 'high' ? 'High Priority' : 'Medium Priority'}
                  </Badge>
                </div>
                <CardContent className="p-4">
                  <h3 className="font-medium mb-1">{article.title}</h3>
                  <p className="text-sm text-muted-foreground mb-2">{article.titleMl}</p>
                  <p className="text-sm mb-3">{article.summary}</p>
                  <p className="text-xs text-muted-foreground mb-3 italic">{article.summaryMl}</p>
                  <div className="flex justify-between items-center">
                    <span className="text-xs text-muted-foreground">{article.readTime} read</span>
                    <Button size="sm" variant="outline">Read More</Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="weather" className="mt-6">
          <div className="grid md:grid-cols-2 gap-6">
            {weatherArticles.map((article, index) => (
              <Card key={index}>
                <CardContent className="p-6">
                  <div className="flex items-start space-x-3">
                    <CloudRain className="h-6 w-6 text-blue-500 mt-1" />
                    <div className="flex-1">
                      <h3 className="font-medium mb-1">{article.title}</h3>
                      <p className="text-sm text-muted-foreground mb-2">{article.titleMl}</p>
                      <p className="text-sm mb-3">{article.summary}</p>
                      <p className="text-xs text-muted-foreground mb-3 italic">{article.summaryMl}</p>
                      <div className="flex justify-between items-center">
                        <span className="text-xs text-muted-foreground">{article.readTime} read</span>
                        <Button size="sm" variant="outline">Read More</Button>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="subsidies" className="mt-6">
          <div className="grid md:grid-cols-2 gap-6">
            {subsidySchemes.map((scheme, index) => (
              <Card key={index}>
                <CardContent className="p-6">
                  <div className="flex items-start justify-between mb-4">
                    <div>
                      <h3 className="font-medium mb-1">{scheme.title}</h3>
                      <p className="text-sm text-muted-foreground">{scheme.titleMl}</p>
                    </div>
                    <Badge variant="secondary">{scheme.amount}</Badge>
                  </div>
                  <p className="text-sm mb-2">{scheme.description}</p>
                  <p className="text-xs text-muted-foreground mb-3 italic">{scheme.descriptionMl}</p>
                  <div className="flex justify-between items-center">
                    <span className="text-xs text-muted-foreground">Eligibility: {scheme.eligibility}</span>
                    <Button size="sm">Apply Now</Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="market" className="mt-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <TrendingUp className="h-5 w-5" />
                <span>Current Market Prices</span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid md:grid-cols-3 gap-4">
                <div className="text-center p-4 border border-border rounded-lg">
                  <h4 className="font-medium">Rice (Quintal)</h4>
                  <p className="text-2xl font-bold text-green-600">₹2,450</p>
                  <p className="text-sm text-muted-foreground">+2.5% from last week</p>
                </div>
                <div className="text-center p-4 border border-border rounded-lg">
                  <h4 className="font-medium">Banana (Dozen)</h4>
                  <p className="text-2xl font-bold text-green-600">₹45</p>
                  <p className="text-sm text-muted-foreground">+1.2% from last week</p>
                </div>
                <div className="text-center p-4 border border-border rounded-lg">
                  <h4 className="font-medium">Coconut (100 pieces)</h4>
                  <p className="text-2xl font-bold text-red-600">₹2,800</p>
                  <p className="text-sm text-muted-foreground">-3.1% from last week</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}