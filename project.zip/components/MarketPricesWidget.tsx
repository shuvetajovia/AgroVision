import React, { useState, useEffect } from 'react';
import { Card } from './ui/card';
import { Input } from './ui/input';
import { Badge } from './ui/badge';
import { useLanguage } from './LanguageContext';
import { Search, TrendingUp, TrendingDown, Minus, RefreshCw, IndianRupee } from 'lucide-react';
import { Button } from './ui/button';

interface CropPrice {
  id: string;
  name: string;
  nameLocal: string;
  pricePerKg: number;
  previousPrice: number;
  unit: string;
  trend: 'up' | 'down' | 'stable';
  change: number;
  lastUpdated: string;
  market: string;
}

const mockCropPrices: CropPrice[] = [
  {
    id: '1',
    name: 'Rice',
    nameLocal: 'അരി/चावल/அரிசி',
    pricePerKg: 45,
    previousPrice: 42,
    unit: 'kg',
    trend: 'up',
    change: 7.1,
    lastUpdated: '2 hours ago',
    market: 'Kochi Mandi'
  },
  {
    id: '2',
    name: 'Coconut',
    nameLocal: 'തേങ്ങാ/नारियल/தேங்காய்',
    pricePerKg: 35,
    previousPrice: 38,
    unit: 'piece',
    trend: 'down',
    change: -7.9,
    lastUpdated: '1 hour ago',
    market: 'Ernakulam Market'
  },
  {
    id: '3',
    name: 'Black Pepper',
    nameLocal: 'കുരുമുളക്/काली मिर्च/கருப்பு மிளகு',
    pricePerKg: 480,
    previousPrice: 475,
    unit: 'kg',
    trend: 'up',
    change: 1.1,
    lastUpdated: '3 hours ago',
    market: 'Spices Board'
  },
  {
    id: '4',
    name: 'Cardamom',
    nameLocal: 'ഏലം/इलायची/ஏலம்',
    pricePerKg: 1250,
    previousPrice: 1250,
    unit: 'kg',
    trend: 'stable',
    change: 0,
    lastUpdated: '30 mins ago',
    market: 'Cardamom Hill'
  },
  {
    id: '5',
    name: 'Banana',
    nameLocal: 'വാഴപ്പഴം/केला/வாழைப்பழம்',
    pricePerKg: 25,
    previousPrice: 28,
    unit: 'dozen',
    trend: 'down',
    change: -10.7,
    lastUpdated: '1 hour ago',
    market: 'Fruit Market'
  },
  {
    id: '6',
    name: 'Tomato',
    nameLocal: 'തക്കാളി/टमाटर/தக்காளி',
    pricePerKg: 32,
    previousPrice: 29,
    unit: 'kg',
    trend: 'up',
    change: 10.3,
    lastUpdated: '45 mins ago',
    market: 'Vegetable Market'
  },
  {
    id: '7',
    name: 'Onion',
    nameLocal: 'ഉള്ളി/प्याज/வெங்காயம்',
    pricePerKg: 22,
    previousPrice: 24,
    unit: 'kg',
    trend: 'down',
    change: -8.3,
    lastUpdated: '2 hours ago',
    market: 'Wholesale Market'
  },
  {
    id: '8',
    name: 'Ginger',
    nameLocal: 'ഇഞ്ചി/अदरक/இஞ்சி',
    pricePerKg: 85,
    previousPrice: 82,
    unit: 'kg',
    trend: 'up',
    change: 3.7,
    lastUpdated: '1 hour ago',
    market: 'Spice Market'
  }
];

export function MarketPricesWidget() {
  const { t } = useLanguage();
  const [searchTerm, setSearchTerm] = useState('');
  const [prices, setPrices] = useState<CropPrice[]>(mockCropPrices);
  const [loading, setLoading] = useState(false);

  const filteredPrices = prices.filter(crop =>
    crop.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    crop.nameLocal.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const refreshPrices = async () => {
    setLoading(true);
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    // Simulate price updates with random changes
    const updatedPrices = mockCropPrices.map(crop => ({
      ...crop,
      pricePerKg: Math.max(1, crop.pricePerKg + (Math.random() - 0.5) * 5),
      lastUpdated: 'Just now'
    }));
    
    setPrices(updatedPrices);
    setLoading(false);
  };

  const getTrendIcon = (trend: string) => {
    switch (trend) {
      case 'up':
        return <TrendingUp className="h-3 w-3 text-green-600" />;
      case 'down':
        return <TrendingDown className="h-3 w-3 text-red-600" />;
      default:
        return <Minus className="h-3 w-3 text-gray-500" />;
    }
  };

  const getTrendColor = (trend: string) => {
    switch (trend) {
      case 'up':
        return 'text-green-600';
      case 'down':
        return 'text-red-600';
      default:
        return 'text-gray-500';
    }
  };

  return (
    <Card className="p-4">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-lg font-semibold text-foreground">{t('marketPrices')}</h3>
        <Button
          size="sm"
          variant="ghost"
          onClick={refreshPrices}
          disabled={loading}
          className="text-muted-foreground hover:text-foreground"
        >
          <RefreshCw className={`h-4 w-4 ${loading ? 'animate-spin' : ''}`} />
        </Button>
      </div>

      {/* Search Bar */}
      <div className="relative mb-4">
        <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
        <Input
          placeholder={t('filterCrops')}
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          className="pl-10"
        />
      </div>

      {/* Prices List */}
      <div className="space-y-3 max-h-80 overflow-y-auto">
        {filteredPrices.length > 0 ? (
          filteredPrices.map((crop) => (
            <div
              key={crop.id}
              className="flex items-center justify-between p-3 border rounded-lg hover:bg-accent/50 transition-colors"
            >
              <div className="flex-1">
                <div className="flex items-center space-x-2">
                  <h4 className="text-sm font-medium text-foreground">{crop.name}</h4>
                  <Badge variant="outline" className="text-xs text-muted-foreground">
                    {crop.unit}
                  </Badge>
                </div>
                <p className="text-xs text-muted-foreground mt-1">{crop.nameLocal}</p>
                <p className="text-xs text-muted-foreground">{crop.market}</p>
              </div>

              <div className="text-right">
                <div className="flex items-center space-x-1">
                  <IndianRupee className="h-3 w-3 text-foreground" />
                  <span className="text-sm font-semibold text-foreground">
                    {crop.pricePerKg.toFixed(0)}
                  </span>
                </div>
                
                <div className="flex items-center justify-end space-x-1 mt-1">
                  {getTrendIcon(crop.trend)}
                  <span className={`text-xs ${getTrendColor(crop.trend)}`}>
                    {crop.change > 0 ? '+' : ''}{crop.change.toFixed(1)}%
                  </span>
                </div>
                
                <p className="text-xs text-muted-foreground mt-1">{crop.lastUpdated}</p>
              </div>
            </div>
          ))
        ) : (
          <div className="text-center py-8 text-muted-foreground">
            <Search className="h-8 w-8 mx-auto mb-2 opacity-50" />
            <p>No crops found matching "{searchTerm}"</p>
          </div>
        )}
      </div>

      {/* Quick Stats */}
      <div className="mt-4 pt-3 border-t">
        <div className="flex justify-between text-xs text-muted-foreground">
          <span>Updated: {prices[0]?.lastUpdated}</span>
          <span>{filteredPrices.length} crops shown</span>
        </div>
      </div>
    </Card>
  );
}