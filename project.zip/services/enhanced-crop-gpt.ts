// Enhanced GPT Service for Crop-Specific Agricultural Assistance
// Integrates with the agricultural dataset for accurate, data-driven responses

import { agriculturalDataset, cropAliases, issueKeywords, type CropData, type QuestionAnswer } from '../data/agricultural-dataset';

export interface CropGPTQuery {
  text: string;
  language: string;
  detectedLanguage?: string;
  audioInput?: boolean;
}

export interface CropGPTResponse {
  id: string;
  query: string;
  response: string;
  language: string;
  englishTranslation?: string;
  confidence: number;
  cropDetected: string | null;
  category: string | null;
  datasetMatches: QuestionAnswer[];
  seasonalContext?: string;
  timestamp: Date;
}

// Enhanced multilingual crop knowledge base
const multilingualCropKnowledge = {
  rice: {
    en: {
      name: "Rice",
      aliases: ["paddy", "rice crop"],
      description: "A staple cereal grain and one of the most important food crops worldwide",
      seasons: ["Kharif (Monsoon)", "Rabi (Winter)"],
      commonIssues: ["Brown spot", "Blast disease", "Stem borer", "Water management"],
      generalAdvice: "Rice requires proper water management with standing water during growth. Apply balanced fertilizers and use disease-resistant varieties."
    },
    hi: {
      name: "धान",
      aliases: ["चावल", "धान की फसल"],
      description: "एक मुख्य अनाज की फसल जो दुनिया भर में महत्वपूर्ण खाद्य फसल है",
      seasons: ["खरीफ (मानसून)", "रबी (सर्दी)"],
      commonIssues: ["भूरे धब्बे", "ब्लास्ट रोग", "तना छेदक", "पानी प्रबंधन"],
      generalAdvice: "धान के लिए वृद्धि के दौरान खड़े पानी के साथ उचित जल प्रबंधन आवश्यक है। संतुलित उर्वरक डालें और रोग प्रतिरोधी किस्मों का उपयोग करें।"
    },
    ml: {
      name: "നെല്ല്",
      aliases: ["അരി", "നെൽകൃഷി"],
      description: "ലോകമെമ്പാടുമുള്ള ഏറ്റവും പ്രധാനപ്പെട്ട ഭക്ഷ്യവിളകളിലൊന്നായ പ്രധാന ധാന്യവിള",
      seasons: ["ഖരീഫ് (മൺസൂൺ)", "റാബി (ശൈത്യകാലം)"],
      commonIssues: ["തവിട്ട് പാട്", "ബ്ലാസ്റ്റ് രോഗം", "തണ്ട് തുരപ്പൻ", "ജല പരിപാലനം"],
      generalAdvice: "നെല്ലിന് വളർച്ചാ കാലത്ത് നിലനിൽക്കുന്ന വെള്ളത്തോടുകൂടിയ ശരിയായ ജല പരിപാലനം ആവശ്യമാണ്. സമതുലിതമായ വളങ്ങൾ പ്രയോഗിക്കുകയും രോഗ പ്രതിരോധ വിഭാഗങ്ങൾ ഉപയോഗിക്കുകയും ചെയ്യുക।"
    },
    ta: {
      name: "நெல்",
      aliases: ["அரிசி", "நெல் சாகுபடி"],
      description: "உலகம் முழுவதும் மிக முக்கியமான உணவு பயிர்களில் ஒன்றான முக்கிய தானிய பயிர்",
      seasons: ["கரீப் (பருவமழை)", "ரபி (குளிர்காலம்)"],
      commonIssues: ["பழுப்பு புள்ளி", "வெடிப்பு நோய்", "தண்டு துளைப்பான்", "நீர் மேலாண்மை"],
      generalAdvice: "நெல்லுக்கு வளர்ச்சியின் போது நிற்கும் தண்ணீருடன் சரியான நீர் மேலாண்மை தேவை. சமதுலனான உரங்களைப் பயன்படுத்தி நோய் எதிர்ப்பு வகைகளைப் பயன்படுத்துங்கள்."
    }
  },
  wheat: {
    en: {
      name: "Wheat",
      aliases: ["wheat crop", "grain"],
      description: "A cereal grain that is a staple food and important crop worldwide",
      seasons: ["Rabi (Winter)"],
      commonIssues: ["Rust disease", "Aphids", "Nutrient deficiency", "Seed rate"],
      generalAdvice: "Wheat is primarily a Rabi crop. Use certified seeds, apply fertilizers in splits, and monitor for rust diseases."
    },
    hi: {
      name: "गेहूं",
      aliases: ["गेहूं की फसल", "अनाज"],
      description: "एक अनाज जो मुख्य भोजन और दुनिया भर में महत्वपूर्ण फसल है",
      seasons: ["रबी (सर्दी)"],
      commonIssues: ["रतुआ रोग", "माहू", "पोषक तत्व की कमी", "बीज दर"],
      generalAdvice: "गेहूं मुख्यतः रबी की फसल है। प्रमाणित बीज का उपयोग करें, उर्वरक को भागों में डालें, और रतुआ रोगों की निगरानी करें।"
    },
    ml: {
      name: "ഗോതമ്പ്",
      aliases: ["ഗോതമ്പ് വിള", "ധാന്യം"],
      description: "പ്രധാന ഭക്ഷണവും ലോകമെമ്പാടും പ്രധാനപ്പെട്ട വിളയുമായ ധാന്യവിള",
      seasons: ["റാബി (ശൈത്യകാലം)"],
      commonIssues: ["തുരുമ്പ് രോഗം", "മുഞ്ഞകൾ", "പോഷക കുറവ്", "വിത്ത് നിരക്ക്"],
      generalAdvice: "ഗോതമ്പ് പ്രധാനമായും റാബി വിളയാണ്. സാക്ഷ്യപ്പെടുത്തിയ വിത്തുകൾ ഉപയോഗിക്കുക, വളങ്ങൾ ഭാഗങ്ങളായി പ്രയോഗിക്കുക, തുരുമ്പ് രോഗങ്ങൾക്കായി നിരീക്ഷിക്കുക."
    },
    ta: {
      name: "கோதுமை",
      aliases: ["கோதுமை பயிர்", "தானியம்"],
      description: "முக்கிய உணவு மற்றும் உலகம் முழுவதும் முக்கியமான பயிரான தானிய பயிர்",
      seasons: ["ரபி (குளிர்காலம்)"],
      commonIssues: ["துரு நோய்", "பேன்கள்", "ஊட்டச்சத்து குறைபாடு", "விதை விகிதம்"],
      generalAdvice: "கோதுமை முக்கியமாக ரபி பயிர். சான்றளிக்கப்பட்ட விதைகளைப் பயன்படுத்துங்கள், உரங்களை பிரிவுகளில் பயன்படுத்துங்கள், துரு நோய்களைக் கண்காணிக்கவும்."
    }
  },
  tomato: {
    en: {
      name: "Tomato",
      aliases: ["tomatoes", "tomato plant"],
      description: "A popular vegetable crop grown for its edible fruits",
      seasons: ["Winter", "Summer (with irrigation)"],
      commonIssues: ["Late blight", "Early blight", "Whitefly", "Fruit cracking"],
      generalAdvice: "Tomatoes need well-drained soil and regular irrigation. Use proper spacing and support systems for healthy growth."
    },
    hi: {
      name: "टमाटर",
      aliases: ["टमाटर की फसल", "टमाटर का पौधा"],
      description: "खाने योग्य फलों के लिए उगाई जाने वाली एक लोकप्रिय सब्जी की फसल",
      seasons: ["सर्दी", "गर्मी (सिंचाई के साथ)"],
      commonIssues: ["अंगमारी", "प्रारंभिक झुलसा", "सफेद मक्खी", "फल फटना"],
      generalAdvice: "टमाटर को अच्छी जल निकासी वाली मिट्टी और नियमित सिंचाई की आवश्यकता होती है। स्वस्थ वृद्धि के लिए उचित दूरी और सहारा प्रणाली का उपयोग करें।"
    },
    ml: {
      name: "തക്കാളി",
      aliases: ["തക്കാളി വിള", "തക്കാളി ചെടി"],
      description: "ഭക്ഷ്യയോഗ്യമായ ഫലങ്ങൾക്കായി വളർത്തുന്ന ജനപ്രിയ പച്ചക്കറി വിള",
      seasons: ["ശൈത്യകാലം", "വേനൽക്കാലം (നീർവിതരണത്തോടുകൂടി)"],
      commonIssues: ["വൈകിയ വരൾച്ച", "നേരത്തെയുള്ള വരൾച്ച", "വെള്ള ഈച്ച", "ഫലം പൊട്ടൽ"],
      generalAdvice: "തക്കാളിക്ക് നല്ല ഡ്രെയിനേജുള്ള മണ്ണും പതിവ് നീർവിതരണവും ആവശ്യമാണ്. ആരോഗ്യകരമായ വളർച്ചയ്ക്കായി ശരിയായ അകലവും പിന്തുണാ സംവിധാനങ്ങളും ഉപയോഗിക്കുക।"
    },
    ta: {
      name: "தக்காளி",
      aliases: ["தக்காளி பயிர்", "தக்காளி செടி"],
      description: "சாப்பிடக்கூடிய பழங்களுக்காக வளர்க்கப்படும் பிரபலமான காய்கறி பயிர்",
      seasons: ["குளிர்காலம்", "கோடைகாலம் (நீர்ப்பாசனத்துடன்)"],
      commonIssues: ["தாமதமான வாட்டல்", "ஆரம்ப வாட்டல்", "வெள்ளை ஈ", "பழம் வெடிப்பு"],
      generalAdvice: "தக்காளிக்கு நல்ல வடிகால் மண் மற்றும் வழக்கமான நீர்ப்பாசனம் தேவை. ஆரோக்கியமான வளர்ச்சிக்கு சரியான இடைவெளி மற்றும் ஆதரவு அமைப்புகளைப் பயன்படுத்துங்கள்."
    }
  }
};

// Language detection helper
const detectLanguageFromText = (text: string): string => {
  const cleanText = text.toLowerCase().trim();
  
  // Malayalam detection (Malayalam script)
  if (/[\u0D00-\u0D7F]/.test(text)) return 'ml';
  
  // Tamil detection (Tamil script)
  if (/[\u0B80-\u0BFF]/.test(text)) return 'ta';
  
  // Hindi detection (Devanagari script)
  if (/[\u0900-\u097F]/.test(text)) return 'hi';
  
  // Common Hindi words in Latin script
  const hindiWords = ['kya', 'hai', 'mein', 'aur', 'se', 'ko', 'ki', 'ke', 'fasal', 'kheti', 'kaise', 'kab', 'kaun', 'dhan', 'gehun'];
  if (hindiWords.some(word => cleanText.includes(word))) return 'hi';
  
  // Common Malayalam words in Latin script
  const malayalamWords = ['enth', 'aan', 'oru', 'und', 'illa', 'krishi', 'pani', 'engane', 'eppo', 'nellu', 'arisi'];
  if (malayalamWords.some(word => cleanText.includes(word))) return 'ml';
  
  // Common Tamil words in Latin script
  const tamilWords = ['enna', 'oru', 'irukku', 'illa', 'velai', 'krishi', 'eppadi', 'eppo', 'nel', 'arisi'];
  if (tamilWords.some(word => cleanText.includes(word))) return 'ta';
  
  return 'en'; // Default to English
};

// Enhanced crop detection with multilingual support
const detectCrop = (query: string): string | null => {
  const lowercaseQuery = query.toLowerCase();
  
  // Check direct crop mentions
  for (const [crop, aliases] of Object.entries(cropAliases)) {
    if (lowercaseQuery.includes(crop)) return crop;
    if (aliases.some(alias => lowercaseQuery.includes(alias))) return crop;
  }
  
  // Check multilingual crop names
  const cropNames = {
    rice: ['rice', 'paddy', 'dhan', 'dhaan', 'chawal', 'nellu', 'nel', 'arisi', 'നെല്ല്', 'நெல்', 'धान', 'चावल'],
    wheat: ['wheat', 'gehun', 'गेहूं', 'ഗോതമ്പ്', 'கோதுமை', 'godhi', 'gahuun'],
    maize: ['maize', 'corn', 'makka', 'মাকাই', 'cholam', 'ചോളം', 'மக்காச்சோளம்', 'मक्का'],
    tomato: ['tomato', 'tamatar', 'टमाटर', 'thakkali', 'തക്കാളി', 'தக்காளி'],
    cotton: ['cotton', 'kapas', 'कपास', 'പരുത്തി', 'பருத்தி', 'patti'],
    potato: ['potato', 'aloo', 'आलू', 'batata', 'urulaikizhangu', 'உருளைக்கிழங்கு']
  };
  
  for (const [crop, names] of Object.entries(cropNames)) {
    if (names.some(name => lowercaseQuery.includes(name.toLowerCase()))) {
      return crop;
    }
  }
  
  return null;
};

// Search dataset for relevant information
const searchDataset = (query: string, crop: string | null): QuestionAnswer[] => {
  const queryWords = query.toLowerCase().split(' ').filter(word => word.length > 2);
  const matches: { qa: QuestionAnswer, score: number }[] = [];
  
  agriculturalDataset.forEach(cropData => {
    // If specific crop detected, prioritize that crop's data
    if (crop && cropData.crop !== crop) return;
    
    cropData.questions.forEach(qa => {
      let score = 0;
      
      // Check question relevance
      const questionWords = qa.question.toLowerCase().split(' ');
      queryWords.forEach(word => {
        if (questionWords.some(qw => qw.includes(word))) score += 15;
        if (qa.keywords.some(kw => kw.toLowerCase().includes(word))) score += 20;
        if (qa.answer.toLowerCase().includes(word)) score += 10;
      });
      
      // Boost score for exact crop match
      if (crop && cropData.crop === crop) score += 25;
      
      if (score > 10) {
        matches.push({ qa, score });
      }
    });
  });
  
  return matches
    .sort((a, b) => b.score - a.score)
    .slice(0, 3)
    .map(m => m.qa);
};

// Generate contextual response
const generateContextualResponse = (
  query: string, 
  crop: string | null, 
  matches: QuestionAnswer[], 
  language: string
): { response: string, englishResponse?: string, category: string | null } => {
  
  if (matches.length === 0 && !crop) {
    const responses = {
      en: "I'd be happy to help with your farming question! To provide specific recommendations, please mention which crop you're asking about (rice, wheat, tomato, etc.) and your specific concern (disease, fertilizer, irrigation, etc.).",
      hi: "मैं आपके खेती के प्रश्न में खुशी से मदद करूंगा! विशिष्ट सुझाव देने के लिए, कृपया बताएं कि आप किस फसल के बारे में पूछ रहे हैं (धान, गेहूं, टमाटर, आदि) और आपकी विशिष्ट समस्या (रोग, उर्वरक, सिंचाई, आदि)।",
      ml: "നിങ്ങളുടെ കൃഷിയെക്കുറിച്ചുള്ള ചോദ്യത്തിൽ സഹായിക്കാൻ ഞാൻ സന്തുഷ്ടനാണ്! നിർദ്ദിഷ്ട ശുപാർശകൾ നൽകാൻ, നിങ്ങൾ ഏത് വിളയെക്കുറിച്ചാണ് ചോദിക്കുന്നത് (നെല്ല്, ഗോതമ്പ്, തക്കാളി മുതലായവ) എന്നും നിങ്ങളുടെ പ്രത്യേക ആശങ്ക (രോഗം, വള, നീർവിതരണം മുതലായവ) എന്നും പറയുക।",
      ta: "உங்கள் விவசாய கேள்வியில் உதவ நான் மகிழ்ச்சியடைகிறேன்! குறிப்பிட்ட பரிந்துரைகளை வழங்க, நீங்கள் எந்த பயிரைப் பற்றி கேட்கிறீர்கள் (நெல், கோதுமை, தக்காளி போன்றவை) மற்றும் உங்கள் குறிப்பிட்ட கவலை (நோய், உரம், நீர்ப்பாசனம் போன்றவை) என்று சொல்லுங்கள்."
    };
    
    const response = responses[language as keyof typeof responses] || responses.en;
    const englishResponse = language !== 'en' ? responses.en : undefined;
    
    return { response, englishResponse, category: null };
  }
  
  if (crop && matches.length === 0) {
    // Crop detected but no specific matches - provide general crop info
    const cropInfo = multilingualCropKnowledge[crop as keyof typeof multilingualCropKnowledge];
    if (cropInfo) {
      const info = cropInfo[language as keyof typeof cropInfo] || cropInfo.en;
      const response = `${info.description}। सामान्य सलाह: ${info.generalAdvice}`;
      const englishResponse = language !== 'en' ? `${cropInfo.en.description}. General advice: ${cropInfo.en.generalAdvice}` : undefined;
      
      return { response, englishResponse, category: 'general' };
    }
  }
  
  // Found specific matches
  if (matches.length > 0) {
    const primaryMatch = matches[0];
    let response = primaryMatch.answer;
    
    // Add additional context from other matches
    if (matches.length > 1) {
      const additionalInfo = matches.slice(1).map(m => m.answer).join(' ');
      response += ` \n\nAdditional information: ${additionalInfo}`;
    }
    
    // Add crop-specific context
    if (crop) {
      const cropInfo = multilingualCropKnowledge[crop as keyof typeof multilingualCropKnowledge];
      if (cropInfo) {
        const info = cropInfo[language as keyof typeof cropInfo] || cropInfo.en;
        response += `\n\nGeneral ${info.name} advice: ${info.generalAdvice}`;
      }
    }
    
    return { 
      response, 
      englishResponse: language !== 'en' ? primaryMatch.answer : undefined,
      category: primaryMatch.category 
    };
  }
  
  return { 
    response: "I couldn't find specific information for your query. Please try rephrasing or contact a local agricultural expert.", 
    englishResponse: undefined,
    category: null 
  };
};

// Main GPT processing function
export class EnhancedCropGPTService {
  static async processQuery(query: CropGPTQuery): Promise<CropGPTResponse> {
    // Simulate processing delay
    await new Promise(resolve => setTimeout(resolve, 1500));
    
    const detectedLang = query.detectedLanguage || detectLanguageFromText(query.text);
    const responseLang = query.language;
    const cropDetected = detectCrop(query.text);
    
    // Search dataset for relevant information
    const datasetMatches = searchDataset(query.text, cropDetected);
    
    // Generate contextual response
    const { response, englishResponse, category } = generateContextualResponse(
      query.text, 
      cropDetected, 
      datasetMatches, 
      responseLang
    );
    
    // Calculate confidence based on matches and crop detection
    let confidence = 0.4; // Base confidence
    if (cropDetected) confidence += 0.3;
    if (datasetMatches.length > 0) confidence += 0.3;
    if (datasetMatches.length > 1) confidence += 0.1;
    confidence = Math.min(confidence, 1.0);
    
    return {
      id: Date.now().toString(),
      query: query.text,
      response,
      language: responseLang,
      englishTranslation: englishResponse,
      confidence,
      cropDetected,
      category,
      datasetMatches,
      timestamp: new Date()
    };
  }
  
  static detectLanguage(text: string): string {
    return detectLanguageFromText(text);
  }
  
  static detectCropFromQuery(text: string): string | null {
    return detectCrop(text);
  }
  
  static getAvailableCrops(): string[] {
    return Object.keys(multilingualCropKnowledge);
  }
  
  static getCropInfo(crop: string, language: string = 'en') {
    const cropInfo = multilingualCropKnowledge[crop as keyof typeof multilingualCropKnowledge];
    if (!cropInfo) return null;
    
    return cropInfo[language as keyof typeof cropInfo] || cropInfo.en;
  }
}