// GPT-powered Crop Calendar and Irrigation Planning Service
// Provides intelligent crop planning based on climate, season, and location

export interface CropCalendarQuery {
  crop?: string;
  location?: string;
  season?: string;
  soilType?: string;
  language: string;
}

export interface IrrigationPlan {
  stage: string;
  daysAfterSowing: number;
  waterRequirement: string;
  frequency: string;
  notes: string;
}

export interface CropCalendarResponse {
  id: string;
  crop: string;
  location: string;
  season: string;
  plantingWindow: {
    start: string;
    end: string;
    optimal: string;
  };
  harvestWindow: {
    start: string;
    end: string;
    optimal: string;
  };
  irrigationPlan: IrrigationPlan[];
  seasonalTips: string[];
  climateConsiderations: string[];
  totalWaterRequirement: string;
  growthDuration: string;
  expectedYield: string;
  language: string;
  englishTranslation?: {
    seasonalTips: string[];
    climateConsiderations: string[];
  };
  timestamp: Date;
}

// Comprehensive crop calendar database with multilingual support
const cropCalendarDatabase = {
  rice: {
    kharif: {
      en: {
        plantingWindow: { start: "June 15", end: "July 31", optimal: "July 1-15" },
        harvestWindow: { start: "November 15", end: "December 31", optimal: "December 1-15" },
        irrigationPlan: [
          { stage: "Land Preparation", daysAfterSowing: -15, waterRequirement: "15-20 cm", frequency: "Once", notes: "Flood the field for puddling" },
          { stage: "Transplanting", daysAfterSowing: 0, waterRequirement: "5-10 cm", frequency: "Continuous", notes: "Maintain standing water" },
          { stage: "Tillering", daysAfterSowing: 21, waterRequirement: "5 cm", frequency: "Continuous", notes: "Critical growth stage" },
          { stage: "Panicle Initiation", daysAfterSowing: 45, waterRequirement: "5 cm", frequency: "Continuous", notes: "Most critical stage" },
          { stage: "Flowering", daysAfterSowing: 65, waterRequirement: "3-5 cm", frequency: "Continuous", notes: "Ensure no water stress" },
          { stage: "Grain Filling", daysAfterSowing: 85, waterRequirement: "2-3 cm", frequency: "Intermittent", notes: "Reduce water gradually" },
          { stage: "Maturity", daysAfterSowing: 110, waterRequirement: "0 cm", frequency: "None", notes: "Drain field 10-15 days before harvest" }
        ],
        seasonalTips: [
          "Monitor monsoon patterns and plant accordingly",
          "Ensure proper drainage to prevent waterlogging",
          "Use disease-resistant varieties for high humidity",
          "Apply organic matter before monsoon season",
          "Plan for pest management during warm, humid conditions"
        ],
        climateConsiderations: [
          "Kharif rice benefits from monsoon rains",
          "High humidity increases disease risk",
          "Temperature should be 25-35°C during growing season",
          "Minimum 1000mm rainfall required",
          "Avoid planting if monsoon is delayed beyond August"
        ],
        totalWaterRequirement: "1200-1500 mm",
        growthDuration: "110-130 days",
        expectedYield: "4-6 tons/hectare"
      },
      hi: {
        plantingWindow: { start: "15 जून", end: "31 जुलाई", optimal: "1-15 जुलाई" },
        harvestWindow: { start: "15 नवंबर", end: "31 दिसंबर", optimal: "1-15 दिसंबर" },
        irrigationPlan: [
          { stage: "भूमि तैयारी", daysAfterSowing: -15, waterRequirement: "15-20 सेमी", frequency: "एक बार", notes: "गारा बनाने के लिए खेत में पानी भरें" },
          { stage: "रोपाई", daysAfterSowing: 0, waterRequirement: "5-10 सेमी", frequency: "निरंतर", notes: "खड़ा पानी बनाए रखें" },
          { stage: "कल्ले निकलना", daysAfterSowing: 21, waterRequirement: "5 सेमी", frequency: "निरंतर", notes: "महत्वपूर्ण वृद्धि अवस्था" },
          { stage: "बाली आना", daysAfterSowing: 45, waterRequirement: "5 सेमी", frequency: "निरंतर", notes: "अत्यंत महत्वपूर्ण अवस्था" },
          { stage: "फूल आना", daysAfterSowing: 65, waterRequirement: "3-5 सेमी", frequency: "निरंतर", notes: "पानी की कमी न होने दें" },
          { stage: "दाना भरना", daysAfterSowing: 85, waterRequirement: "2-3 सेमी", frequency: "रुक-रुक कर", notes: "धीरे-धीरे पानी कम करें" },
          { stage: "पकना", daysAfterSowing: 110, waterRequirement: "0 सेमी", frequency: "कोई नहीं", notes: "कटाई से 10-15 दिन पहले खेत सुखाएं" }
        ],
        seasonalTips: [
          "मानसून के पैटर्न पर नजर रखें और उसके अनुसार बुवाई करें",
          "जलभराव से बचने के लिए उचित जल निकासी सुनिश्चित करें",
          "उच्च आर्द्रता के लिए रोग प्रतिरोधी किस्मों का उपयोग करें",
          "मानसून सीजन से पहले जैविक पदार्थ डालें",
          "गर्म, आर्द्र स्थितियों में कीट प्रबंधन की योजना बनाएं"
        ],
        climateConsiderations: [
          "खरीफ धान को मानसूनी बारिश से लाभ होता है",
          "उच्च आर्द्रता से रोग का खतरा बढ़ता है",
          "बढ़ते मौसम में तापमान 25-35°C होना चाहिए",
          "न्यूनतम 1000 मिमी वर्षा आवश्यक",
          "यदि मानसून अगस्त के बाद देर से आए तो बुवाई न करें"
        ],
        totalWaterRequirement: "1200-1500 मिमी",
        growthDuration: "110-130 दिन",
        expectedYield: "4-6 टन/हेक्टेयर"
      },
      ml: {
        plantingWindow: { start: "ജൂൺ 15", end: "ജൂലൈ 31", optimal: "ജൂലൈ 1-15" },
        harvestWindow: { start: "നവംബർ 15", end: "ഡിസംബർ 31", optimal: "ഡിസംബർ 1-15" },
        irrigationPlan: [
          { stage: "ഭൂമി തയ്യാറാക്കൽ", daysAfterSowing: -15, waterRequirement: "15-20 സെമി", frequency: "ഒരു തവണ", notes: "കളിമണ്ണ് തയ്യാറാക്കാൻ വയൽ വെള്ളത്തിൽ മുക്കുക" },
          { stage: "നടീൽ", daysAfterSowing: 0, waterRequirement: "5-10 സെമി", frequency: "തുടർച്ചയായി", notes: "നിലനിൽക്കുന്ന വെള്ളം നിലനിർത്തുക" },
          { stage: "കുല പൊട്ടൽ", daysAfterSowing: 21, waterRequirement: "5 സെമി", frequency: "തുടർച്ചയായി", notes: "നിർണായക വളർച്ചാ ഘട്ടം" },
          { stage: "കതിർ വരൽ", daysAfterSowing: 45, waterRequirement: "5 സെമി", frequency: "തുടർച്ചയായി", notes: "ഏറ്റവും നിർണായക ഘട്ടം" },
          { stage: "പൂക്കൽ", daysAfterSowing: 65, waterRequirement: "3-5 സെമി", frequency: "തുടർച്ചയായി", notes: "വെള്ളക്ഷാമം ഉണ്ടാകരുത്" },
          { stage: "ധാന്യം നിറയൽ", daysAfterSowing: 85, waterRequirement: "2-3 സെമി", frequency: "ഇടവിട്ട്", notes: "വെള്ളം ക്രമേണ കുറയ്ക്കുക" },
          { stage: "പാകം", daysAfterSowing: 110, waterRequirement: "0 സെമി", frequency: "ഇല്ല", notes: "വിളവെടുപ്പിന് 10-15 ദിവസം മുമ്പ് വയൽ വറ്റിക്കുക" }
        ],
        seasonalTips: [
          "മൺസൂൺ പാറ്റേൺ നിരീക്ഷിച്ച് അതനുസരിച്ച് നടുക",
          "വെള്ളക്കെട്ട് തടയാൻ ശരിയായ ഡ്രെയിനേജ് ഉറപ്പാക്കുക",
          "ഉയർന്ന ഈർപ്പത്തിന് രോഗ പ്രതിരോധ ഇനങ്ങൾ ഉപയോഗിക്കുക",
          "മൺസൂൺ സീസണിന് മുമ്പ് ജൈവ വസ്തുക്കൾ പ്രയോഗിക്കുക",
          "ചൂടുള്ളതും ഈർപ്പമുള്ളതുമായ അവസ്ഥകളിൽ കീട പരിപാലനം ആസൂത്രണം ചെയ്യുക"
        ],
        climateConsiderations: [
          "ഖരീഫ് നെല്ലിന് മൺസൂൺ മഴയിൽ നിന്ന് പ്രയോജനം ലഭിക്കുന്നു",
          "ഉയർന്ന ഈർപ്പം രോഗ സാധ്യത വർധിപ്പിക്കുന്നു",
          "വളർച്ചാ കാലത്ത് താപനില 25-35°C ആയിരിക്കണം",
          "കുറഞ്ഞത് 1000 മില്ലീമീറ്റർ മഴ ആവശ്യം",
          "മൺസൂൺ ആഗസ്റ്റിനു ശേഷം വൈകിയാൽ നടീൽ ഒഴിവാക്കുക"
        ],
        totalWaterRequirement: "1200-1500 മില്ലീമീറ്റർ",
        growthDuration: "110-130 ദിവസം",
        expectedYield: "4-6 ടൺ/ഹെക്ടർ"
      },
      ta: {
        plantingWindow: { start: "ஜூன் 15", end: "ஜூலை 31", optimal: "ஜூலை 1-15" },
        harvestWindow: { start: "நவம்பர் 15", end: "டிசம்பர் 31", optimal: "டிசம்பர் 1-15" },
        irrigationPlan: [
          { stage: "நில தயாரிப்பு", daysAfterSowing: -15, waterRequirement: "15-20 செமீ", frequency: "ஒரு முறை", notes: "சேற்று வேலைக்கு வயலை வெள்ளத்தில் மூழ்கடிக்கவும்" },
          { stage: "நடவு", daysAfterSowing: 0, waterRequirement: "5-10 செமீ", frequency: "தொடர்ச்சியாக", notes: "நிற்கும் நீரை பராமரிக்கவும்" },
          { stage: "தழைத்தல்", daysAfterSowing: 21, waterRequirement: "5 செமீ", frequency: "தொடர்ச்சியாக", notes: "முக்கியமான வளர்ச்சி நிலை" },
          { stage: "கதிர் வருதல்", daysAfterSowing: 45, waterRequirement: "5 செமீ", frequency: "தொடர்ச்சியாக", notes: "மிக முக்கியமான நிலை" },
          { stage: "பூக்கும்", daysAfterSowing: 65, waterRequirement: "3-5 செமீ", frequency: "தொடர்ச்சியாக", notes: "நீர் பற்றாக்குறை இல்லாமல் பார்த்துக் கொள்ளவும்" },
          { stage: "தானிய நிரப்புதல்", daysAfterSowing: 85, waterRequirement: "2-3 செமீ", frequency: "இடைவிட்டு", notes: "படிப்படியாக நீரை குறைக்கவும்" },
          { stage: "முதிர்ச்சி", daysAfterSowing: 110, waterRequirement: "0 செமீ", frequency: "எதுவுமில்லை", notes: "அறுவடைக்கு 10-15 நாட்கள் முன்பு வயலை வறட்டவும்" }
        ],
        seasonalTips: [
          "பருவமழை முறைகளை கண்காணித்து அதற்கேற்ப நடவு செய்யவும்",
          "நீர்த்தேக்கத்தை தடுக்க சரியான வடிகால் உறுதி செய்யவும்",
          "அதிக ஈரப்பதத்திற்கு நோய் எதிர்ப்பு வகைகளை பயன்படுத்தவும்",
          "பருவமழை காலத்திற்கு முன் கரிம பொருட்களை பயன்படுத்தவும்",
          "வெப்பமான, ஈரப்பதமான நிலைமைகளில் பூச்சி மேலாண்மை திட்டமிடவும்"
        ],
        climateConsiderations: [
          "கரீப் நெல் பருவமழையால் பயன்பெறுகிறது",
          "அதிக ஈரப்பதம் நோய் அபாயத்தை அதிகரிக்கிறது",
          "வளரும் காலத்தில் வெப்பநிலை 25-35°C இருக்க வேண்டும்",
          "குறைந்தபட்சம் 1000மிமீ மழை தேவை",
          "பருவமழை ஆகஸ்ட் மாதத்திற்கு பிறகு தாமதமானால் நடவு தவிர்க்கவும்"
        ],
        totalWaterRequirement: "1200-1500 மிமீ",
        growthDuration: "110-130 நாட்கள்",
        expectedYield: "4-6 டன்/ஹெக்டேர்"
      }
    },
    rabi: {
      en: {
        plantingWindow: { start: "November 15", end: "January 15", optimal: "December 1-31" },
        harvestWindow: { start: "April 1", end: "May 31", optimal: "April 15-May 15" },
        irrigationPlan: [
          { stage: "Land Preparation", daysAfterSowing: -10, waterRequirement: "8-10 cm", frequency: "Once", notes: "Light irrigation for seedbed preparation" },
          { stage: "Sowing/Transplanting", daysAfterSowing: 0, waterRequirement: "3-5 cm", frequency: "As needed", notes: "Ensure adequate moisture" },
          { stage: "Establishment", daysAfterSowing: 15, waterRequirement: "3-4 cm", frequency: "Weekly", notes: "Critical for root establishment" },
          { stage: "Tillering", daysAfterSowing: 30, waterRequirement: "4-5 cm", frequency: "7-10 days", notes: "Increase irrigation frequency" },
          { stage: "Panicle Initiation", daysAfterSowing: 60, waterRequirement: "5-6 cm", frequency: "5-7 days", notes: "Most critical stage" },
          { stage: "Flowering", daysAfterSowing: 90, waterRequirement: "4-5 cm", frequency: "7-10 days", notes: "Maintain consistent moisture" },
          { stage: "Grain Filling", daysAfterSowing: 105, waterRequirement: "3-4 cm", frequency: "10-15 days", notes: "Reduce frequency gradually" },
          { stage: "Maturity", daysAfterSowing: 130, waterRequirement: "0 cm", frequency: "None", notes: "Stop irrigation 10 days before harvest" }
        ],
        seasonalTips: [
          "Take advantage of cool winter temperatures",
          "Protect from cold waves and frost",
          "Use residual soil moisture from previous crop",
          "Plan irrigation schedule based on winter rainfall",
          "Monitor for winter-specific pests and diseases"
        ],
        climateConsiderations: [
          "Rabi rice benefits from cool, dry weather",
          "Temperature should be 20-25°C during growing season",
          "Lower humidity reduces disease pressure",
          "Requires more irrigation due to low rainfall",
          "Risk of cold damage during germination and early growth"
        ],
        totalWaterRequirement: "800-1000 mm",
        growthDuration: "130-150 days",
        expectedYield: "3-5 tons/hectare"
      }
    }
  },
  wheat: {
    rabi: {
      en: {
        plantingWindow: { start: "November 1", end: "December 31", optimal: "November 15-December 15" },
        harvestWindow: { start: "March 15", end: "May 15", optimal: "April 1-30" },
        irrigationPlan: [
          { stage: "Pre-sowing", daysAfterSowing: -5, waterRequirement: "6-8 cm", frequency: "Once", notes: "Apply if soil moisture is insufficient" },
          { stage: "Crown Root Stage", daysAfterSowing: 21, waterRequirement: "5-6 cm", frequency: "Once", notes: "First critical irrigation" },
          { stage: "Tillering", daysAfterSowing: 45, waterRequirement: "5-6 cm", frequency: "Once", notes: "Important for tiller development" },
          { stage: "Jointing", daysAfterSowing: 60, waterRequirement: "6-7 cm", frequency: "Once", notes: "Critical for stem elongation" },
          { stage: "Flowering", daysAfterSowing: 90, waterRequirement: "6-7 cm", frequency: "Once", notes: "Most critical for yield" },
          { stage: "Milk Stage", daysAfterSowing: 105, waterRequirement: "5-6 cm", frequency: "Once", notes: "Important for grain filling" },
          { stage: "Dough Stage", daysAfterSowing: 120, waterRequirement: "4-5 cm", frequency: "Once (if needed)", notes: "Last irrigation if required" }
        ],
        seasonalTips: [
          "Sow immediately after rice harvest",
          "Take advantage of residual soil moisture",
          "Monitor weather for frost protection",
          "Use early maturing varieties in late sown conditions",
          "Ensure good drainage to prevent waterlogging"
        ],
        climateConsiderations: [
          "Wheat thrives in cool, dry climate",
          "Optimal temperature 15-25°C during growing season",
          "Requires 450-600mm water throughout growth",
          "Sensitive to high temperatures during grain filling",
          "Frost can damage crop during flowering"
        ],
        totalWaterRequirement: "450-600 mm",
        growthDuration: "120-150 days",
        expectedYield: "4-6 tons/hectare"
      }
    }
  },
  tomato: {
    winter: {
      en: {
        plantingWindow: { start: "October 15", end: "November 30", optimal: "November 1-15" },
        harvestWindow: { start: "January 15", end: "April 30", optimal: "February 1-March 31" },
        irrigationPlan: [
          { stage: "Nursery", daysAfterSowing: 0, waterRequirement: "Light spraying", frequency: "2-3 times daily", notes: "Keep nursery beds moist" },
          { stage: "Transplanting", daysAfterSowing: 25, waterRequirement: "2-3 cm", frequency: "Immediately after", notes: "Heavy watering after transplanting" },
          { stage: "Establishment", daysAfterSowing: 35, waterRequirement: "1-2 cm", frequency: "Every 3-4 days", notes: "Light but frequent irrigation" },
          { stage: "Vegetative Growth", daysAfterSowing: 50, waterRequirement: "2-3 cm", frequency: "Every 5-7 days", notes: "Increase water as plant grows" },
          { stage: "Flowering", daysAfterSowing: 70, waterRequirement: "3-4 cm", frequency: "Every 4-5 days", notes: "Critical for flower formation" },
          { stage: "Fruit Development", daysAfterSowing: 90, waterRequirement: "4-5 cm", frequency: "Every 3-4 days", notes: "Maximum water requirement" },
          { stage: "Fruit Ripening", daysAfterSowing: 110, waterRequirement: "2-3 cm", frequency: "Every 5-7 days", notes: "Reduce water to improve fruit quality" }
        ],
        seasonalTips: [
          "Take advantage of cool winter weather",
          "Protect from frost using mulch or covers",
          "Use drip irrigation for water efficiency",
          "Monitor soil moisture regularly",
          "Harvest fruits at right maturity stage"
        ],
        climateConsiderations: [
          "Winter tomatoes have better fruit quality",
          "Lower disease pressure due to dry weather",
          "Temperature should be 18-25°C for optimal growth",
          "Protect from cold winds and frost",
          "Extended harvest period due to cool weather"
        ],
        totalWaterRequirement: "400-600 mm",
        growthDuration: "120-140 days",
        expectedYield: "40-60 tons/hectare"
      }
    }
  }
};

// Location-specific climate data
const locationClimateData = {
  kerala: {
    en: {
      climate: "Tropical humid climate with heavy monsoons",
      rainySeasons: ["June-September (Southwest Monsoon)", "October-December (Northeast Monsoon)"],
      temperature: "24-33°C year round",
      humidity: "70-85% during monsoons"
    },
    ml: {
      climate: "കനത്ത മൺസൂണുള്ള ഉഷ്ണമേഖലാ ഈർപ്പമുള്ള കാലാവസ്ഥ",
      rainySeasons: ["ജൂൺ-സെപ്റ്റംബർ (തെക്കുപടിഞ്ഞാറൻ മൺസൂൺ)", "ഒക്ടോബർ-ഡിസംബർ (വടക്കുകിഴക്കൻ മൺസൂൺ)"],
      temperature: "വർഷം മുഴുവൻ 24-33°C",
      humidity: "മൺസൂൺ കാലത്ത് 70-85%"
    }
  },
  punjab: {
    en: {
      climate: "Semi-arid continental climate",
      rainySeasons: ["July-September (Monsoon)"],
      temperature: "Sub-zero to 45°C (seasonal variation)",
      humidity: "30-70% (seasonal)"
    },
    hi: {
      climate: "अर्ध-शुष्क महाद्वीपीय जलवायु",
      rainySeasons: ["जुलाई-सितंबर (मानसून)"],
      temperature: "शून्य से कम से 45°C तक (मौसमी बदलाव)",
      humidity: "30-70% (मौसमी)"
    }
  },
  maharashtra: {
    en: {
      climate: "Tropical and sub-tropical climate",
      rainySeasons: ["June-September (Southwest Monsoon)"],
      temperature: "18-35°C (seasonal variation)",
      humidity: "45-85% (seasonal)"
    },
    hi: {
      climate: "उष्णकटिबंधीय और उपोष्णकटिबंधीय जलवायु",
      rainySeasons: ["जून-सितंबर (दक्षिण-पश्चिम मानसून)"],
      temperature: "18-35°C (मौसमी बदलाव)",
      humidity: "45-85% (मौसमी)"
    }
  },
  tamilnadu: {
    en: {
      climate: "Tropical climate with distinct monsoon periods",
      rainySeasons: ["June-September (Southwest Monsoon)", "October-December (Northeast Monsoon)"],
      temperature: "24-35°C year round",
      humidity: "60-80% during monsoons"
    },
    ta: {
      climate: "தனித்த பருவமழை காலங்களுடன் வெப்பமண்டல காலநிலை",
      rainySeasons: ["ஜூன்-செப்டம்பர் (தென்மேற்கு பருவமழை)", "அக்டோபர்-டிசம்பர் (வடகிழக்கு பருவமழை)"],
      temperature: "ஆண்டு முழுவதும் 24-35°C",
      humidity: "பருவமழையின் போது 60-80%"
    }
  },
  karnataka: {
    en: {
      climate: "Diverse climate from coastal to mountainous regions",
      rainySeasons: ["June-September (Southwest Monsoon)", "October-November (Northeast Monsoon)"],
      temperature: "15-35°C (varies by region)",
      humidity: "50-85% (seasonal and regional)"
    },
    hi: {
      climate: "तटीय से पहाड़ी क्षेत्रों तक विविध जलवायु",
      rainySeasons: ["जून-सितंबर (दक्षिण-पश्चिम मानसून)", "अक्टूबर-नवंबर (उत्तर-पूर्व मानसून)"],
      temperature: "15-35°C (क्षेत्र के अनुसार)",
      humidity: "50-85% (मौसमी और क्षेत्रीय)"
    }
  }
};

export class CropCalendarGPTService {
  static async generateCropCalendar(query: CropCalendarQuery): Promise<CropCalendarResponse> {
    // Simulate API processing delay
    await new Promise(resolve => setTimeout(resolve, 2000));

    const { crop = 'rice', location = 'kerala', season = 'kharif', language } = query;
    
    // Get crop data
    const cropData = cropCalendarDatabase[crop as keyof typeof cropCalendarDatabase];
    if (!cropData) {
      throw new Error(`Crop ${crop} not found in database`);
    }

    const seasonData = cropData[season as keyof typeof cropData];
    if (!seasonData) {
      throw new Error(`Season ${season} not available for crop ${crop}`);
    }

    const languageData = seasonData[language as keyof typeof seasonData] || seasonData.en;
    
    // Get location climate data
    const locationData = locationClimateData[location as keyof typeof locationClimateData];
    const locationClimate = locationData?.[language as keyof typeof locationData] || locationData?.en;

    // Generate response
    const response: CropCalendarResponse = {
      id: Date.now().toString(),
      crop,
      location,
      season,
      plantingWindow: languageData.plantingWindow,
      harvestWindow: languageData.harvestWindow,
      irrigationPlan: languageData.irrigationPlan,
      seasonalTips: languageData.seasonalTips,
      climateConsiderations: languageData.climateConsiderations,
      totalWaterRequirement: languageData.totalWaterRequirement,
      growthDuration: languageData.growthDuration,
      expectedYield: languageData.expectedYield,
      language,
      timestamp: new Date()
    };

    // Add English translation if not English
    if (language !== 'en' && seasonData.en) {
      response.englishTranslation = {
        seasonalTips: seasonData.en.seasonalTips,
        climateConsiderations: seasonData.en.climateConsiderations
      };
    }

    return response;
  }

  static getAvailableCrops(): string[] {
    return Object.keys(cropCalendarDatabase);
  }

  static getAvailableSeasons(crop: string): string[] {
    const cropData = cropCalendarDatabase[crop as keyof typeof cropCalendarDatabase];
    return cropData ? Object.keys(cropData) : [];
  }

  static getAvailableLocations(): string[] {
    return Object.keys(locationClimateData);
  }
}