// GPT-based Agricultural Assistant Service
// Simulates OpenAI GPT API for agricultural queries

export interface GPTQuery {
  text: string;
  language: string;
  detectedLanguage?: string;
}

export interface GPTResponse {
  id: string;
  query: string;
  response: string;
  language: string;
  englishTranslation?: string;
  confidence: number;
  cropDetected: string | null;
  timestamp: Date;
}

// Mock multilingual agricultural knowledge base
const agriculturalKnowledge = {
  rice: {
    en: {
      fertilizer: "For rice cultivation, apply NPK in 4:2:1 ratio. Use 120kg Nitrogen, 60kg Phosphorus, and 40kg Potassium per hectare. Apply nitrogen in 3 splits: 50% at transplanting, 25% at tillering, and 25% at panicle initiation.",
      disease: "Common rice diseases include brown spot, blast, and bacterial blight. For brown spot, apply Carbendazim 50% WP @ 1g/L. For blast disease, use Tricyclazole 75% WP @ 0.6g/L. Ensure proper field drainage and use disease-resistant varieties.",
      irrigation: "Rice requires 1200-1500mm water throughout growing season. Maintain 2-5cm standing water during vegetative growth. Drain field 10-15 days before harvest. Apply irrigation when hairline cracks appear on soil surface.",
      harvest: "Harvest rice when 80% of grains turn golden yellow. Moisture content should be 20-25% at harvest. Cut paddy 15cm above ground level for better ratoon crop."
    },
    hi: {
      fertilizer: "धान की खेती के लिए एनपीके 4:2:1 अनुपात में डालें। प्रति हेक्टेयर 120 किग्रा नाइट्रोजन, 60 किग्रा फास्फोरस और 40 किग्रा पोटाश का उपयोग करें। नाइट्रोजन को 3 भागों में डालें: 50% रोपाई के समय, 25% कल्ले निकलने पर, 25% बाली आने पर।",
      disease: "धान के सामान्य रोगों में भूरे धब्बे, ब्लास्ट और जीवाणु झुलसा शामिल हैं। भूरे धब्बे के लिए कार्बेन्डाजिम 50% WP @ 1 ग्राम/लीटर डालें। ब्लास्ट रोग के लिए ट्राइसायक्लाजोल 75% WP @ 0.6 ग्राम/लीटर का उपयोग करें।",
      irrigation: "धान को पूरे बढ़ते मौसम में 1200-1500 मिमी पानी की आवश्यकता होती है। वानस्पतिक वृद्धि के दौरान 2-5 सेमी खड़ा पानी बनाए रखें। फसल से 10-15 दिन पहले खेत से पानी निकालें।",
      harvest: "जब 80% दाने सुनहरे पीले हो जाएं तो धान की कटाई करें। कटाई के समय नमी 20-25% होनी चाहिए। बेहतर रतून फसल के लिए धान को जमीन से 15 सेमी ऊपर काटें।"
    },
    ml: {
      fertilizer: "നെല്ലിന് എൻപികെ 4:2:1 അനുപാതത്തിൽ പ്രയോഗിക്കുക। ഹെക്ടറിന് 120 കിലോ നൈട്രജൻ, 60 കിലോ ഫോസ്ഫറസ്, 40 കിലോ പൊട്ടാഷ് ഉപയോഗിക്കുക। നൈട്രജൻ 3 ഭാഗങ്ങളായി പ്രയോഗിക്കുക: 50% നടീൽ സമയത്ത്, 25% കുല പൊട്ടൽ സമയത്ത്, 25% കതിർ വരുമ്പോൾ।",
      disease: "നെല്ലിന്റെ സാധാരണ രോഗങ്ങളിൽ തവിട്ട് പാട്, ബ്ലാസ്റ്റ്, ബാക്ടീരിയൽ ബ്ലൈറ്റ് എന്നിവ ഉൾപ്പെടുന്നു. തവിട്ട് പാട്ടിന് കാർബെൻഡാസിം 50% WP @ 1ഗ്രാം/ലിറ്റർ പ്രയോഗിക്കുക। ബ്ലാസ്റ്റ് രോഗത്തിന് ട്രൈസൈക്ലാസോൾ 75% WP @ 0.6ഗ്രാം/ലിറ്റർ ഉപയോഗിക്കുക।",
      irrigation: "നെല്ലിന് വളർച്ചാ കാലയളവിൽ 1200-1500 മില്ലീമീറ്റർ വെള്ളം ആവശ്യമാണ്. സസ്യവളർച്ചാ കാലത്ത് 2-5 സെന്റീമീറ്റർ നിലനിൽക്കുന്ന വെള്ളം നിലനിർത്തുക। വിളവെടുപ്പിന് 10-15 ദിവസം മുമ്പ് വയൽ വറ്റിക്കുക।",
      harvest: "80% ധാന്യങ്ങൾ സുവർണ്ണ മഞ്ഞയായി മാറുമ്പോൾ നെല്ല് വിളവെടുക്കുക। വിളവെടുപ്പ് സമയത്ത് ഈർപ്പം 20-25% ആയിരിക്കണം। മികച്ച റാറ്റൂൺ വിളയ്ക്കായി നെല്ല് നിലത്തു നിന്ന് 15 സെന്റീമീറ്റർ ഉയരത്തിൽ വെട്ടുക।"
    },
    ta: {
      fertilizer: "நெல் சாகுபடிக்கு என்பிகே 4:2:1 விகிதத்தில் பயன்படുത்துங்கள். ஹெக்டேருக்கு 120 கிலோ நைட்ரஜன், 60 கிலோ பாஸ்பரஸ், 40 கிலோ பொட்டாஷ் பயன்படுத்துங்கள். நைட்ரஜனை 3 பகுதிகளாகப் பிரித்து: 50% நடவு நேரத்தில், 25% தழைத்தல் நேரத்தில், 25% கதிர் வரும்போது.",
      disease: "நெல்லின் பொதுவான நோய்களில் பழுப்பு புள்ளி, வெடிப்பு, பாக்டீரியல் வாட்டல் ஆகியவை அடங்கும். பழுப்பு புள்ளிக்கு கார்பெண்டாசிம் 50% WP @ 1 கிராம்/லிட்டர் பயன்படுத்துங்கள். வெடிப்பு நோய்க்கு ட்ரைசைக்லசோல் 75% WP @ 0.6 கிராம்/லிட்டர் பயன்படுத்துங்கள்.",
      irrigation: "நெல்லுக்கு வளர்ச்சி காலத்தில் 1200-1500 மி.மீ. நீர் தேவை. தாவர வளர்ச்சியின் போது 2-5 செ.மீ. நிற்கும் நீரை பராமரிக்கவும். அறுவடைக்கு 10-15 நாட்கள் முன்பு வயலை வறட்டவும்.",
      harvest: "80% தானியங்கள் தங்க மஞ்சளாக மாறும்போது நெல்லை அறுவடை செய்யவும். அறுவடையின் போது ஈரப்பதம் 20-25% இருக்க வேண்டும். சிறந்த இரண்டாம் பயிருக்காக நெல்லை தரையில் இருந்து 15 செ.மீ. உயரத்தில் வெட்டவும்."
    }
  },
  wheat: {
    en: {
      fertilizer: "Apply NPK 120:60:40 kg/ha for wheat. Use DAP at sowing time and Urea in 2 splits. Apply 10-15 tons farmyard manure per hectare before sowing.",
      disease: "Control wheat rust using Propiconazole 25% EC @ 1ml/L. For aphids, use Imidacloprid 17.8% SL @ 0.3ml/L. Ensure proper crop rotation and use resistant varieties.",
      irrigation: "Wheat requires 4-6 irrigations. First irrigation at 21 days after sowing (crown root stage). Subsequent irrigations at tillering, jointing, flowering, and grain filling stages.",
      harvest: "Harvest wheat when grains are hard and moisture content is 12-14%. Cut crop early morning to prevent shattering. Use combine harvester for large fields."
    },
    hi: {
      fertilizer: "गेहूं के लिए एनपीके 120:60:40 किग्रा/हेक्टेयर डालें। बुवाई के समय डीएपी और यूरिया 2 भागों में डालें। बुवाई से पहले 10-15 टन गोबर खाद प्रति हेक्टेयर डालें।",
      disease: "गेहूं में रतुआ नियंत्रण के लिए प्रोपिकोनाजोल 25% ईसी @ 1 मिली/लीटर का प्रयोग करें। माहू के लिए इमिडाक्लोप्रिड 17.8% एसएल @ 0.3 मिली/लीटर का प्रयोग करें।",
      irrigation: "गेहूं में 4-6 सिंचाई की आवश्यकता होती है। पहली सिंचाई बुवाई के 21 दिन बाद (क्राउन रूट अवस्था में)। बाद की सिंचाई कल्ले निकलने, गांठ बनने, फूल आने और दाना भरने पर करें।",
      harvest: "जब दाने कड़े हो जाएं और नमी 12-14% हो तो गेहूं की कटाई करें। झड़ने से बचने के लिए सुबह जल्दी फसल काटें।"
    },
    ml: {
      fertilizer: "ഗോതമ്പിന് എൻപികെ 120:60:40 കിലോ/ഹെക്ടർ പ്രയോഗിക്കുക। വിതയ്ക്കുമ്പോൾ ഡിഎപിയും യൂറിയ 2 ഭാഗങ്ങളായും പ്രയോഗിക്കുക। വിതയ്ക്കുന്നതിനു മുമ്പ് ഹെക്ടറിന് 10-15 ടൺ ഗോമൂത്രം പ്രയോഗിക്കുക।",
      disease: "ഗോതമ്പിൽ തുരുമ്പ് നിയന്ത്രണത്തിന് പ്രോപികോണസോൾ 25% EC @ 1മില്ലി/ലിറ്റർ ഉപയോഗിക്കുക। മുഞ്ഞകൾക്ക് ഇമിഡാക്ലോപ്രിഡ് 17.8% SL @ 0.3മില്ലി/ലിറ്റർ ഉപയോഗിക്കുക।",
      irrigation: "ഗോതമ്പിന് 4-6 നീർവിതരണം ആവശ്യമാണ്. വിതച്ച് 21 ദിവസം കഴിഞ്ഞ് ആദ്യത്തെ നീർവിതരണം (ക്രൗൺ റൂട്ട് ഘട്ടത്തിൽ). പിന്നീട് കുല പൊട്ടൽ, ജോയിന്റിംഗ്, പൂവിടൽ, ധാന്യം നിറയൽ ഘട്ടങ്ങളിൽ നീർവിതരണം നൽകുക।",
      harvest: "ധാന്യങ്ങൾ കട്ടിയാകുകയും ഈർപ്പം 12-14% ആകുകയും ചെയ്യുമ്പോൾ ഗോതമ്പ് വിളവെടുക്കുക। ചിതറിപ്പോകാതിരിക്കാൻ നേരത്തെ രാവിലെ വിള വെട്ടുക।"
    },
    ta: {
      fertilizer: "கோதுமைக்கு என்பிகே 120:60:40 கிலோ/ஹெக்டேர் பயன்படுத்துங்கள். விதைக்கும் போது டிஏபி மற்றும் யூரியாவை 2 பகுதிகளாக இடுங்கள். விதைக்கும் முன் ஹெக்டேருக்கு 10-15 டன் தொழு உரம் இடுங்கள்.",
      disease: "கோதுமையில் துரு நோய் கட்டுப்பாட்டுக்கு புரோபிகோனசோல் 25% EC @ 1 மி.லி/லிட்டர் பயன்படுத்துங்கள். பேன்களுக்கு இமிடாக்ளோப்ரிட் 17.8% SL @ 0.3 மி.லி/லிட்டர் பயன்படுத்துங்கள்.",
      irrigation: "கோதுமைக்கு 4-6 நீர்ப்பாசனம் தேவை. விதைத்த 21 நாட்களுக்குப் பிறகு முதல் நீர்ப்பாசனம் (கிரீடம் வேர் நிலையில்). பின்னர் தழைத்தல், மூட்டு உருவாக்கம், பூக்கும் மற்றும் தானிய நிரப்புதல் நிலைகளில் நீர்ப்பாசனம் செய்யவும்.",
      harvest: "தானியங்கள் கடினமாகி ஈரப்பதம் 12-14% ஆகும்போது கோதுமையை அறுவடை செய்யவும். சிதறுவதைத் தவிர்க்க அதிகாலையில் பயிரை வெட்டவும்."
    }
  },
  tomato: {
    en: {
      fertilizer: "Apply NPK 150:75:50 kg/ha for tomato. Use calcium nitrate for fruit development. Apply magnesium sulfate for preventing blossom end rot.",
      disease: "For late blight, apply Metalaxyl+Mancozeb @ 2g/L. For whitefly control, use Spiromesifen 240% SC @ 1ml/L. For fruit borer, apply Emamectin benzoate @ 0.4g/L.",
      irrigation: "Tomato requires regular irrigation. Apply water when top 2-3 cm soil becomes dry. Use drip irrigation for efficient water use. Avoid water stress during fruit development.",
      harvest: "Harvest tomatoes when they show first color change. Pick fruits every 2-3 days. Store at 12-15°C for longer shelf life."
    },
    hi: {
      fertilizer: "टमाटर के लिए एनपीके 150:75:50 किग्रा/हेक्टेयर डालें। फल विकास के लिए कैल्शियम नाइट्रेट का उपयोग करें। ब्लॉसम एंड रॉट रोकने के लिए मैग्नीशियम सल्फेट डालें।",
      disease: "अंगमारी के लिए मेटालैक्सिल+मैंकोजेब @ 2 ग्राम/लीटर का प्रयोग करें। सफेद मक्खी नियंत्रण के लिए स्पिरोमेसिफेन 240% एससी @ 1 मिली/लीटर का प्रयोग करें।",
      irrigation: "टमाटर में नियमित सिंचाई की आवश्यकता होती है। जब ऊपरी 2-3 सेमी मिट्टी सूख जाए तो पानी दें। कुशल पानी के उपयोग के लिए ड्रिप सिंचाई का प्रयोग करें।",
      harvest: "जब टमाटर में पहला रंग परिवर्तन दिखे तो तुड़ाई करें। हर 2-3 दिन में फल तोड़ें। लंबी शेल्फ लाइफ के लिए 12-15°C पर स्टोर करें।"
    },
    ml: {
      fertilizer: "തക്കാളിക്ക് എൻപികെ 150:75:50 കിലോ/ഹെക്ടർ പ്രയോഗിക്കുക। ഫല വികസനത്തിന് കാൽസ്യം നൈട്രേറ്റ് ഉപയോഗിക്കുക। ബ്ലോസം എൻഡ് റോട്ട് തടയാൻ മഗ്നീഷ്യം സൾഫേറ്റ് പ്രയോഗിക്കുക।",
      disease: "വൈകിയ വരൾച്ചയ്ക്ക് മെറ്റലാക്സിൽ+മാൻകോസെബ് @ 2ഗ്രാം/ലിറ്റർ പ്രയോഗിക്കുക। വെളുത്ത ഈച്ച നിയന്ത്രണത്തിന് സ്പൈറോമെസിഫെൻ 240% SC @ 1മില്ലി/ലിറ്റർ ഉപയോഗിക്കുക।",
      irrigation: "തക്കാളിക്ക് പതിവ് നീർവിതരണം ആവശ്യമാണ്. മുകളിലെ 2-3 സെന്റീമീറ്റർ മണ്ണ് ഉണങ്ങുമ്പോൾ വെള്ളം നൽകുക। കാര്യക്ഷമമായ ജല ഉപയോഗത്തിന് ഡ്രിപ്പ് ഇറിഗേഷൻ ഉപയോഗിക്കുക।",
      harvest: "തക്കാളിയിൽ ആദ്യത്തെ നിറം മാറ്റം കാണിക്കുമ്പോൾ വിളവെടുക്കുക. ഓരോ 2-3 ദിവസത്തിലും ഫലങ്ങൾ പറിക്കുക. ദീർഘകാല ശേഖരണത്തിന് 12-15°C ൽ സൂക്ഷിക്കുക।"
    },
    ta: {
      fertilizer: "தக்காளிக்கு என்பிகே 150:75:50 கிலோ/ஹெக்டேர் பயன்படுத்துங்கள். பழ வளர்ச்சிக்கு கால்சியம் நைட்ரேட் பயன்படுத்துங்கள். மலர் முனை அழுகலைத் தடுக்க மெக்னீசியம் சல்பேட் இடுங்கள்.",
      disease: "தாமதமான வாட்டலுக்கு மெட்டலாக்சில்+மான்கோசெப் @ 2 கிராம்/லிட்டர் பயன்படுத்துங்கள். வெள்ளை ஈக்கள் கட்டுப்பாட்டுக்கு ஸ்பைரோமெசிஃபென் 240% SC @ 1 மி.லி/லிட்டர் பயன்படுத்துங்கள்.",
      irrigation: "தக்காளிக்கு தொடர்ந்து நீர்ப்பாசனம் தேவை. மேல் 2-3 செ.மீ. மண் காய்ந்தால் தண்ணீர் கொடுங்கள். திறமையான நீர் பயன்பாட்டுக்கு சொட்டு நீர்ப்பாசனம் பயன்படுத்துங்கள்.",
      harvest: "தக்காளியில் முதல் நிற மாற்றம் தெரியும்போது அறுவடை செய்யவும். ஒவ்வொரு 2-3 நாட்களுக்கும் பழங்களை பறிக்கவும். நீண்ட கால சேமிப்புக்கு 12-15°C இல் வைக்கவும்."
    }
  }
};

// Language detection helper
const detectLanguageFromText = (text: string): string => {
  const cleanText = text.toLowerCase().trim();
  
  // Malayalam detection (Malayalam script)
  if (/[\u0D00-\u0D7F]/.test(text)) return 'ml';
  
  // Tamil detection (Tamil script)
  if (/[\u0B80-\u0BFF]/.test(text)) return 'ta';
  
  // Hindi detection (Devanagari script)
  if (/[\u0900-\u097F]/.test(text)) return 'hi';
  
  // Common Hindi words in Latin script
  const hindiWords = ['kya', 'hai', 'mein', 'aur', 'se', 'ko', 'ki', 'ke', 'fasal', 'kheti', 'kaise', 'kab', 'kaun'];
  if (hindiWords.some(word => cleanText.includes(word))) return 'hi';
  
  // Common Malayalam words in Latin script
  const malayalamWords = ['enth', 'aan', 'oru', 'und', 'illa', 'krishi', 'pani', 'engane', 'eppo'];
  if (malayalamWords.some(word => cleanText.includes(word))) return 'ml';
  
  // Common Tamil words in Latin script
  const tamilWords = ['enna', 'oru', 'irukku', 'illa', 'velai', 'krishi', 'eppadi', 'eppo'];
  if (tamilWords.some(word => cleanText.includes(word))) return 'ta';
  
  return 'en'; // Default to English
};

// Crop detection from query
const detectCrop = (query: string): string | null => {
  const crops = ['rice', 'wheat', 'tomato', 'cotton', 'maize', 'potato', 'onion'];
  const aliases = {
    'rice': ['paddy', 'dhan', 'chawal', 'nellu', 'arisi', 'dhaan'],
    'wheat': ['gehun', 'godhi', 'gahuun', 'gothambu'],
    'tomato': ['tamatar', 'thakkali', 'tomatoe'],
    'cotton': ['kapas', 'patti', 'karpas'],
    'maize': ['corn', 'makka', 'cholam', 'bhutta'],
    'potato': ['aloo', 'batata', 'urulaikizhangu'],
    'onion': ['pyaz', 'kanda', 'vengayam', 'ullipaya']
  };

  const lowercaseQuery = query.toLowerCase();
  
  for (const crop of crops) {
    if (lowercaseQuery.includes(crop)) return crop;
    const cropAliases = aliases[crop as keyof typeof aliases] || [];
    if (cropAliases.some(alias => lowercaseQuery.includes(alias))) return crop;
  }
  
  return null;
};

// Generate GPT response
const generateGPTResponse = async (query: GPTQuery): Promise<GPTResponse> => {
  // Simulate API delay
  await new Promise(resolve => setTimeout(resolve, 1500));
  
  const detectedLang = query.detectedLanguage || detectLanguageFromText(query.text);
  const responseLang = query.language;
  const cropDetected = detectCrop(query.text);
  
  let response = '';
  let englishTranslation = '';
  
  if (cropDetected && agriculturalKnowledge[cropDetected as keyof typeof agriculturalKnowledge]) {
    const cropInfo = agriculturalKnowledge[cropDetected as keyof typeof agriculturalKnowledge];
    
    // Determine query intent
    const queryLower = query.text.toLowerCase();
    let intent = 'general';
    
    if (queryLower.includes('fertilizer') || queryLower.includes('fertiliser') || queryLower.includes('khad') || queryLower.includes('urvar') || queryLower.includes('വള') || queryLower.includes('உர')) {
      intent = 'fertilizer';
    } else if (queryLower.includes('disease') || queryLower.includes('pest') || queryLower.includes('rog') || queryLower.includes('keet') || queryLower.includes('രോഗ') || queryLower.includes('கீട') || queryLower.includes('നോയ്')) {
      intent = 'disease';
    } else if (queryLower.includes('water') || queryLower.includes('irrigation') || queryLower.includes('sinchay') || queryLower.includes('pani') || queryLower.includes('വെള്ളം') || queryLower.includes('நീர்')) {
      intent = 'irrigation';
    } else if (queryLower.includes('harvest') || queryLower.includes('katai') || queryLower.includes('फसल') || queryLower.includes('വിളവെടുപ്പ്') || queryLower.includes('அறுவடை')) {
      intent = 'harvest';
    }
    
    if (cropInfo[responseLang as keyof typeof cropInfo] && cropInfo[responseLang as keyof typeof cropInfo][intent as keyof any]) {
      response = cropInfo[responseLang as keyof typeof cropInfo][intent as keyof any];
      
      // Generate English translation if response is not in English
      if (responseLang !== 'en' && cropInfo.en && cropInfo.en[intent as keyof typeof cropInfo.en]) {
        englishTranslation = cropInfo.en[intent as keyof typeof cropInfo.en];
      }
    } else {
      // Fallback response
      const fallbackResponses = {
        en: `Based on your query about ${cropDetected}, here are general recommendations: Use appropriate fertilizers, monitor for pests and diseases, ensure proper irrigation, and harvest at the right time. For specific advice, consult local agricultural experts.`,
        hi: `${cropDetected} के बारे में आपके प्रश्न के आधार पर, यहाँ सामान्य सुझाव हैं: उपयुक्त उर्वरकों का उपयोग करें, कीट और रोगों की निगरानी करें, उचित सिंचाई सुनिश्चित करें, और सही समय पर फसल काटें।`,
        ml: `${cropDetected} നെ കുറിച്ചുള്ള നിങ്ങളുടെ ചോദ്യത്തിന്റെ അടിസ്ഥാനത്തിൽ, ഇവിടെ പൊതുവായ ശുപാർശകൾ ഉണ്ട്: ഉചിതമായ വളങ്ങൾ ഉപയോഗിക്കുക, കീടങ്ങളും രോഗങ്ങളും നിരീക്ഷിക്കുക, ശരിയായ നീർവിതരണം ഉറപ്പാക്കുക, ശരിയായ സമയത്ത് വിളവെടുക്കുക।`,
        ta: `${cropDetected} பற்றிய உங்கள் கேள்வியின் அடிப்படையில், இங்கே பொதுவான பரிந்துரைகள் உள்ளன: பொருத்தமான உரங்களைப் பயன்படுத்துங்கள், பூச்சிகள் மற்றும் நோய்களைக் கண்காணிக்கவும், சரியான நீர்ப்பாசனத்தை உறுதி செய்யுங்கள், சரியான நேரத்தில் அறுவடை செய்யுங்கள்.`
      };
      
      response = fallbackResponses[responseLang as keyof typeof fallbackResponses] || fallbackResponses.en;
      
      if (responseLang !== 'en') {
        englishTranslation = fallbackResponses.en;
      }
    }
  } else {
    // No crop detected - general response
    const generalResponses = {
      en: "I understand you're asking about farming. To provide specific recommendations, please mention the crop you're asking about (rice, wheat, tomato, etc.) and your specific question (fertilizer, disease, irrigation, etc.).",
      hi: "मैं समझता हूं कि आप खेती के बारे में पूछ रहे हैं। विशिष्ट सुझाव देने के लिए, कृपया बताएं कि आप किस फसल के बारे में पूछ रहे हैं (धान, गेहूं, टमाटर, आदि) और आपका विशिष्ट प्रश्न (उर्वरक, रोग, सिंचाई, आदि)।",
      ml: "നിങ്ങൾ കാർഷികത്തെക്കുറിച്ച് ചോദിക്കുന്നുവെന്ന് ഞാൻ മനസ്സിലാക്കുന്നു. നിർദ്ദിഷ്ട ശുപാർശകൾ നൽകാൻ, ദയവായി നിങ്ങൾ ഏത് വിളയെക്കുറിച്ചാണ് ചോദിക്കുന്നത് (നെല്ല്, ഗോതമ്പ്, തക്കാളി മുതലായവ) എന്നും നിങ്ങളുടെ നിർദ്ദിഷ്ട ചോദ്യം (വളം, രോഗം, നീർവിതരണം മുതലായവ) എന്നും പറയുക।",
      ta: "நீங்கள் விவசாயத்தைப் பற்றி கேட்கிறீர்கள் என்பதை நான் புரிந்துகொள்கிறேன். குறிப்பிட்ட பரிந்துரைகளை வழங்க, நீங்கள் எந்த பயிரைப் பற்றி கேட்கிறீர்கள் (நெல், கோதுமை, தக்காளி, போன்றவை) மற்றும் உங்கள் குறிப்பிட்ட கேள்வி (உரம், நோய், நீர்ப்பாசனம், போன்றவை) என்று சொல்லுங்கள்."
    };
    
    response = generalResponses[responseLang as keyof typeof generalResponses] || generalResponses.en;
    
    if (responseLang !== 'en') {
      englishTranslation = generalResponses.en;
    }
  }
  
  return {
    id: Date.now().toString(),
    query: query.text,
    response,
    language: responseLang,
    englishTranslation: responseLang !== 'en' ? englishTranslation : undefined,
    confidence: cropDetected ? 0.85 : 0.4,
    cropDetected,
    timestamp: new Date()
  };
};

export class GPTService {
  static async processQuery(query: GPTQuery): Promise<GPTResponse> {
    return generateGPTResponse(query);
  }
  
  static detectLanguage(text: string): string {
    return detectLanguageFromText(text);
  }
  
  static detectCropFromQuery(text: string): string | null {
    return detectCrop(text);
  }
}