import { projectId, publicAnonKey } from './supabase/info';

const API_BASE_URL = `https://${projectId}.supabase.co/functions/v1/make-server-7a8723f1`;

const apiHeaders = {
  'Content-Type': 'application/json',
  'Authorization': `Bearer ${publicAnonKey}`,
};

export interface QueryRequest {
  question: string;
  questionMl?: string;
  context: {
    location: string;
    crop: string;
    season: string;
    farmerId: string;
  };
  type: 'text' | 'voice' | 'image';
}

export interface QueryResponse {
  queryId: string;
  answer: string;
  answerMl: string;
  status: 'resolved' | 'escalated';
  confidence: number;
  escalated: boolean;
}

export interface FarmerQuery {
  id: string;
  farmerId: string;
  question: string;
  questionMl?: string;
  answer: string;
  answerMl?: string;
  context: any;
  type: string;
  status: string;
  timestamp: string;
  confidence: number;
  satisfaction?: 'positive' | 'negative';
  feedback?: string;
}

// Submit a new farmer query
export async function submitQuery(request: QueryRequest): Promise<QueryResponse> {
  try {
    const response = await fetch(`${API_BASE_URL}/queries`, {
      method: 'POST',
      headers: apiHeaders,
      body: JSON.stringify(request),
    });

    if (!response.ok) {
      throw new Error(`API error: ${response.status} ${response.statusText}`);
    }

    const data = await response.json();
    console.log('Query submitted successfully:', data);
    return data;
  } catch (error) {
    console.error('Error submitting query:', error);
    throw error;
  }
}

// Get farmer's query history
export async function getQueryHistory(farmerId: string): Promise<FarmerQuery[]> {
  try {
    const response = await fetch(`${API_BASE_URL}/farmers/${farmerId}/queries`, {
      headers: apiHeaders,
    });

    if (!response.ok) {
      throw new Error(`API error: ${response.status} ${response.statusText}`);
    }

    const data = await response.json();
    console.log('Query history fetched successfully:', data);
    return data.queries || [];
  } catch (error) {
    console.error('Error fetching query history:', error);
    throw error;
  }
}

// Submit feedback for a query
export async function submitQueryFeedback(
  queryId: string, 
  satisfaction: 'positive' | 'negative', 
  feedback?: string
): Promise<void> {
  try {
    const response = await fetch(`${API_BASE_URL}/queries/${queryId}/feedback`, {
      method: 'POST',
      headers: apiHeaders,
      body: JSON.stringify({ satisfaction, feedback }),
    });

    if (!response.ok) {
      throw new Error(`API error: ${response.status} ${response.statusText}`);
    }

    console.log('Query feedback submitted successfully');
  } catch (error) {
    console.error('Error submitting query feedback:', error);
    throw error;
  }
}

// Update farmer profile
export async function updateFarmerProfile(farmerId: string, profileData: any): Promise<void> {
  try {
    const response = await fetch(`${API_BASE_URL}/farmers/${farmerId}/profile`, {
      method: 'POST',
      headers: apiHeaders,
      body: JSON.stringify(profileData),
    });

    if (!response.ok) {
      throw new Error(`API error: ${response.status} ${response.statusText}`);
    }

    console.log('Farmer profile updated successfully');
  } catch (error) {
    console.error('Error updating farmer profile:', error);
    throw error;
  }
}

// Get farmer profile
export async function getFarmerProfile(farmerId: string): Promise<any> {
  try {
    const response = await fetch(`${API_BASE_URL}/farmers/${farmerId}/profile`, {
      headers: apiHeaders,
    });

    if (!response.ok) {
      if (response.status === 404) {
        return null; // Profile doesn't exist yet
      }
      throw new Error(`API error: ${response.status} ${response.statusText}`);
    }

    const data = await response.json();
    console.log('Farmer profile fetched successfully:', data);
    return data.profile;
  } catch (error) {
    console.error('Error fetching farmer profile:', error);
    throw error;
  }
}

// Get knowledge base articles
export async function getKnowledgeBase(category?: string, search?: string): Promise<any[]> {
  try {
    const params = new URLSearchParams();
    if (category) params.append('category', category);
    if (search) params.append('search', search);

    const response = await fetch(`${API_BASE_URL}/knowledge?${params.toString()}`, {
      headers: apiHeaders,
    });

    if (!response.ok) {
      throw new Error(`API error: ${response.status} ${response.statusText}`);
    }

    const data = await response.json();
    console.log('Knowledge base fetched successfully:', data);
    return data.articles || [];
  } catch (error) {
    console.error('Error fetching knowledge base:', error);
    throw error;
  }
}