import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { ArrowLeft, Plus, Sprout } from "lucide-react";

const MyCrop = () => {
  const crops = [
    { id: 1, name: "Tomatoes", status: "Growing", planted: "2024-01-15" },
    { id: 2, name: "Rice", status: "Harvested", planted: "2023-12-01" },
    { id: 3, name: "Wheat", status: "Planted", planted: "2024-02-10" },
  ];

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border bg-card">
        <div className="container mx-auto px-4 py-6">
          <div className="flex items-center gap-4">
            <Link to="/">
              <Button variant="outline" size="sm" className="gap-2">
                <ArrowLeft size={16} />
                Back
              </Button>
            </Link>
            <h1 className="text-2xl font-bold text-primary">My Crop</h1>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-8">
        <div className="max-w-4xl mx-auto">
          <div className="flex items-center justify-between mb-8">
            <h2 className="text-xl text-foreground">Crop Management</h2>
            <Button className="gap-2 bg-gradient-primary hover:bg-primary-hover">
              <Plus size={16} />
              Add New Crop
            </Button>
          </div>

          {/* Crops Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {crops.map((crop) => (
              <Card key={crop.id} className="p-6 border border-border shadow-card hover:shadow-hover transition-all duration-300">
                <div className="space-y-4">
                  <div className="flex items-center gap-3">
                    <div className="w-12 h-12 bg-gradient-primary rounded-full flex items-center justify-center">
                      <Sprout size={20} className="text-primary-foreground" />
                    </div>
                    <div>
                      <h3 className="font-semibold text-foreground">{crop.name}</h3>
                      <p className="text-sm text-muted-foreground">Status: {crop.status}</p>
                    </div>
                  </div>
                  <div className="space-y-2">
                    <p className="text-sm text-muted-foreground">
                      Planted: {crop.planted}
                    </p>
                    <div className="flex gap-2">
                      <Button size="sm" variant="outline" className="flex-1">
                        View Details
                      </Button>
                      <Button size="sm" className="flex-1">
                        Update
                      </Button>
                    </div>
                  </div>
                </div>
              </Card>
            ))}
          </div>
        </div>
      </main>
    </div>
  );
};

export default MyCrop;