import { useState } from "react";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { ArrowLeft, Mic, MicOff, Volume2 } from "lucide-react";

const VoiceInput = () => {
  const [isListening, setIsListening] = useState(false);
  const [transcript, setTranscript] = useState("");

  const handleToggleListening = () => {
    setIsListening(!isListening);
    if (!isListening) {
      setTranscript("Listening for voice input...");
    } else {
      setTranscript("Voice recording stopped. Processing your request...");
    }
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border bg-card">
        <div className="container mx-auto px-4 py-6">
          <div className="flex items-center gap-4">
            <Link to="/">
              <Button variant="outline" size="sm" className="gap-2">
                <ArrowLeft size={16} />
                Back
              </Button>
            </Link>
            <h1 className="text-2xl font-bold text-primary">Voice Input</h1>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-8">
        <div className="max-w-2xl mx-auto text-center">
          <div className="mb-8">
            <h2 className="text-xl text-foreground mb-4">Voice Assistant</h2>
            <p className="text-muted-foreground">
              Speak naturally about your farming questions or concerns
            </p>
          </div>

          {/* Voice Control */}
          <Card className="p-8 mb-8 border border-border shadow-card">
            <div className="space-y-6">
              <div
                className={`w-32 h-32 mx-auto rounded-full flex items-center justify-center transition-all duration-300 ${
                  isListening 
                    ? "bg-gradient-primary animate-pulse scale-110" 
                    : "bg-secondary hover:bg-accent"
                }`}
              >
                <button
                  onClick={handleToggleListening}
                  className="w-full h-full flex items-center justify-center rounded-full"
                >
                  {isListening ? (
                    <MicOff size={48} className="text-primary-foreground" />
                  ) : (
                    <Mic size={48} className="text-primary" />
                  )}
                </button>
              </div>
              
              <div>
                <p className="text-lg font-medium text-foreground mb-2">
                  {isListening ? "Listening..." : "Tap to speak"}
                </p>
                <Button
                  onClick={handleToggleListening}
                  className={`${
                    isListening 
                      ? "bg-destructive hover:bg-destructive/90" 
                      : "bg-gradient-primary hover:bg-primary-hover"
                  }`}
                >
                  {isListening ? "Stop Recording" : "Start Recording"}
                </Button>
              </div>
            </div>
          </Card>

          {/* Transcript Display */}
          {transcript && (
            <Card className="p-6 border border-border shadow-card">
              <div className="space-y-4">
                <div className="flex items-center gap-2 justify-center">
                  <Volume2 size={20} className="text-primary" />
                  <h3 className="font-semibold text-foreground">Transcript</h3>
                </div>
                <p className="text-muted-foreground italic">"{transcript}"</p>
                {transcript.includes("Processing") && (
                  <Button className="mt-4">
                    Get AI Response
                  </Button>
                )}
              </div>
            </Card>
          )}
        </div>
      </main>
    </div>
  );
};

export default VoiceInput;