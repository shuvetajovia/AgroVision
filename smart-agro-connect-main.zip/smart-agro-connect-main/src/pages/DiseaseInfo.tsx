import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { ArrowLeft, Bug, Search, Camera, AlertTriangle } from "lucide-react";

const DiseaseInfo = () => {
  const commonDiseases = [
    {
      id: 1,
      name: "Leaf Blight",
      crops: ["Rice", "Wheat"],
      severity: "High",
      symptoms: "Brown spots on leaves, yellowing"
    },
    {
      id: 2,
      name: "Powdery Mildew", 
      crops: ["Tomato", "Cucumber"],
      severity: "Medium",
      symptoms: "White powdery coating on leaves"
    },
    {
      id: 3,
      name: "Root Rot",
      crops: ["Tomato", "Pepper"],
      severity: "High", 
      symptoms: "Wilting, stunted growth, dark roots"
    }
  ];

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case "High": return "text-destructive";
      case "Medium": return "text-amber-500";
      case "Low": return "text-primary";
      default: return "text-muted-foreground";
    }
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border bg-card">
        <div className="container mx-auto px-4 py-6">
          <div className="flex items-center gap-4">
            <Link to="/">
              <Button variant="outline" size="sm" className="gap-2">
                <ArrowLeft size={16} />
                Back
              </Button>
            </Link>
            <h1 className="text-2xl font-bold text-primary">Disease Info</h1>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-8">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-8">
            <h2 className="text-xl text-foreground mb-4">Disease Identification</h2>
            <p className="text-muted-foreground">
              Identify and learn about crop diseases
            </p>
          </div>

          {/* Search and Camera */}
          <Card className="p-6 mb-8 border border-border shadow-card">
            <div className="space-y-4">
              <div className="flex items-center gap-3 mb-4">
                <Bug className="text-primary" size={24} />
                <h3 className="font-semibold text-foreground">Find Disease Information</h3>
              </div>
              
              <div className="flex gap-2 mb-4">
                <Input 
                  placeholder="Search disease by name or symptoms..."
                  className="flex-1"
                />
                <Button className="gap-2 bg-gradient-primary hover:bg-primary-hover">
                  <Search size={16} />
                  Search
                </Button>
              </div>

              <div className="flex justify-center">
                <Button variant="outline" className="gap-2">
                  <Camera size={16} />
                  Take Photo for Diagnosis
                </Button>
              </div>
            </div>
          </Card>

          {/* Common Diseases */}
          <div className="space-y-6">
            <h3 className="text-lg font-semibold text-foreground flex items-center gap-2">
              <AlertTriangle size={20} />
              Common Diseases
            </h3>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {commonDiseases.map((disease) => (
                <Card key={disease.id} className="p-6 border border-border shadow-card hover:shadow-hover transition-all duration-300">
                  <div className="space-y-4">
                    <div className="flex items-start justify-between">
                      <h4 className="font-semibold text-foreground">{disease.name}</h4>
                      <span className={`text-sm font-medium ${getSeverityColor(disease.severity)}`}>
                        {disease.severity}
                      </span>
                    </div>
                    
                    <div className="space-y-2">
                      <p className="text-sm text-muted-foreground">
                        <strong>Affects:</strong> {disease.crops.join(", ")}
                      </p>
                      <p className="text-sm text-muted-foreground">
                        <strong>Symptoms:</strong> {disease.symptoms}
                      </p>
                    </div>
                    
                    <div className="flex gap-2 pt-2">
                      <Button size="sm" className="flex-1">
                        View Details
                      </Button>
                      <Button size="sm" variant="outline" className="flex-1">
                        Treatment
                      </Button>
                    </div>
                  </div>
                </Card>
              ))}
            </div>
          </div>
        </div>
      </main>
    </div>
  );
};

export default DiseaseInfo;