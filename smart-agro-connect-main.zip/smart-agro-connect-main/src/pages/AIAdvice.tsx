import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { ArrowLeft, Brain, Send, MessageCircle } from "lucide-react";

const AIAdvice = () => {
  const suggestions = [
    "What's the best time to plant rice?",
    "How to identify pest damage?",
    "Optimal watering schedule for tomatoes?",
    "Fertilizer recommendations for wheat?"
  ];

  const recentAdvice = [
    {
      id: 1,
      question: "Yellowing leaves on tomato plants",
      answer: "This could indicate nitrogen deficiency or overwatering. Check soil moisture and consider balanced fertilizer.",
      date: "2 hours ago"
    },
    {
      id: 2, 
      question: "Best planting season for rice",
      answer: "Monsoon season (June-July) is ideal for rice planting in most regions. Ensure adequate water availability.",
      date: "1 day ago"
    }
  ];

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border bg-card">
        <div className="container mx-auto px-4 py-6">
          <div className="flex items-center gap-4">
            <Link to="/">
              <Button variant="outline" size="sm" className="gap-2">
                <ArrowLeft size={16} />
                Back
              </Button>
            </Link>
            <h1 className="text-2xl font-bold text-primary">AI Advice</h1>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-8">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-8">
            <h2 className="text-xl text-foreground mb-4">Agricultural Intelligence</h2>
            <p className="text-muted-foreground">
              Get expert farming advice powered by AI
            </p>
          </div>

          {/* Query Input */}
          <Card className="p-6 mb-8 border border-border shadow-card">
            <div className="space-y-4">
              <div className="flex items-center gap-3 mb-4">
                <Brain className="text-primary" size={24} />
                <h3 className="font-semibold text-foreground">Ask AI Assistant</h3>
              </div>
              <div className="flex gap-2">
                <Input 
                  placeholder="Type your farming question here..."
                  className="flex-1"
                />
                <Button className="gap-2 bg-gradient-primary hover:bg-primary-hover">
                  <Send size={16} />
                  Ask
                </Button>
              </div>
              
              <div className="pt-4">
                <p className="text-sm text-muted-foreground mb-3">Quick suggestions:</p>
                <div className="flex flex-wrap gap-2">
                  {suggestions.map((suggestion, index) => (
                    <Button
                      key={index}
                      variant="outline"
                      size="sm"
                      className="text-xs"
                    >
                      {suggestion}
                    </Button>
                  ))}
                </div>
              </div>
            </div>
          </Card>

          {/* Recent Advice */}
          <div className="space-y-6">
            <h3 className="text-lg font-semibold text-foreground flex items-center gap-2">
              <MessageCircle size={20} />
              Recent Advice
            </h3>
            
            {recentAdvice.map((advice) => (
              <Card key={advice.id} className="p-6 border border-border shadow-card">
                <div className="space-y-3">
                  <div className="flex items-start justify-between">
                    <h4 className="font-medium text-foreground">{advice.question}</h4>
                    <span className="text-xs text-muted-foreground">{advice.date}</span>
                  </div>
                  <p className="text-muted-foreground">{advice.answer}</p>
                  <div className="flex gap-2 pt-2">
                    <Button size="sm" variant="outline">
                      Helpful
                    </Button>
                    <Button size="sm" variant="outline">
                      More Info
                    </Button>
                  </div>
                </div>
              </Card>
            ))}
          </div>
        </div>
      </main>
    </div>
  );
};

export default AIAdvice;