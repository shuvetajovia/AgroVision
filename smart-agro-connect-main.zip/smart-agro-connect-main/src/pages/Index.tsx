import { useState } from "react";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Sprout, Mic, Brain, Bug, ChevronDown, Globe, Palette } from "lucide-react";

const languages = [
  { code: "en", name: "English" },
  { code: "ta", name: "Tamil" },
  { code: "ml", name: "Malayalam" },
  { code: "te", name: "Telugu" },
  { code: "kn", name: "Kannada" },
];

const Index = () => {
  const [selectedLanguage, setSelectedLanguage] = useState(languages[0]);
  const [theme, setTheme] = useState<'default' | 'dark' | 'bw'>('default');

  const toggleTheme = () => {
    const newTheme = theme === 'default' ? 'dark' : theme === 'dark' ? 'bw' : 'default';
    setTheme(newTheme);
    
    const root = document.documentElement;
    root.classList.remove('dark', 'bw-theme');
    if (newTheme === 'dark') {
      root.classList.add('dark');
    } else if (newTheme === 'bw') {
      root.classList.add('bw-theme');
    }
  };

  const navigationItems = [
    {
      title: "MY CROP",
      path: "/my-crop",
      icon: Sprout,
      description: "Manage your crops and track progress",
    },
    {
      title: "VOICE INPUT",
      path: "/voice-input",
      icon: Mic,
      description: "Voice-activated crop assistance",
    },
    {
      title: "AI ADVICE",
      path: "/ai-advice",
      icon: Brain,
      description: "Get intelligent farming recommendations",
    },
    {
      title: "DISEASE INFO",
      path: "/disease-info",
      icon: Bug,
      description: "Identify and treat crop diseases",
    },
  ];

  return (
    <div className="h-screen bg-gradient-to-br from-background via-secondary/20 to-background flex flex-col">
      {/* Header */}
      <header className="relative border-b border-border/50 bg-gradient-card backdrop-blur-sm">
        <div className="absolute inset-0 bg-gradient-to-r from-transparent via-primary/5 to-transparent" />
        <div className="relative container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-gradient-primary rounded-xl flex items-center justify-center shadow-glow">
                <Sprout size={20} className="text-primary-foreground" />
              </div>
              <h1 className="text-3xl font-bold bg-gradient-to-r from-primary via-primary-hover to-primary bg-clip-text text-transparent">
                AGROVISION
              </h1>
            </div>
            
            <div className="flex items-center gap-2">
              <Button 
                variant="outline" 
                size="sm"
                onClick={toggleTheme}
                className="gap-2 bg-gradient-card hover:bg-gradient-hover border-border/60 shadow-card hover:shadow-hover transition-all duration-300"
              >
                <Palette size={14} />
                {theme === 'default' ? 'Cool' : theme === 'dark' ? 'Dark' : 'B&W'}
              </Button>
              
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="outline" size="sm" className="gap-2 bg-gradient-card hover:bg-gradient-hover border-border/60 shadow-card hover:shadow-hover transition-all duration-300">
                    <Globe size={14} />
                    {selectedLanguage.name}
                    <ChevronDown size={14} />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end" className="bg-popover/95 backdrop-blur-md border border-border/60 shadow-hover">
                  {languages.map((language) => (
                    <DropdownMenuItem
                      key={language.code}
                      onClick={() => setSelectedLanguage(language)}
                      className="hover:bg-accent/80 transition-colors duration-200"
                    >
                      {language.name}
                    </DropdownMenuItem>
                  ))}
                </DropdownMenuContent>
              </DropdownMenu>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1 container mx-auto px-4 py-6 flex flex-col">
        <div className="text-center mb-8">
          <h2 className="text-2xl font-light text-foreground/90 mb-3 tracking-wide">
            Smart Farming Solutions
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            AI-powered tools for modern farming
          </p>
        </div>

        {/* Navigation Grid */}
        <div className="flex-1 grid grid-cols-2 gap-4 max-w-4xl mx-auto">
          {navigationItems.map((item, index) => {
            const Icon = item.icon;
            return (
              <Link key={item.path} to={item.path}>
                <Card className="group relative p-6 border-0 bg-gradient-card hover:bg-gradient-hover shadow-card hover:shadow-hover transition-all duration-500 cursor-pointer overflow-hidden h-full flex flex-col justify-center">
                  {/* Decorative background element */}
                  <div className="absolute top-0 right-0 w-20 h-20 bg-gradient-primary opacity-5 rounded-full -translate-y-10 translate-x-10 group-hover:scale-150 transition-transform duration-700" />
                  
                  <div className="relative text-center space-y-4">
                    <div className="w-16 h-16 bg-gradient-primary rounded-2xl flex items-center justify-center mx-auto group-hover:scale-110 group-hover:rotate-3 transition-all duration-500 shadow-glow">
                      <Icon size={28} className="text-primary-foreground" />
                    </div>
                    <h3 className="text-xl font-semibold text-foreground group-hover:text-primary transition-colors duration-300">
                      {item.title}
                    </h3>
                    <p className="text-muted-foreground text-sm leading-relaxed">
                      {item.description}
                    </p>
                    
                    {/* Hover indicator */}
                    <div className="absolute bottom-0 left-1/2 w-0 h-1 bg-gradient-primary group-hover:w-12 transition-all duration-300 transform -translate-x-1/2 rounded-full" />
                  </div>
                </Card>
              </Link>
            );
          })}
        </div>
      </main>
    </div>
  );
};

export default Index;